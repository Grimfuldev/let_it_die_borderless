"""UI building blocks: Windows dialogs, DPI, TextBox, number parsers, and the Outer / Center catalog popups (CatalogMixin)."""
import ctypes
import os
import time
from rt_core import (
    ART,
    DEFAULTS,
    GAME_EXE,
    IS_WIN,
    KIND_DIRS,
    MAX_DUPE,
    VK_NAMES,
    abs_of,
    clamp,
    compose,
    ensure_dirs,
    kind_sections,
    load_section_cfg,
    norm_section,
    parse_rgb,
    prune_selected,
    rel_of,
    rgb_text,
    save_section_cfg,
)
import pygame


def open_file_dialog(owner, title, filt, initial="", save=False, default_name="", default_ext=""):
    """Windows 'Open' (or 'Save as' with save=True) dialog. -> path or ''."""
    if not IS_WIN:
        return ""
    from ctypes import wintypes as w

    class OFN(ctypes.Structure):
        _fields_ = [("lStructSize", w.DWORD), ("hwndOwner", w.HWND), ("hInstance", w.HINSTANCE),
                    ("lpstrFilter", w.LPCWSTR), ("lpstrCustomFilter", w.LPWSTR), ("nMaxCustFilter", w.DWORD),
                    ("nFilterIndex", w.DWORD), ("lpstrFile", w.LPWSTR), ("nMaxFile", w.DWORD),
                    ("lpstrFileTitle", w.LPWSTR), ("nMaxFileTitle", w.DWORD), ("lpstrInitialDir", w.LPCWSTR),
                    ("lpstrTitle", w.LPCWSTR), ("Flags", w.DWORD), ("nFileOffset", w.WORD),
                    ("nFileExtension", w.WORD), ("lpstrDefExt", w.LPCWSTR), ("lCustData", w.LPARAM),
                    ("lpfnHook", ctypes.c_void_p), ("lpTemplateName", w.LPCWSTR), ("pvReserved", ctypes.c_void_p),
                    ("dwReserved", w.DWORD), ("FlagsEx", w.DWORD)]

    buf = ctypes.create_unicode_buffer(default_name, 1024) if default_name else ctypes.create_unicode_buffer(1024)
    o = OFN()
    o.lStructSize = ctypes.sizeof(OFN)
    o.hwndOwner = owner
    o.lpstrFilter = filt
    o.lpstrFile = ctypes.cast(buf, w.LPWSTR)
    o.nMaxFile = 1024
    o.lpstrTitle = title
    o.lpstrInitialDir = initial or None
    o.Flags = (0x00000002 | 0x00000800 | 0x00080000 | 0x00000008) if save else \
        (0x00001000 | 0x00000800 | 0x00080000 | 0x00000008)
    o.lpstrDefExt = default_ext or None
    try:
        dlg = ctypes.windll.comdlg32
        ok = (dlg.GetSaveFileNameW if save else dlg.GetOpenFileNameW)(ctypes.byref(o))
    except Exception:
        return ""
    return buf.value if ok else ""


def snapshot_game():
    """One picture of the game window's whole client area -> (RGB numpy array or None, reason when None).
    With the game in front the screen itself is copied (what the overlay already relies on); otherwise the game
    window is asked to paint itself, so our own windows can never be in the picture. Memory only, never saved."""
    if not IS_WIN:
        return None, "only on Windows"
    try:
        import numpy as np
        from ctypes import wintypes as w
        u = ctypes.WinDLL("user32", use_last_error=True)
        g = ctypes.WinDLL("gdi32", use_last_error=True)
        u.GetForegroundWindow.restype = ctypes.c_void_p
        fg = u.GetForegroundWindow()
        hwnd = fg if window_is_game(fg) else None
        if hwnd is None:
            found = []
            ENUM = ctypes.WINFUNCTYPE(w.BOOL, ctypes.c_void_p, ctypes.c_void_p)

            def cb(h, _lp):
                if u.IsWindowVisible(ctypes.c_void_p(h)) and window_is_game(h):
                    found.append(h)
                return True
            u.EnumWindows(ENUM(cb), 0)
            hwnd = found[0] if found else None
        if hwnd is None:
            return None, "the game is not running"
        hw = ctypes.c_void_p(hwnd)
        if u.IsIconic(hw):
            return None, "the game is minimized"
        rc, pt = w.RECT(), w.POINT(0, 0)
        u.GetClientRect(hw, ctypes.byref(rc))
        u.ClientToScreen(hw, ctypes.byref(pt))
        cw, ch = rc.right - rc.left, rc.bottom - rc.top
        if cw < 64 or ch < 64 or cw * ch > 8192 * 4608:
            return None, "the game window has no usable size"

        class BIH(ctypes.Structure):
            _fields_ = [("biSize", w.DWORD), ("biWidth", w.LONG), ("biHeight", w.LONG), ("biPlanes", w.WORD),
                        ("biBitCount", w.WORD), ("biCompression", w.DWORD), ("biSizeImage", w.DWORD),
                        ("biXPelsPerMeter", w.LONG), ("biYPelsPerMeter", w.LONG), ("biClrUsed", w.DWORD),
                        ("biClrImportant", w.DWORD)]

        u.GetDC.restype = ctypes.c_void_p
        u.GetDC.argtypes = [ctypes.c_void_p]
        u.ReleaseDC.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        u.PrintWindow.argtypes = [ctypes.c_void_p, ctypes.c_void_p, w.UINT]
        g.CreateCompatibleDC.restype = ctypes.c_void_p
        g.CreateCompatibleDC.argtypes = [ctypes.c_void_p]
        g.CreateCompatibleBitmap.restype = ctypes.c_void_p
        g.CreateCompatibleBitmap.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
        g.SelectObject.restype = ctypes.c_void_p
        g.SelectObject.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        g.BitBlt.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                             ctypes.c_void_p, ctypes.c_int, ctypes.c_int, w.DWORD]
        g.GetDIBits.argtypes = [ctypes.c_void_p, ctypes.c_void_p, w.UINT, w.UINT, ctypes.c_void_p,
                                ctypes.c_void_p, w.UINT]
        g.DeleteObject.argtypes = [ctypes.c_void_p]
        g.DeleteDC.argtypes = [ctypes.c_void_p]
        sdc = u.GetDC(None)
        mdc = g.CreateCompatibleDC(sdc)
        bmp = g.CreateCompatibleBitmap(sdc, cw, ch)
        old = g.SelectObject(mdc, bmp)
        out, why = None, "the capture failed"
        try:
            if hwnd == fg:
                # plain SRCCOPY (no CAPTUREBLT): layered windows, like our own overlay, are left out
                ok = g.BitBlt(mdc, 0, 0, cw, ch, sdc, pt.x, pt.y, 0x00CC0020)
            else:
                ok = u.PrintWindow(hw, mdc, 0x1 | 0x2)          # client area only | render full content
            if ok:
                bi = BIH(ctypes.sizeof(BIH), cw, -ch, 1, 32, 0, 0, 0, 0, 0, 0)
                buf = (ctypes.c_ubyte * (cw * ch * 4))()
                if g.GetDIBits(mdc, bmp, 0, ch, buf, ctypes.byref(bi), 0):
                    arr = np.frombuffer(buf, np.uint8).reshape(ch, cw, 4)
                    if arr[::8, ::8, :3].max() < 6:
                        why = "the game window gave a black picture (try borderless / windowed mode)"
                    else:
                        out = np.ascontiguousarray(arr[..., 2::-1])         # BGRA -> RGB
        finally:
            g.SelectObject(mdc, old)
            g.DeleteObject(bmp)
            g.DeleteDC(mdc)
            u.ReleaseDC(None, sdc)
        return (out, "") if out is not None else (None, why)
    except Exception as e:
        return None, "capture error: %s" % (str(e) or e.__class__.__name__)


def choose_color_dialog(owner, rgb):
    """Windows colour dialog. -> (r,g,b) or None."""
    if not IS_WIN:
        return None
    from ctypes import wintypes as w

    class CC(ctypes.Structure):
        _fields_ = [("lStructSize", w.DWORD), ("hwndOwner", w.HWND), ("hInstance", w.HWND),
                    ("rgbResult", w.DWORD), ("lpCustColors", ctypes.POINTER(w.DWORD)), ("Flags", w.DWORD),
                    ("lCustData", w.LPARAM), ("lpfnHook", ctypes.c_void_p), ("lpTemplateName", w.LPCWSTR)]

    custom = (w.DWORD * 16)(*([0x00FFFFFF] * 16))
    c = CC()
    c.lStructSize = ctypes.sizeof(CC)
    c.hwndOwner = owner
    c.rgbResult = rgb[0] | (rgb[1] << 8) | (rgb[2] << 16)
    c.lpCustColors = custom
    c.Flags = 0x1 | 0x2
    try:
        if ctypes.windll.comdlg32.ChooseColorW(ctypes.byref(c)):
            v = c.rgbResult
            return (v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF)
    except Exception:
        pass
    return None


def scan_pressed_key():
    """The first keyboard key currently held (a VK from VK_NAMES), else 0."""
    if not IS_WIN:
        return 0
    gas = ctypes.windll.user32.GetAsyncKeyState
    for vk in VK_NAMES:
        if vk in (0x05, 0x06, 0x1B):
            continue
        if gas(vk) & 0x8000:
            return vk
    return 0


def esc_down():
    return IS_WIN and bool(ctypes.windll.user32.GetAsyncKeyState(0x1B) & 0x8000)


_pid_cache = {}
_pid_cache_t = 0.0


def window_is_game(hwnd):
    """True when the window belongs to the game process (BrgGame-Steam.exe)."""
    global _pid_cache_t
    if not (IS_WIN and hwnd):
        return False
    try:
        from ctypes import wintypes as w
        u = ctypes.WinDLL("user32", use_last_error=True)
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        u.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(w.DWORD)]
        k.OpenProcess.restype = ctypes.c_void_p
        k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
        k.QueryFullProcessImageNameW.argtypes = [ctypes.c_void_p, w.DWORD, w.LPWSTR, ctypes.POINTER(w.DWORD)]
        k.CloseHandle.argtypes = [ctypes.c_void_p]
        pid = w.DWORD()
        u.GetWindowThreadProcessId(ctypes.c_void_p(hwnd), ctypes.byref(pid))
        now = time.time()
        if now - _pid_cache_t > 10:
            _pid_cache.clear()
            _pid_cache_t = now
        r = _pid_cache.get(pid.value)
        if r is None:
            r = False
            h = k.OpenProcess(0x1000, False, pid.value)
            if h:
                buf = ctypes.create_unicode_buffer(1024)
                n = w.DWORD(1024)
                if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                    r = os.path.basename(buf.value).lower() == GAME_EXE
                k.CloseHandle(h)
            _pid_cache[pid.value] = r
        return r
    except Exception:
        return False


def ui_scale():
    try:
        return min(3.0, max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96))
    except Exception:
        return 1.0


# ----------------------------------------------------------------------------- UI

W, H = 600, 600     # logical size of the window (the popups cover all of it)

C_LABEL = (200, 200, 200)
C_LABEL_DIM = (150, 150, 150)
C_TEXT = (226, 226, 226)
C_INPUT_FILL = (3, 3, 3)
C_INPUT_LINE = (51, 51, 51)
C_INPUT_TEXT = (204, 204, 206)
C_BTN = (24, 24, 28)
C_BTN_HOT = (40, 40, 46)
C_BTN_DOWN = (16, 16, 19)
C_BTN_LINE = (68, 68, 76)
C_OFF_TEXT = (92, 92, 98)
C_OFF_LINE = (44, 44, 48)
C_SEP = (35, 35, 35)
C_RED = (63, 27, 27)
C_RED_HOT = (94, 38, 38)
C_SEL = (70, 110, 190)


class TextBox:
    """Single-line input: caret, mouse/shift selection, Ctrl+A/C/V/X. Applies on Enter or when it loses focus."""

    def __init__(self, ui, rect, default, parse, fmt, commit, align_left=False, font="f_in"):
        self.font_name = font
        self.ui, self.rect = ui, rect
        self.default, self.parse, self.fmt, self.commit = default, parse, fmt, commit
        self.align_left = align_left
        self.value = default
        self.text = fmt(default)
        self.focused = False
        self.caret = 0
        self.anchor = None
        self.drag = False

    def set_value(self, v):
        self.value = v
        if not self.focused:
            self.text = self.fmt(v)

    def sel(self):
        if self.anchor is None or self.anchor == self.caret:
            return None
        return min(self.anchor, self.caret), max(self.anchor, self.caret)

    def focus(self):
        if not self.focused:
            self.focused = True
            self.ui.focus = self
            self.caret, self.anchor = len(self.text), 0
            try:
                pygame.key.start_text_input()
            except Exception:
                pass

    def blur(self, revert=False):
        if not self.focused:
            return
        self.focused = False
        if self.ui.focus is self:
            self.ui.focus = None
        self.anchor = None
        if revert:
            self.text = self.fmt(self.value)
            return
        v = self.parse(self.text)
        if v is None:
            v = self.default
        self.value = v
        self.text = self.fmt(v)
        self.commit(v)

    def _caret_at(self, x):
        f = getattr(self.ui, self.font_name)
        px = x - (self.rect.x + 8)
        best, bd = 0, 1e9
        for i in range(len(self.text) + 1):
            d = abs(f.size(self.text[:i])[0] - px)
            if d < bd:
                best, bd = i, d
        return best

    def mouse_down(self, pos):
        self.focus()
        self.caret = self._caret_at(pos[0])
        self.anchor = self.caret
        self.drag = True

    def mouse_move(self, pos):
        if self.drag:
            self.caret = self._caret_at(pos[0])

    def mouse_up(self):
        self.drag = False

    def _replace(self, s):
        sel = self.sel()
        if sel:
            self.text = self.text[:sel[0]] + self.text[sel[1]:]
            self.caret = sel[0]
        self.text = self.text[:self.caret] + s + self.text[self.caret:]
        self.caret += len(s)
        self.anchor = None

    def key(self, ev):
        k, mods = ev.key, ev.mod
        ctrl, shift = bool(mods & pygame.KMOD_CTRL), bool(mods & pygame.KMOD_SHIFT)
        if k in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.blur()
        elif k == pygame.K_ESCAPE:
            self.blur(revert=True)
        elif ctrl and k == pygame.K_a:
            self.anchor, self.caret = 0, len(self.text)
        elif ctrl and k in (pygame.K_c, pygame.K_x):
            sel = self.sel()
            if sel:
                self.ui.clip_put(self.text[sel[0]:sel[1]])
                if k == pygame.K_x:
                    self._replace("")
        elif ctrl and k == pygame.K_v:
            t = self.ui.clip_get()
            if t:
                self._replace(t.replace("\r", "").replace("\n", " ")[:64])
        elif k == pygame.K_BACKSPACE:
            if self.sel():
                self._replace("")
            elif self.caret > 0:
                self.text = self.text[:self.caret - 1] + self.text[self.caret:]
                self.caret -= 1
        elif k == pygame.K_DELETE:
            if self.sel():
                self._replace("")
            else:
                self.text = self.text[:self.caret] + self.text[self.caret + 1:]
        elif k in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_HOME, pygame.K_END):
            if shift and self.anchor is None:
                self.anchor = self.caret
            if not shift:
                sel = self.sel()
                if sel and k in (pygame.K_LEFT, pygame.K_RIGHT):
                    self.caret = sel[0] if k == pygame.K_LEFT else sel[1]
                    self.anchor = None
                    return
                self.anchor = None
            if k == pygame.K_LEFT:
                self.caret = max(0, self.caret - 1)
            elif k == pygame.K_RIGHT:
                self.caret = min(len(self.text), self.caret + 1)
            elif k == pygame.K_HOME:
                self.caret = 0
            else:
                self.caret = len(self.text)

    def textinput(self, s):
        s = "".join(c for c in s if c.isprintable())
        if s and len(self.text) + len(s) <= 64:
            self._replace(s)

    def draw(self, scr, font):
        pygame.draw.rect(scr, C_INPUT_FILL, self.rect)
        pygame.draw.rect(scr, (110, 110, 120) if self.focused else C_INPUT_LINE, self.rect, 1)
        img = font.render(self.text, True, C_INPUT_TEXT)
        x = self.rect.x + 8
        if not self.align_left and img.get_width() + 16 <= self.rect.w and not self.focused:
            x = self.rect.centerx - img.get_width() // 2
        clip = scr.get_clip()
        scr.set_clip(self.rect.inflate(-4, -2))
        y = self.rect.centery - img.get_height() // 2
        if self.focused:
            sel = self.sel()
            if sel:
                x0 = x + font.size(self.text[:sel[0]])[0]
                x1 = x + font.size(self.text[:sel[1]])[0]
                pygame.draw.rect(scr, C_SEL, (x0, self.rect.y + 4, x1 - x0, self.rect.h - 8))
        scr.blit(img, (x, y))
        if self.focused and (pygame.time.get_ticks() // 500) % 2 == 0:
            cx = x + font.size(self.text[:self.caret])[0]
            pygame.draw.line(scr, C_INPUT_TEXT, (cx, self.rect.y + 5), (cx, self.rect.bottom - 6))
        scr.set_clip(clip)


def parse_float(lo, hi):
    def p(t):
        try:
            v = float(t.strip().replace(",", "."))
        except ValueError:
            return None
        if v != v or v < lo or v > hi:
            return None
        return v
    return p


def parse_int(lo, hi):
    def p(t):
        try:
            v = float(t.strip())
        except ValueError:
            return None
        if v != v or v != int(v) or v < lo or v > hi:
            return None
        return int(v)
    return p


def fmt_num(v):
    return ("%g" % v)


def parse_rgb_strict(t):
    """'r,g,b' (or #hex) -> tuple, or None when it is not a colour."""
    if not isinstance(t, str) or not t.strip():
        return None
    r = parse_rgb(t, None)
    return r


class CatalogMixin:
    """Outer / Center catalog popups of ReticleUI: multi-select (one image per folder), a Focus checkbox per
    folder, and the options of the focused folder (kept in that folder's Section_configs.json)."""

    CELL, GAP, HEAD, ROW = 64, 8, 28, 24
    SLIDER_MAX = {"rotate_dupe": 359, "rotate_all": 359, "spread": 100, "rotate": 359, "displace_x": 100,
                  "displace_y": 100, "opacity": 100, "size": 100, "stretch_x": 100, "stretch_y": 100}
    NEG_KEYS = ("spread", "rotate", "size", "displace_x", "displace_y", "stretch_x", "stretch_y")      # slider 0-100 + a "neg." checkbox
    # (key, label, kind of input)
    ROWS = {
        "outer": [("dupe", "Dupe", "int"), ("rotate_dupe", "Rotate Dupe", "rot"), ("rotate_all", "Rotate All", "rot"),
                  ("spread", "Spread Dupe", "neg"), ("color", "Color", "color"), ("opacity", "Opacity %", "opacity"),
                  ("size", "Size px", "neg"), ("stretch_x", "Stretch X %", "neg"), ("stretch_y", "Stretch Y %", "neg")],
        "center": [("color", "Color", "color"), ("opacity", "Opacity %", "opacity"),
                   ("size", "Size px", "neg"), ("rotate", "Rotate", "neg"), ("displace_x", "Displace X", "neg"), ("displace_y", "Displace Y", "neg"),
                   ("stretch_x", "Stretch X %", "neg"), ("stretch_y", "Stretch Y %", "neg")],
    }

    def open_catalog(self, kind):
        ensure_dirs()
        self.sel = prune_selected(self.sel)
        secs = kind_sections(kind)
        if not secs:
            self.post("No reticle images found in the %s folder." % os.path.basename(KIND_DIRS[kind]))
            return
        c = self.cat_rect = pygame.Rect(8, 6, W - 16, H - 12)
        rows = self.ROWS[kind]
        btn_y = c.bottom - 42
        opt_top = btn_y - 8 - len(rows) * self.ROW
        grid_top = c.y + 36
        inner = pygame.Rect(c.x + 14, grid_top, c.w - 28, max(40, opt_top - 8 - grid_top))
        cat = {"kind": kind, "sections": secs, "scroll": 0, "max": 0, "inner": inner,
               "sel": {os.path.dirname(rel): rel for rel in self.sel[kind]},
               "cfgs": {fid: load_section_cfg(fid) for fid, _l, _f in secs},
               "opts": {}, "focus": None, "focus_rects": {}, "tbs": {}, "prev_key": None, "prev": None, "drag": None,
               "reset_rect": pygame.Rect(c.right - 14 - 116 * 2 - 10 - 124 - 8 - 120, btn_y, 120, 30),
               "grid_rect": pygame.Rect(c.right - 14 - 116 * 2 - 10 - 124, btn_y + 8, 14, 14),
               "accept": pygame.Rect(c.right - 14 - 116 * 2 - 10, btn_y, 116, 30),
               "cancel": pygame.Rect(c.right - 14 - 116, btn_y, 116, 30),
               "prev_rect": pygame.Rect(c.right - 14 - 73, opt_top + 11, 62, 62), "opt_top": opt_top,
               "copy_rect": pygame.Rect(c.right - 14 - 120, opt_top + 84 + 8, 120, 24),
               "paste_rect": pygame.Rect(c.right - 14 - 120, opt_top + 84 + 8 + 28, 120, 24),
               "clip": None,        # copied options; lives only as long as this popup (dropped on Accept / Cancel / exit)
               "sliders": {}, "checks": {}, "swatch": None}
        parsers = {"int": parse_int(1, MAX_DUPE), "rot": parse_int(0, 359), "neg": parse_float(-100, 100),
                   "color": parse_rgb_strict, "opacity": parse_int(0, 100)}
        for i, (key, _label, typ) in enumerate(rows):
            y = opt_top + i * self.ROW
            wide = 100 if typ == "color" else 64
            parse = (parse_int(-359, 359) if key == "rotate" else parse_int(-100, 100) if key == "size"
                     else parse_int(-100, 500) if key.startswith("stretch") else parsers[typ])
            tb = TextBox(self, pygame.Rect(c.x + 150, y, wide, 22), DEFAULTS[kind][key], parse,
                         rgb_text if typ == "color" else str if typ in ("int", "rot", "opacity") else fmt_num,
                         lambda v, k=key: self._pop_set(k, v), font="f_pin")
            cat["tbs"][key] = tb
            if typ == "color":
                cat["swatch"] = pygame.Rect(c.x + 150 + wide + 10, y, 22, 22)
            if key in self.SLIDER_MAX:
                cat["sliders"][key] = pygame.Rect(c.x + 228, y, 130, 22)
            if typ == "rot":
                cat["checks"][key + "_inv"] = pygame.Rect(c.x + 376, y + 3, 16, 16)
            elif typ == "neg":
                cat["checks"][key + "_neg"] = pygame.Rect(c.x + 376, y + 3, 16, 16)
        self.catalog = cat
        start = next((os.path.dirname(r) for r in self.sel[kind] if os.path.dirname(r) in cat["cfgs"]), secs[0][0])
        self._set_focus(start)
        self.dropdown = None

    def _set_focus(self, fid):
        """Only one catalog section is on focus: the options below edit that folder's own config."""
        c = self.catalog
        if self.focus:
            self.focus.blur()
        c["focus"] = fid
        o = c["opts"] = c["cfgs"][fid]
        for key in self.NEG_KEYS:
            if key in o:
                o[key + "_neg"] = o[key] < 0
        for key, tb in c["tbs"].items():
            tb.set_value(o[key])

    def pop_textboxes(self):
        return list(self.catalog["tbs"].values()) if self.catalog else []

    def active_tbs(self):
        return self.pop_textboxes() if self.catalog else self.textboxes

    def _pop_set(self, key, v):
        o = self.catalog["opts"]
        o[key] = v
        if key in self.NEG_KEYS and v:
            o[key + "_neg"] = v < 0

    def _pop_check(self, name):
        o = self.catalog["opts"]
        o[name] = not o.get(name, False)
        key = name[:-4]
        if name.endswith("_neg") and key in self.NEG_KEYS:
            o[key] = -abs(o[key]) if o[name] else abs(o[key])
            tb = self.catalog["tbs"][key]
            tb.value, tb.text = o[key], fmt_num(o[key])

    def _pop_slider(self, key, x):
        c = self.catalog
        r = c["sliders"][key]
        o = c["opts"]
        v = int(round(clamp((x - r.x) / float(r.w), 0, 1) * self.SLIDER_MAX[key]))
        if key in self.NEG_KEYS and o.get(key + "_neg"):
            v = -v
        o[key] = v
        tb = c["tbs"][key]
        tb.value, tb.text = v, fmt_num(v)

    def _catalog_layout(self):
        c = self.catalog
        inner = c["inner"]
        cols = max(1, (inner.w - 14 + self.GAP) // (self.CELL + self.GAP))
        y, cells, heads = 0, [], []
        for fid, label, files in c["sections"]:
            heads.append((label or os.path.basename(KIND_DIRS[c["kind"]]).lstrip("_"), y, fid))
            y += self.HEAD
            for i, p in enumerate(files):
                r, col = divmod(i, cols)
                cells.append((fid, p, pygame.Rect(inner.x + col * (self.CELL + self.GAP),
                                                  y + r * (self.CELL + self.GAP), self.CELL, self.CELL)))
            rows = (len(files) + cols - 1) // cols
            y += rows * (self.CELL + self.GAP) + 2
        c["cells"], c["heads"] = cells, heads
        c["max"] = max(0, y - inner.h)
        c["scroll"] = clamp(c["scroll"], 0, c["max"])

    def _accept_catalog(self):
        c = self.catalog
        kind = c["kind"]
        if self.focus:
            self.focus.blur()
        picks = []
        for fid, _label, files in c["sections"]:
            rel = c["sel"].get(fid)
            if rel:
                picks.append(rel)
        self.sel[kind] = picks
        self.cfg.set(selected={k: list(v) for k, v in self.sel.items()})
        for fid, o in c["cfgs"].items():
            save_section_cfg(fid, o)
        self.catalog = None
        self.scale = max(self.scale, self.scale_min())      # the picks changed: keep the global scale valid
        self.tb_scale.set_value(self.scale)

    def _cancel_catalog(self):
        if self.focus:
            self.focus.blur()
        self.catalog = None

    def _catalog_click(self, pos):
        c = self.catalog
        if c["reset_rect"].collidepoint(pos):
            c["cfgs"][c["focus"]] = norm_section(c["kind"], None)      # defaults; saved on Accept like any edit
            self._set_focus(c["focus"])
            return
        if (c["copy_rect"].collidepoint(pos) or c["paste_rect"].collidepoint(pos)) and self.focus:
            self.focus.blur()          # commit a half-typed value before copying
        if c["copy_rect"].collidepoint(pos):
            c["clip"] = dict(c["opts"])
            return
        if c["paste_rect"].collidepoint(pos):
            if c["clip"] is not None:
                c["cfgs"][c["focus"]] = norm_section(c["kind"], c["clip"])      # saved on Accept like any edit
                c["clip"] = None                                                # one paste per copy
                self._set_focus(c["focus"])
            return
        if c["grid_rect"].inflate(100, 8).collidepoint(pos):
            self.cfg.set(hide_grid=not self.cfg.get("hide_grid"))
            return
        if c["accept"].collidepoint(pos):
            self._accept_catalog()
            return
        if c["cancel"].collidepoint(pos):
            self._cancel_catalog()
            return
        for fid, r in c.get("focus_rects", {}).items():
            if r.inflate(40, 6).collidepoint(pos) and c["inner"].collidepoint(pos):
                self._set_focus(fid)
                return
        hit_tb = next((tb for tb in c["tbs"].values() if tb.rect.collidepoint(pos)), None)
        if self.focus and self.focus is not hit_tb:
            self.focus.blur()
        if hit_tb:
            hit_tb.mouse_down(pos)
            return
        if c["swatch"] and c["swatch"].collidepoint(pos):
            self.pick_color(c["tbs"]["color"])
            return
        for key, r in c["sliders"].items():
            if r.inflate(0, 4).collidepoint(pos):
                c["drag"] = key
                self._pop_slider(key, pos[0])
                return
        for name, r in c["checks"].items():
            if r.inflate(40, 4).collidepoint(pos):
                self._pop_check(name)
                return
        self._catalog_layout()
        inner, sc = c["inner"], c["scroll"]
        if inner.collidepoint(pos):
            if pos[0] >= inner.right - 10 and c["max"] > 0:
                c["scroll"] = int(clamp((pos[1] - inner.y) / float(max(1, inner.h)), 0, 1) * c["max"])
                return
            for fid, p, r in c["cells"]:
                if r.move(0, inner.y - sc).collidepoint(pos):
                    rel = rel_of(p)
                    # picking an image focuses its section; clicking the picked one of a section that is
                    # not on focus only moves the focus, clicking it again deselects
                    if c["focus"] != fid:
                        self._set_focus(fid)
                        c["sel"][fid] = rel
                    elif c["sel"].get(fid) == rel:
                        del c["sel"][fid]
                    else:
                        c["sel"][fid] = rel
                    return

    def _guide_grid(self, scr, r):
        """Faint 3 x 3 line grid (centre line + two more each way) over a preview box."""
        key = (r.w, r.h)
        s = self._grid_cache.get(key) if hasattr(self, "_grid_cache") else None
        if s is None:
            if not hasattr(self, "_grid_cache"):
                self._grid_cache = {}
            s = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
            col = (150, 150, 160, 55)
            for k in (1, 2, 3):
                x, y = r.w * k // 4, r.h * k // 4
                pygame.draw.line(s, col, (x, 0), (x, r.h - 1), 1)
                pygame.draw.line(s, col, (0, y), (r.w - 1, y), 1)
            self._grid_cache[key] = s
        scr.blit(s, r.topleft)

    def _prev_surface(self, kind, picks, cfgs):
        """Popup preview: this kind's picks with the options being edited (not affected by the global Scale), at
        real size and cropped to the reticle cell, so a Size change grows or shrinks it inside a fixed frame."""
        outer, center = (picks, []) if kind == "outer" else ([], picks)
        im = compose(outer, center, cfgs)
        if im is None:
            return None
        return self._crop_surface(im)

    def _draw_catalog(self, mouse):
        c = self.catalog
        scr = self.canvas
        kind = c["kind"]
        grid_on = not self.cfg.get("hide_grid")
        self._catalog_layout()
        dim = pygame.Surface((W, H), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 170))
        scr.blit(dim, (0, 0))
        pygame.draw.rect(scr, (14, 14, 16), self.cat_rect)
        pygame.draw.rect(scr, (110, 110, 118), self.cat_rect, 1)
        self.draw_text(self.f_lbl, "Select outer sights" if kind == "outer" else "Select center sights", C_TEXT,
                       self.cat_rect.x + 14, self.cat_rect.y + 16)
        self.draw_text(self.f_small, "One per folder - click again to deselect", C_LABEL_DIM,
                       self.cat_rect.right - 14, self.cat_rect.y + 16, "r")
        inner, sc = c["inner"], c["scroll"]
        clip = scr.get_clip()
        scr.set_clip(inner)
        loaded = 0
        c["focus_rects"] = {}
        for label, y, fid in c["heads"]:
            yy = inner.y + y - sc
            nm = label.lstrip("_") or label
            self.draw_text(self.f_btn, nm, C_LABEL, inner.x + 2, yy + 11)
            cb = pygame.Rect(inner.x + self.f_btn.size(nm)[0] + 14, yy + 4, 14, 14)
            on_ = c["focus"] == fid
            pygame.draw.rect(scr, (245, 245, 245) if on_ else C_INPUT_FILL, cb)
            pygame.draw.rect(scr, (210, 210, 210), cb, 1)
            if on_:
                pygame.draw.lines(scr, (20, 20, 20), False, [(cb.x + 3, cb.centery), (cb.x + 6, cb.bottom - 4),
                                                            (cb.right - 3, cb.y + 3)], 2)
            tw2 = self.f_small.size("Focus")[0]
            self.draw_text(self.f_small, "Focus", C_LABEL, cb.right + 6, cb.centery)
            c["focus_rects"][fid] = pygame.Rect(cb.x, cb.y, 14 + 6 + tw2, 14)
            pygame.draw.line(scr, (70, 70, 76), (cb.right + 6 + tw2 + 8, yy + 11), (inner.right - 16, yy + 11), 1)
        for fid, p, r in c["cells"]:
            rr = r.move(0, inner.y - sc)
            if rr.bottom < inner.y or rr.top > inner.bottom:
                continue
            hot = rr.collidepoint(mouse) and inner.collidepoint(mouse)
            on = c["sel"].get(fid) == rel_of(p)
            pygame.draw.rect(scr, (0, 0, 0), rr)
            bx = self.CELL - 10
            if (p, bx) in self.thumbs or loaded < 6:
                if (p, bx) not in self.thumbs:
                    loaded += 1
                t = self.thumb(p, bx)
                scr.blit(t, t.get_rect(center=rr.center))
            if grid_on:
                self._guide_grid(scr, rr.inflate(-4, -4))
            border = (240, 240, 240) if on else ((150, 150, 160) if hot else (50, 50, 56))
            pygame.draw.rect(scr, border, rr, 3 if on else (2 if hot else 1))
            if hot:
                self.draw_text(self.f_small, os.path.splitext(os.path.basename(p))[0], C_TEXT, rr.centerx,
                               rr.bottom - 9, "c")
        scr.set_clip(clip)
        if c["max"] > 0:
            track = pygame.Rect(inner.right - 8, inner.y, 6, inner.h)
            pygame.draw.rect(scr, (30, 30, 34), track)
            kh = max(24, int(track.h * inner.h / (inner.h + c["max"])))
            ky = track.y + int((track.h - kh) * sc / c["max"])
            pygame.draw.rect(scr, (130, 130, 138), (track.x, ky, track.w, kh))
        # options of the focused folder
        x0 = self.cat_rect.x + 16
        ly = c["opt_top"] - 5
        pygame.draw.line(scr, (60, 60, 64), (x0, ly), (self.cat_rect.right - 16, ly), 1)
        fl = next((l for f, l, _fl in c["sections"] if f == c["focus"]), "")
        title = "Options for: " + ((fl or os.path.basename(KIND_DIRS[kind])).lstrip("_") or fl)
        tw = self.f_small.size(title)[0]
        pygame.draw.rect(scr, (14, 14, 16), (x0 - 2, ly - 8, tw + 10, 16))
        self.draw_text(self.f_small, title, C_TEXT, x0 + 2, ly)
        o = c["opts"]
        for key, label, typ in self.ROWS[kind]:
            tb = c["tbs"][key]
            self.draw_text(self.f_small, label, C_LABEL, x0, tb.rect.centery)
            tb.draw(scr, self.f_pin)
            if key == "color" and c["swatch"]:
                sw = c["swatch"]
                col = parse_rgb_strict(tb.text) or tb.value
                pygame.draw.circle(scr, col, sw.center, 10)
                pygame.draw.circle(scr, (210, 210, 210), sw.center, 10, 1)
            if key in c["sliders"]:
                r = c["sliders"][key]
                pygame.draw.line(scr, (190, 190, 190), (r.x, r.centery), (r.right, r.centery), 2)
                top = self.SLIDER_MAX[key]
                kx = r.x + int(r.w * clamp(abs(o[key]), 0, top) / float(top))
                pygame.draw.circle(scr, (240, 240, 240), (kx, r.centery), 6)
            for name, r in c["checks"].items():
                if name != key + "_inv" and name != key + "_neg":
                    continue
                pygame.draw.rect(scr, (245, 245, 245) if o.get(name) else C_INPUT_FILL, r)
                pygame.draw.rect(scr, (210, 210, 210), r, 1)
                if o.get(name):
                    pygame.draw.lines(scr, (20, 20, 20), False, [(r.x + 3, r.centery), (r.x + 7, r.bottom - 4),
                                                                (r.right - 3, r.y + 4)], 2)
                self.draw_text(self.f_small, name.split("_")[-1] + ".", C_LABEL, r.right + 5, r.centery)
        # live preview of this kind's picks with the options being edited
        pr = c["prev_rect"]
        pygame.draw.rect(scr, (0, 0, 0), pr, border_radius=6)
        pygame.draw.rect(scr, (60, 60, 64), pr, 1, border_radius=6)
        picks = [abs_of(rel) for rel in c["sel"].values()]
        key = (tuple(picks), repr(sorted((f, sorted(norm_section(kind, v).items())) for f, v in c["cfgs"].items())))
        if key != c["prev_key"]:
            c["prev_key"] = key
            try:
                c["prev"] = self._prev_surface(kind, picks, c["cfgs"])
            except Exception:
                c["prev"] = None
        if c["prev"] is not None:
            sq = pygame.Rect(0, 0, ART, ART)
            sq.center = pr.center
            clip = scr.get_clip()
            scr.set_clip(sq)
            scr.blit(c["prev"], c["prev"].get_rect(center=sq.center))
            scr.set_clip(clip)
        if grid_on:
            self._guide_grid(scr, pr.inflate(-4, -4))
        self.button(c["reset_rect"], "Reset focused", True, mouse, None)
        self.button(c["copy_rect"], "Copy", True, mouse, None)
        self.button(c["paste_rect"], "Paste", c["clip"] is not None, mouse, None)
        gr = c["grid_rect"]
        pygame.draw.rect(scr, C_INPUT_FILL if grid_on else (245, 245, 245), gr)
        pygame.draw.rect(scr, (210, 210, 210), gr, 1)
        if not grid_on:
            pygame.draw.lines(scr, (20, 20, 20), False, [(gr.x + 3, gr.centery), (gr.x + 6, gr.bottom - 4),
                                                        (gr.right - 3, gr.y + 3)], 2)
        self.draw_text(self.f_small, "disable grid", C_LABEL, gr.right + 6, gr.centery)
        self.button(c["accept"], "Accept", True, mouse, None)
        self.button(c["cancel"], "Cancel", True, mouse, None)