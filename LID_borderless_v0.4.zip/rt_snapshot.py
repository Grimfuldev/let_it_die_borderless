"""Take photo: a countdown over the game, then one picture of the game screen for the preview popup.

The user holds the aim button (the mouse / keyboard / joystick buttons chosen in the preview popup) in the game; once
it has been held for `snapshot_hold_seconds` the game window is copied and saved in _Current\\_InGameAim. Nothing is
searched for in that picture. Windows only (the module imports anywhere, the job does nothing elsewhere)."""
import ctypes
import threading
import time
from rt_core import IS_WIN, JOY_BITS, save_snapshot
from rt_widgets import snapshot_game, window_is_game
import numpy as np


def dpi_aware():
    """Must run before any window is created, or screen sizes come back scaled."""
    if not IS_WIN:
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


if IS_WIN:
    from ctypes import wintypes as wt

    V = ctypes.c_void_p
    WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, V, wt.UINT, wt.WPARAM, wt.LPARAM)
    ENUMPROC = ctypes.WINFUNCTYPE(wt.BOOL, V, wt.LPARAM)

    class WNDCLASSW(ctypes.Structure):
        _fields_ = [("style", wt.UINT), ("lpfnWndProc", WNDPROC), ("cbClsExtra", ctypes.c_int),
                    ("cbWndExtra", ctypes.c_int), ("hInstance", V), ("hIcon", V), ("hCursor", V),
                    ("hbrBackground", V), ("lpszMenuName", wt.LPCWSTR), ("lpszClassName", wt.LPCWSTR)]

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [("biSize", wt.DWORD), ("biWidth", wt.LONG), ("biHeight", wt.LONG), ("biPlanes", wt.WORD),
                    ("biBitCount", wt.WORD), ("biCompression", wt.DWORD), ("biSizeImage", wt.DWORD),
                    ("biXPelsPerMeter", wt.LONG), ("biYPelsPerMeter", wt.LONG), ("biClrUsed", wt.DWORD),
                    ("biClrImportant", wt.DWORD)]

    class BITMAPINFO(ctypes.Structure):
        _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wt.DWORD * 3)]

    class BLENDFUNCTION(ctypes.Structure):
        _fields_ = [("BlendOp", ctypes.c_ubyte), ("BlendFlags", ctypes.c_ubyte),
                    ("SourceConstantAlpha", ctypes.c_ubyte), ("AlphaFormat", ctypes.c_ubyte)]

    def _sig(fn, res, *args):
        fn.restype = res
        fn.argtypes = list(args)

    class XINPUT_GAMEPAD(ctypes.Structure):
        _fields_ = [("wButtons", wt.WORD), ("bLeftTrigger", ctypes.c_ubyte), ("bRightTrigger", ctypes.c_ubyte),
                    ("sThumbLX", ctypes.c_short), ("sThumbLY", ctypes.c_short),
                    ("sThumbRX", ctypes.c_short), ("sThumbRY", ctypes.c_short)]

    class XINPUT_STATE(ctypes.Structure):
        _fields_ = [("dwPacketNumber", wt.DWORD), ("Gamepad", XINPUT_GAMEPAD)]

    class XInput:
        """Controller buttons through XInput; works whether or not any window of ours has focus."""

        def __init__(self):
            self.fn = None
            for name in ("xinput1_4.dll", "xinput1_3.dll", "xinput9_1_0.dll"):
                try:
                    self.fn = ctypes.WinDLL(name).XInputGetState
                    self.fn.argtypes = [wt.DWORD, ctypes.POINTER(XINPUT_STATE)]
                    self.fn.restype = wt.DWORD
                    break
                except (OSError, AttributeError):
                    self.fn = None
            self.slot, self.last_scan, self.st = None, 0.0, XINPUT_STATE()

        def read(self):
            """-> (buttons, left trigger, right trigger) or None when no controller answers."""
            if self.fn is None:
                return None
            now = time.perf_counter()
            if self.slot is not None and self.fn(self.slot, ctypes.byref(self.st)) == 0:
                g = self.st.Gamepad
                return g.wButtons, g.bLeftTrigger, g.bRightTrigger
            self.slot = None
            if now - self.last_scan < 2.0:
                return None
            self.last_scan = now
            for i in range(4):
                if self.fn(i, ctypes.byref(self.st)) == 0:
                    self.slot = i
                    g = self.st.Gamepad
                    return g.wButtons, g.bLeftTrigger, g.bRightTrigger
            return None

    class Banner:
        """White text over the game (a click-through layered window of its own)."""
        BW, BH = 1100, 56

        def __init__(self):
            from PIL import ImageFont
            self.u = u = ctypes.WinDLL("user32", use_last_error=True)
            self.g = g = ctypes.WinDLL("gdi32", use_last_error=True)
            k = ctypes.WinDLL("kernel32", use_last_error=True)
            _sig(u.DefWindowProcW, ctypes.c_ssize_t, V, wt.UINT, wt.WPARAM, wt.LPARAM)
            _sig(u.RegisterClassW, wt.ATOM, ctypes.POINTER(WNDCLASSW))
            _sig(u.CreateWindowExW, V, wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD, ctypes.c_int, ctypes.c_int,
                 ctypes.c_int, ctypes.c_int, V, V, V, V)
            _sig(u.DestroyWindow, wt.BOOL, V)
            _sig(u.ShowWindow, wt.BOOL, V, ctypes.c_int)
            _sig(u.SetWindowPos, wt.BOOL, V, V, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wt.UINT)
            _sig(u.GetDC, V, V)
            _sig(u.ReleaseDC, ctypes.c_int, V, V)
            _sig(u.UpdateLayeredWindow, wt.BOOL, V, V, ctypes.POINTER(wt.POINT), ctypes.POINTER(wt.SIZE), V,
                 ctypes.POINTER(wt.POINT), wt.DWORD, ctypes.POINTER(BLENDFUNCTION), wt.DWORD)
            _sig(g.CreateCompatibleDC, V, V)
            _sig(g.DeleteDC, wt.BOOL, V)
            _sig(g.DeleteObject, wt.BOOL, V)
            _sig(g.SelectObject, V, V, V)
            _sig(g.CreateDIBSection, V, V, ctypes.POINTER(BITMAPINFO), wt.UINT, ctypes.POINTER(V), V, wt.DWORD)
            _sig(k.GetModuleHandleW, V, wt.LPCWSTR)
            self._proc = WNDPROC(lambda h, m, w, l: u.DefWindowProcW(h, m, w, l))
            wc = WNDCLASSW()
            wc.lpfnWndProc = self._proc
            wc.hInstance = k.GetModuleHandleW(None)
            wc.lpszClassName = "LIDReticleSnapshotBanner"
            u.RegisterClassW(ctypes.byref(wc))
            # layered | transparent (click-through) | tool window | no activate | topmost
            self.hwnd = u.CreateWindowExW(0x80000 | 0x20 | 0x80 | 0x08000000 | 0x8, wc.lpszClassName, "LID Reticle Message",
                                          0x80000000, 0, 0, 1, 1, None, None, wc.hInstance, None)
            if not self.hwnd:
                raise ctypes.WinError(ctypes.get_last_error())
            self.screen_dc = u.GetDC(None)
            bi = BITMAPINFO()
            bi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            bi.bmiHeader.biWidth, bi.bmiHeader.biHeight = self.BW, -self.BH
            bi.bmiHeader.biPlanes, bi.bmiHeader.biBitCount = 1, 32
            bits = V()
            self.bmp = g.CreateDIBSection(self.screen_dc, ctypes.byref(bi), 0, ctypes.byref(bits), None, 0)
            self.dc = g.CreateCompatibleDC(self.screen_dc)
            g.SelectObject(self.dc, self.bmp)
            buf = (ctypes.c_ubyte * (self.BW * self.BH * 4)).from_address(bits.value)
            self.arr = np.frombuffer(buf, np.uint8).reshape(self.BH * self.BW, 4)
            self.key, self.visible = None, False
            self.font = None
            for name in ("segoeui.ttf", "arial.ttf"):
                try:
                    self.font = ImageFont.truetype(name, 30)
                    break
                except OSError:
                    pass
            if self.font is None:
                self.font = ImageFont.load_default()

        def show(self, text, rect):
            """rect = (left, top, width, height) of the game's client area in screen pixels."""
            from PIL import Image, ImageDraw
            x = rect[0] + rect[2] // 2 - self.BW // 2
            y = rect[1] + int(rect[3] * 0.14)
            key = (text, x, y)
            if key == self.key and self.visible:
                return
            self.key = key
            im = Image.new("RGBA", (self.BW, self.BH), (0, 0, 0, 0))
            ImageDraw.Draw(im).text((self.BW // 2, self.BH // 2), text, font=self.font, fill=(255, 255, 255, 255),
                                    anchor="mm", stroke_width=3, stroke_fill=(0, 0, 0, 255))
            a = np.asarray(im, np.float32)
            al = a[..., 3:4] / 255.0
            self.arr[:] = np.rint(np.concatenate([a[..., 2::-1] * al, a[..., 3:4]], -1)).astype(np.uint8).reshape(-1, 4)
            pt, sz, src = wt.POINT(int(x), int(y)), wt.SIZE(self.BW, self.BH), wt.POINT(0, 0)
            self.u.UpdateLayeredWindow(self.hwnd, None, ctypes.byref(pt), ctypes.byref(sz), self.dc,
                                       ctypes.byref(src), 0, ctypes.byref(BLENDFUNCTION(0, 0, 255, 1)), 2)
            if not self.visible:
                self.u.ShowWindow(self.hwnd, 4)
                self.u.SetWindowPos(self.hwnd, -1, 0, 0, 0, 0, 0x13)
                self.visible = True

        def hide(self):
            if self.visible:
                self.u.ShowWindow(self.hwnd, 0)
                self.visible = False
                self.key = None

        def close(self):
            self.hide()
            self.u.DestroyWindow(self.hwnd)
            self.g.DeleteDC(self.dc)
            self.g.DeleteObject(self.bmp)
            self.u.ReleaseDC(None, self.screen_dc)

    def pump():
        u = ctypes.windll.user32
        msg = wt.MSG()
        while u.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
            u.TranslateMessage(ctypes.byref(msg))
            u.DispatchMessageW(ctypes.byref(msg))

    def find_game_rect():
        """-> (hwnd, left, top, width, height of the client area) of the biggest visible game window, or None."""
        u = ctypes.WinDLL("user32", use_last_error=True)
        found = []

        def cb(hwnd, _lp):
            if u.IsWindowVisible(ctypes.c_void_p(hwnd)) and window_is_game(hwnd):
                found.append(hwnd)
            return True

        u.EnumWindows(ENUMPROC(cb), 0)
        best = None
        for hwnd in found:
            rc, pt = wt.RECT(), wt.POINT(0, 0)
            h = ctypes.c_void_p(hwnd)
            if u.GetClientRect(h, ctypes.byref(rc)) and u.ClientToScreen(h, ctypes.byref(pt)) \
                    and rc.right > 0 and rc.bottom > 0 and (best is None or rc.right * rc.bottom > best[3] * best[4]):
                best = (hwnd, pt.x, pt.y, rc.right, rc.bottom)
        return best

    def foreground():
        u = ctypes.windll.user32
        u.GetForegroundWindow.restype = ctypes.c_void_p
        return u.GetForegroundWindow()

    def key_down(vk):
        return bool(ctypes.windll.user32.GetAsyncKeyState(vk) & 0x8000)


class SnapshotJob(threading.Thread):
    """One Take photo request. Runs until the picture is taken, it fails, or cancel() is called."""

    def __init__(self, cfg, say, key):
        super().__init__(daemon=True, name="reticle-snapshot")
        self.cfg = cfg
        self.key = key                        # name of the photo (game resolution + screen resolution)
        self.say = say                        # say(text): status line of the UI
        self.stop_req = threading.Event()
        self.result = None                    # None while running, then "done" | "failed" | "cancelled"

    @property
    def running(self):
        return self.is_alive() and self.result is None

    def cancel(self):
        self.stop_req.set()

    def _held(self, v, xi):
        if v.mouse_vk and key_down(v.mouse_vk):
            return True
        if v.kb_vk and key_down(v.kb_vk):
            return True
        if v.joy:
            st = xi.read()
            if st:
                if v.joy == "lt":
                    return st[1] > 60
                if v.joy == "rt":
                    return st[2] > 60
                return bool(st[0] & JOY_BITS.get(v.joy, 0))
        return False

    def run(self):
        if not IS_WIN:
            self.say("Take photo only works on Windows.")
            self.result = "failed"
            return
        banner = None
        try:
            banner = Banner()
            self.result = self._loop(banner)
        except Exception as e:
            self.say("Take photo stopped: %s" % (str(e) or e.__class__.__name__))
            self.result = "failed"
        finally:
            if banner is not None:
                banner.close()
            if self.result is None:
                self.result = "failed"

    def _loop(self, banner):
        cfg = self.cfg
        v = cfg.values()
        xi = XInput()
        hold_start = None
        armed = False                           # a press only counts after the button was seen released in the game
        game, last_look, last_say = None, 0.0, ""
        self.say("Go to the game and hold your aim button for %g seconds to take the photo." % v.hold)
        while not self.stop_req.is_set():
            pump()
            now = time.perf_counter()
            if now - last_look > 0.3:
                last_look = now
                cfg.reload()
                v = cfg.values()
                game = find_game_rect()
            if not game:
                banner.hide()
                hold_start = None
                if last_say != "nogame":
                    last_say = "nogame"
                    self.say("Waiting for the game window...")
                time.sleep(0.1)
                continue
            if foreground() != game[0]:
                banner.hide()
                hold_start = None
                armed = False
                if last_say != "back":
                    last_say = "back"
                    self.say("Click into the game, then hold your aim button for %g seconds." % v.hold)
                time.sleep(0.05)
                continue
            rect = game[1:]
            held = self._held(v, xi)
            if not held:
                armed, hold_start = True, None
                banner.show("Hold Aim to take the photo  %.1fs" % v.hold, rect)
                last_say = "idle"
                time.sleep(0.02)
                continue
            if not armed:                       # the button was already down when the game came to the front
                banner.show("Release the aim button, then hold it", rect)
                time.sleep(0.02)
                continue
            if hold_start is None:
                hold_start = now
            left = v.hold - (now - hold_start)
            if left > 0:
                banner.show("Hold Aim to take the photo  %.1fs" % left, rect)
                time.sleep(0.02)
                continue
            banner.hide()
            time.sleep(0.12)                    # let the banner leave the screen before the picture is taken
            pic, why = snapshot_game()
            if pic is None:
                self.say("Could not take the photo: %s." % why)
                banner.show("Failed: %s" % why[:70], rect)
                time.sleep(2.5)
                return "failed"
            save_snapshot(pic, self.key)
            self.say("Photo taken (%d x %d)." % (pic.shape[1], pic.shape[0]))
            banner.show("Photo taken", rect)
            time.sleep(1.2)
            return "done"
        return "cancelled"