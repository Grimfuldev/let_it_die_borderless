"""Core: shared constants / Config, Steam + game files (the reticle baked into the HUD), and the reticle image pipeline (folders, Section_configs.json, compose, recolor, _Current)."""
import colorsys
import ctypes
import json
import math
import os
import random
import shutil
import struct
import sys
import threading
import time
from types import SimpleNamespace
import numpy as np


os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
sys.dont_write_bytecode = True

APP_TITLE = "Reticle Maker"
VERSION = "v0.4"
APP_ID = "Grimfuldev.LID.Borderless"
GAME_EXE = "brggame-steam.exe"
GAME_DIR_NAME = "LET IT DIE"

FROZEN = getattr(sys, "frozen", False)
HERE = os.path.dirname(os.path.abspath(sys.executable if FROZEN else __file__))
RES_DIR = getattr(sys, "_MEIPASS", HERE)
UI_ASSETS = os.path.join(RES_DIR, "UI_Assets")
CFG_PATH = os.path.join(HERE, "reticle_config.json")
RETICLES_DIR = os.path.join(HERE, "Reticles")
CURRENT_DIR = os.path.join(RETICLES_DIR, "_Current")
UPK_NAME = "UI_HUD_SF.upk"
BASE_NAME = "BrgGameBase.upk"
INI_NAME = "SteamPCRelease-BrgEngine.ini"      # the game rewrites it on every run; its original has to be put back
SNAP_DIR = os.path.join(CURRENT_DIR, "_InGameAim")      # the game picture of the preview (not a reticle)
SNAP_QUALITY = 30                    # lossy webp quality of the photos (they are only a background)
RES_CHANGED = "Current in-game resolution and/or computer resolution changed, new photo needed"
CLOSE_CANCEL_FILE = os.path.join(HERE, "borderless_cancel_close.flag")   # the Reticle window asks the borderless tool to stay
BORDERLESS_STATUS = os.path.join(HERE, "borderless_status.json")   # written by the borderless tool while it runs
IMG_EXT = (".webp", ".png")
IS_WIN = sys.platform == "win32"


def find_ui(name):
    for root in (UI_ASSETS, HERE):
        p = os.path.join(root, name)
        if os.path.isfile(p):
            return p
    return ""


# ----------------------------------------------------------------------------- keys

VK_NAMES = {0x08: "Backspace", 0x09: "Tab", 0x0D: "Enter", 0x13: "Pause", 0x14: "CapsLock", 0x1B: "Esc",
            0x20: "Space", 0x21: "PageUp", 0x22: "PageDown", 0x23: "End", 0x24: "Home", 0x25: "Left",
            0x26: "Up", 0x27: "Right", 0x28: "Down", 0x2C: "PrintScreen", 0x2D: "Insert", 0x2E: "Delete",
            0x6A: "Num*", 0x6B: "Num+", 0x6D: "Num-", 0x6E: "Num.", 0x6F: "Num/", 0x90: "NumLock",
            0x91: "ScrollLock", 0xA0: "LShift", 0xA1: "RShift", 0xA2: "LCtrl", 0xA3: "RCtrl", 0xA4: "LAlt",
            0xA5: "RAlt", 0xBA: ";", 0xBB: "=", 0xBC: ",", 0xBD: "-", 0xBE: ".", 0xBF: "/", 0xC0: "`",
            0xDB: "[", 0xDC: "\\", 0xDD: "]", 0xDE: "'", 0x05: "Mouse4", 0x06: "Mouse5"}
for _i in range(10):
    VK_NAMES[0x30 + _i] = str(_i)
    VK_NAMES[0x60 + _i] = "Num%d" % _i
for _i in range(26):
    VK_NAMES[0x41 + _i] = chr(65 + _i)
for _i in range(24):
    VK_NAMES[0x70 + _i] = "F%d" % (_i + 1)
NAME_VK = {v.lower(): k for k, v in VK_NAMES.items()}
MOUSE_VK = {"lmb": 0x01, "rmb": 0x02, "mmb": 0x04}
MOUSE_CHOICES = ["RMB", "LMB", "MMB"]
JOY_CHOICES = ["None", "A_Cross", "B_Circle", "X_Square", "Y_Triangle", "LB", "LT", "RB", "RT", "Start"]
JOY_BITS = {"a_cross": 0x1000, "b_circle": 0x2000, "x_square": 0x4000, "y_triangle": 0x8000,
            "lb": 0x0100, "rb": 0x0200, "start": 0x0010}


def vk_of(name):
    return NAME_VK.get(str(name or "").strip().lower(), 0)


# ----------------------------------------------------------------------------- config

DEFAULT_CFG = {
    "steam_exe": "",
    "hide_grid": False,
    "hide_preview_grid": False,
    "deviation_x": 0,
    "deviation_y": 0,
    "reticle_scale": 0,
    "override_color": [255, 255, 255],
    "override_enabled": False,
    "subtract_opacity": 0,
    "post_outline": True,
    "outline_width": 1.5,
    "outline_width_note": "Outline thickness in pixels. Original value: 1.5",
    "outline_blur": 3,
    "outline_blur_note": "Outline blur strength (the Gaussian sigma in pixels is this value / 2). Original value: 3",
    "outline_opacity": 70,
    "outline_opacity_note": "How visible the outline is, 0-100 (100 = solid black, 0 = invisible). Original value: 70",
    "last_apply": "",
    "last_apply_note": "What Patch Reticle / Original Deviate last wrote (patch | deviate | empty after a restore). auto_reapply uses it.",
    "auto_reapply": False,
    "auto_reapply_note": "Advanced. true = when the borderless app starts (game closed, Steam done installing) and a game update undid your changes, unlock the SHA check again and apply the last reticle (with its Reticle Deviation) again. Default: false",
    "snapshot_hold_seconds": 2.0,
    "snapshot_hold_seconds_note": "Take photo: how many seconds the aim button has to be held in the game before the picture is taken. Original value: 2",
    "mouse_key": "LMB",
    "keyboard_key": "",
    "joystick_key": "None",
    "ui_hotkey": "",
    "hide_apply_warning": False,
    "selected": None,
}

def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def num(v, default, lo, hi, integer=False):
    try:
        v = float(v)
        if v != v:
            raise ValueError
    except (TypeError, ValueError):
        v = default
    v = clamp(v, lo, hi)
    return int(round(v)) if integer else v


def parse_rgb(v, default=(255, 255, 255)):
    """'12,34,56' / '#aabbcc' / [r,g,b] -> (r,g,b) or the default."""
    try:
        if isinstance(v, str):
            t = v.strip()
            if t.startswith("#") or (len(t) == 6 and all(c in "0123456789abcdefABCDEF" for c in t)
                                     and "," not in t):
                t = t.lstrip("#")
                return (int(t[0:2], 16), int(t[2:4], 16), int(t[4:6], 16))
            parts = [p for p in t.replace(";", ",").replace(" ", ",").split(",") if p != ""]
            v = parts
        if len(v) != 3:
            raise ValueError
        out = tuple(int(float(c)) for c in v)
        if any(c < 0 or c > 255 for c in out):
            raise ValueError
        return out
    except (TypeError, ValueError):
        return default


def rgb_text(c):
    return "%d,%d,%d" % tuple(c)


class Config:
    """The shared JSON. Thread-safe; writes are atomic; reloads when the file changes on disk."""

    def __init__(self, path=CFG_PATH):
        self.path = path
        self.lock = threading.RLock()
        self.data = json.loads(json.dumps(DEFAULT_CFG))
        self.mtime = None
        self.warned = False
        if not os.path.isfile(self.path):
            self._write()
        self.reload(force=True)

    def _write(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
            os.replace(tmp, self.path)
            self.mtime = os.path.getmtime(self.path)
        except OSError as e:
            print("Could not write", self.path, "-", e)

    @staticmethod
    def migrate(d):
        """Add every missing setting with its default. Returns True when something was added."""
        changed = False
        for k, v in DEFAULT_CFG.items():
            if k not in d:
                d[k] = json.loads(json.dumps(v))
                changed = True
        return changed

    def reload(self, force=False):
        """True when the file was re-read (its contents changed on disk)."""
        with self.lock:
            try:
                m = os.path.getmtime(self.path)
                if not force and m == self.mtime:
                    return False
                with open(self.path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if not isinstance(data, dict):
                    raise ValueError("top level must be an object")
                self.warned = False
                before = json.dumps(data, sort_keys=True)
                self.migrate(data)
                self.data = data
                self.mtime = m
                if json.dumps(data, sort_keys=True) != before:
                    self._write()
                return True
            except (OSError, ValueError) as e:
                if not self.warned:
                    print("reticle_config.json is not valid, keeping the last good values:", e)
                    self.warned = True
                return False

    def get(self, key, default=None):
        with self.lock:
            return self.data.get(key, default)

    def set(self, **kw):
        with self.lock:
            self.data.update(kw)
            self._write()

    def values(self):
        with self.lock:
            d = self.data
            mouse = str(d.get("mouse_key", "LMB")).strip().lower()
            joy = str(d.get("joystick_key", "None")).strip().lower()
            return SimpleNamespace(
                dev_x=num(d.get("deviation_x"), 0, -DEV_LIMIT, DEV_LIMIT, True),
                dev_y=num(d.get("deviation_y"), 0, -DEV_LIMIT, DEV_LIMIT, True),
                hold=num(d.get("snapshot_hold_seconds"), 2.0, 0.2, 60),
                patch=centre_patch(),
                mouse_vk=MOUSE_VK.get(mouse, 0x01), kb_vk=vk_of(d.get("keyboard_key")),
                joy=joy if joy in JOY_BITS or joy in ("lt", "rt") else "")


def steam_roots(steam_exe):
    """Every Steam library folder (the Steam folder itself plus those in libraryfolders.vdf)."""
    base = os.path.dirname(os.path.abspath(steam_exe))
    roots = [base]
    vdf = os.path.join(base, "steamapps", "libraryfolders.vdf")
    try:
        with open(vdf, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                parts = line.split('"')
                if len(parts) >= 4 and parts[1].lower() == "path":
                    p = parts[3].replace("\\\\", "\\")
                    if p and p not in roots:
                        roots.append(p)
    except OSError:
        pass
    return roots


def game_running():
    """True while BrgGame-Steam.exe is a running process."""
    if not IS_WIN:
        return False
    try:
        from ctypes import wintypes as wt

        class PE(ctypes.Structure):
            _fields_ = [("dwSize", wt.DWORD), ("cntUsage", wt.DWORD), ("th32ProcessID", wt.DWORD),
                        ("th32DefaultHeapID", ctypes.c_size_t), ("th32ModuleID", wt.DWORD),
                        ("cntThreads", wt.DWORD), ("th32ParentProcessID", wt.DWORD),
                        ("pcPriClassBase", wt.LONG), ("dwFlags", wt.DWORD), ("szExeFile", wt.WCHAR * 260)]

        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.CreateToolhelp32Snapshot.restype = ctypes.c_void_p
        k.CreateToolhelp32Snapshot.argtypes = [wt.DWORD, wt.DWORD]
        k.Process32FirstW.argtypes = [ctypes.c_void_p, ctypes.POINTER(PE)]
        k.Process32NextW.argtypes = [ctypes.c_void_p, ctypes.POINTER(PE)]
        k.CloseHandle.argtypes = [ctypes.c_void_p]
        snap = k.CreateToolhelp32Snapshot(0x2, 0)
        if not snap or snap == ctypes.c_void_p(-1).value:
            return False
        try:
            pe = PE()
            pe.dwSize = ctypes.sizeof(PE)
            ok = k.Process32FirstW(snap, ctypes.byref(pe))
            while ok:
                if pe.szExeFile.lower() == GAME_EXE:
                    return True
                ok = k.Process32NextW(snap, ctypes.byref(pe))
        finally:
            k.CloseHandle(snap)
    except Exception:
        pass
    return False


def pid_alive(pid):
    if not IS_WIN:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    try:
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.OpenProcess.restype = ctypes.c_void_p
        h = k.OpenProcess(0x1000, False, pid)
        if not h:
            return False
        code = ctypes.c_ulong()
        k.GetExitCodeProcess(ctypes.c_void_p(h), ctypes.byref(code))
        k.CloseHandle(ctypes.c_void_p(h))
        return code.value == 259
    except Exception:
        return True


# ----------------------------------------------------------------------------- game folder

class GameFiles(SimpleNamespace):
    """The game files this program works with: hud (UI_HUD_SF.upk), base (BrgGameBase.upk), exe, bin (its folder)."""


def find_game_files(steam_exe):
    """-> GameFiles, or None when this Steam has no LET IT DIE with all of them."""
    if not steam_exe or os.path.basename(steam_exe).lower() != "steam.exe":
        return None
    for root in steam_roots(steam_exe):
        game = os.path.join(root, "steamapps", "common", GAME_DIR_NAME)
        cooked = os.path.join(game, "BrgGame", "CookedPCConsole")
        hud = os.path.join(cooked, UPK_NAME)
        bin_dir = os.path.join(game, "Binaries", "Win64")
        exe = os.path.join(bin_dir, "BrgGame-Steam.exe")
        if not (os.path.isfile(hud) and os.path.isfile(exe)):
            continue
        base = os.path.join(cooked, BASE_NAME)
        if not os.path.isfile(base):
            base = ""
            for dirpath, _dirs, names in os.walk(game):
                if BASE_NAME in names:
                    base = os.path.join(dirpath, BASE_NAME)
                    break
        ini = os.path.join(game, "BrgGame", "Config", INI_NAME)
        return GameFiles(hud=hud, base=base, exe=exe, bin=bin_dir, game=game, ini=ini if os.path.isfile(ini) else "")
    return None


# ----------------------------------------------------------------------------- game files (UPK)
# Two game files are changed, both are rebuilt from their untouched backup every time:
#   UI_HUD_SF.upk   the stock reticle picture is wiped from the HUD texture and the finished reticle is painted into
#                   the reticle sprite's own cell of that texture.
#   BrgGameBase.upk the HUD's sprite table: the reticle sprite's draw offset (mDrawX / mDrawY) is the Reticle Deviation.

UPK_TAG = 0x9E2A83C1
TEXTURE = "TX_UI_HUD_Base_Status_v06_00"
TEX_W, TEX_H = 2048, 860
PIXEL_BYTES = TEX_W * TEX_H * 4
BOX = (1405, 0, 1463, 50)           # where the stock reticle art lives (x0, y0, x1, y1): wiped when applying
EXPECT_VISIBLE = 1527               # visible pixels of the stock art inside BOX: tells an original HUD file
CELL = (1409, 1, 1469, 61)          # the reticle sprite's rectangle in the stored texture (60 x 60)
ART = 58                            # biggest reticle that fits the cell, keeping 1 px free all round
BLOCK = 0x20000

SPRITE_EXPORT = "Default__BrgUIImageMapInfo_UI_HUD_TX_UI_HUD_Base_Status_v06"
SPRITE = 86                         # index of the reticle sprite (Icon_Retile_v00) in the table's image array
_IMG = ("mImageMap", "mImageArray", SPRITE)
_UNIT = _IMG + ("mUnitArray", 0)
SPRITE_STOCK = {_IMG + ("mScreenPosX",): 1874, _IMG + ("mScreenPosY",): 1034,
                _IMG + ("mSizeX",): 92, _IMG + ("mSizeY",): 92,
                _UNIT + ("mTextureUseX",): 2818, _UNIT + ("mTextureUseY",): 2,
                _UNIT + ("mTextureUseSizeX",): 120, _UNIT + ("mTextureUseSizeY",): 120}
DRAW_X, DRAW_Y = _UNIT + ("mDrawX",), _UNIT + ("mDrawY",)
DEV_LIMIT = 1000                    # Reticle Deviation range, in the HUD's own units (a 3840 x 2160 layout)
HUD_LAYOUT_H = 2160.0               # the HUD is laid out on this many units of height ...
HUD_UNITS_PER_PX = 2.0              # ... and one stored pixel of the reticle covers this many units: measured in game, a
                                    # reticle is shown 1:1 on a 1080p screen (twice as big on 2160p)


class MakerError(Exception):
    pass


class Package:
    def __init__(self, data):
        self.d = data
        if struct.unpack_from("<I", data, 0)[0] != UPK_TAG:
            raise ValueError("this is not an Unreal Engine package")
        o = 12
        n, = struct.unpack_from("<i", data, o)
        o += 4 + n
        self.flags, = struct.unpack_from("<I", data, o)
        o += 4
        (self.name_count, self.name_off, self.export_count, self.export_off,
         self.import_count, self.import_off) = struct.unpack_from("<6i", data, o)
        o += 24 + 20 + 16
        gens, = struct.unpack_from("<i", data, o)
        o += 4 + 12 * gens + 8
        cflags, nchunks = struct.unpack_from("<Ii", data, o)
        o += 8
        self.compressed = bool(self.flags & 0x02000000) and nchunks > 0
        if self.compressed:
            if cflags != 2:
                raise ValueError("unsupported compression type (only LZO is supported)")
            try:
                import lzallright
            except ImportError:
                raise MakerError("Missing dependency: pip install lzallright")
            self.lzo = lzallright.LZOCompressor
            self.table_off = o
            self.chunks = [list(struct.unpack_from("<4i", data, o + 16 * i)) for i in range(nchunks)]
            self.summary_size = self.chunks[0][0]
            self.parts = []
            for uo, us, co, cs in self.chunks:
                _tag, bsz, _ctot, utot = struct.unpack_from("<IiiI", data, co)
                nb = (utot + bsz - 1) // bsz
                p = co + 16 + 8 * nb
                out = bytearray()
                for i in range(nb):
                    bc = struct.unpack_from("<ii", data, co + 16 + 8 * i)[0]
                    out += bytes(self.lzo.decompress(data[p:p + bc]))
                    p += bc
                if len(out) != us:
                    raise ValueError("chunk size mismatch")
                self.parts.append(out)
            self.orig_parts = [bytes(x) for x in self.parts]
            self.img = bytearray(data[:self.summary_size])
            for part in self.parts:
                self.img += part
        else:
            self.summary_size = 0
            self.img = bytearray(data)
        self._read_tables()

    def _fname(self, idx, num_):
        s = self.names[idx]
        return s if num_ == 0 else "%s_%d" % (s, num_ - 1)

    def _read_tables(self):
        img, o = self.img, self.name_off
        self.names = []
        for _ in range(self.name_count):
            n, = struct.unpack_from("<i", img, o)
            o += 4
            self.names.append(img[o:o + n - 1].decode("latin1"))
            o += n + 8
        o = self.export_off
        self.exports = {}
        for _ in range(self.export_count):
            nm, nmn = struct.unpack_from("<ii", img, o + 12)
            size, off = struct.unpack_from("<ii", img, o + 32)
            netc = struct.unpack_from("<Ii", img, o + 40)[1]
            o += 24 + 16 + 8 + 4 * netc + 20
            self.exports[self._fname(nm, nmn)] = (off, size)

    def pixel_offset(self):
        off, size = self.exports[TEXTURE]
        k = bytes(self.img[off:off + size]).find(struct.pack("<ii", PIXEL_BYTES, PIXEL_BYTES))
        if k < 0:
            raise ValueError("texture pixel data not found")
        return off + k + 12

    def int_fields(self, export, wanted):
        """Absolute offsets of the int32 properties of `export` whose path (property names, array positions) is in
        `wanted`. Tagged property streams are walked; struct arrays are entered, any other array is skipped."""
        off, size = self.exports[export]
        img, names = self.img, self.names
        found = {}

        def walk(o, path):
            while True:
                n, _ = struct.unpack_from("<ii", img, o)
                o += 8
                name = names[n]
                if name == "None":
                    return o
                t, _ = struct.unpack_from("<ii", img, o)
                o += 8
                ty = names[t]
                sz, _ai = struct.unpack_from("<ii", img, o)
                o += 8
                if ty in ("StructProperty", "ByteProperty"):
                    o += 8
                elif ty == "BoolProperty":
                    o += 1
                    continue
                here = path + (name,)
                end = o + sz
                if ty == "IntProperty":
                    if here in wanted:
                        found[here] = o
                elif ty == "StructProperty":
                    walk(o, here)
                elif ty == "ArrayProperty" and name in ("mImageArray", "mUnitArray"):
                    cnt, = struct.unpack_from("<i", img, o)
                    q = o + 4
                    for k in range(cnt):
                        q = walk(q, here + (k,))
                o = end

        walk(off + 4, ())
        return found

    def build(self):
        if not self.compressed:
            return bytes(self.img)
        d = self.d
        for i, (uo, us, co, cs) in enumerate(self.chunks):
            self.parts[i] = bytearray(self.img[uo:uo + us])
        comp = []
        for idx, part in enumerate(self.parts):
            uo, us, co, cs = self.chunks[idx]
            if bytes(part) == self.orig_parts[idx]:
                comp.append(d[co:co + cs])
                continue
            nb = (len(part) + BLOCK - 1) // BLOCK
            blocks = [bytes(self.lzo().compress(bytes(part[i * BLOCK:(i + 1) * BLOCK]))) for i in range(nb)]
            head = struct.pack("<IiiI", UPK_TAG, BLOCK, sum(len(b) for b in blocks), len(part))
            head += b"".join(struct.pack("<ii", len(b), min(BLOCK, len(part) - i * BLOCK))
                             for i, b in enumerate(blocks))
            comp.append(head + b"".join(blocks))
        out = bytearray(d[:self.table_off])
        pos = self.chunks[0][2]
        table = bytearray()
        for (uo, us, co, cs), blob in zip(self.chunks, comp):
            table += struct.pack("<4i", uo, us, pos, len(blob))
            pos += len(blob)
        out += table
        out += d[self.table_off + len(table):self.chunks[0][2]]
        for blob in comp:
            out += blob
        return bytes(out)

    def body(self):
        """The package without its header (the chunk table there changes whenever the file is rebuilt)."""
        return bytes(self.img[self.summary_size:])


def _texture(img, px):
    return np.frombuffer(img, np.uint8, PIXEL_BYTES, px).reshape(TEX_H, TEX_W, 4)      # writable view of a bytearray


def visible(img, px, box):
    x0, y0, x1, y1 = box
    return int(np.count_nonzero(_texture(img, px)[y0:y1, x0:x1, 3]))


def read_hud(data):
    try:
        return Package(data)
    except (ValueError, struct.error) as e:
        raise MakerError("cannot read it as a package: %s" % e)


def check_hud(path):
    """-> (package, pixel offset) of an unmodified UI_HUD_SF.upk, else MakerError."""
    try:
        with open(path, "rb") as f:
            pkg = read_hud(f.read())
    except OSError as e:
        raise MakerError("cannot read it: %s" % e)
    if TEXTURE not in pkg.exports:
        raise MakerError("this is not %s (texture %s not found)." % (UPK_NAME, TEXTURE))
    px = pkg.pixel_offset()
    n = visible(pkg.img, px, BOX)
    if n != EXPECT_VISIBLE:
        raise MakerError("the reticle area has %d visible pixels instead of %d: this file is already modified "
                         "(or is a different version of the game)." % (n, EXPECT_VISIBLE))
    return pkg, px


def sprite_state(pkg):
    """-> (offsets {path: int32 offset}, (deviation x, deviation y)) of the reticle sprite in BrgGameBase.upk.
    MakerError when the table is not the one this program knows (another game version)."""
    if SPRITE_EXPORT not in pkg.exports:
        raise MakerError("this is not %s (the HUD sprite table was not found)." % BASE_NAME)
    want = set(SPRITE_STOCK) | {DRAW_X, DRAW_Y}
    offs = pkg.int_fields(SPRITE_EXPORT, want)
    if len(offs) != len(want):
        raise MakerError("the reticle sprite was not found in the HUD sprite table (another game version?).")
    for key, v in SPRITE_STOCK.items():
        if struct.unpack_from("<i", pkg.img, offs[key])[0] != v:
            raise MakerError("the reticle sprite has other values than expected (another game version?).")
    dev = tuple(struct.unpack_from("<i", pkg.img, offs[k])[0] for k in (DRAW_X, DRAW_Y))
    return offs, dev


def check_base(path):
    """-> (package, offsets) of an unmodified BrgGameBase.upk (reticle draw offset still 0), else MakerError."""
    try:
        with open(path, "rb") as f:
            pkg = read_hud(f.read())
    except OSError as e:
        raise MakerError("cannot read it: %s" % e)
    offs, dev = sprite_state(pkg)
    if dev != (0, 0):
        raise MakerError("the reticle sprite is already moved: this file is already modified.")
    return pkg, offs


def crop_picture(rgba):
    """The finished reticle cropped around its centre to what fits the reticle cell (ART x ART, anything outside is
    lost) and padded to even sides. Still ordinary (straight alpha) colours: this is what the player sees."""
    h, w = rgba.shape[:2]
    if w > ART:
        x0 = (w - ART) // 2
        rgba, w = rgba[:, x0:x0 + ART], ART
    if h > ART:
        y0 = (h - ART) // 2
        rgba, h = rgba[y0:y0 + ART], ART
    pw, ph = w + w % 2, h + h % 2
    if (pw, ph) != (w, h):
        rgba = np.pad(rgba, ((0, ph - h), (0, pw - w), (0, 0)))
    return np.ascontiguousarray(rgba, np.uint8)


def bake_picture(rgba):
    """The picture as it is stored in the HUD texture. The game's textures hold PREMULTIPLIED alpha (in the stock HUD every
    pixel has its colour channels <= its alpha, checked over the whole texture): colour = colour x alpha, and fully
    transparent pixels are black. Storing ordinary straight colours made the soft edges flicker as dark / bright
    squares in game."""
    pic = crop_picture(rgba)
    a = pic[..., 3:4].astype(np.float32) / 255.0
    out = pic.copy()
    out[..., :3] = np.clip(np.rint(pic[..., :3].astype(np.float32) * a), 0, 255).astype(np.uint8)
    return out


def cell_origin(w, h):
    """Top-left of a w x h picture centred in the reticle cell."""
    x0, y0, x1, y1 = CELL
    return (x0 + x1) // 2 - w // 2, (y0 + y1) // 2 - h // 2


def paint_reticle(img, px, rgba):
    """Wipe the stock art and the whole cell, then paint the reticle (picture = bake_picture result, premultiplied) in the middle."""
    tex = _texture(img, px)
    bx0, by0, bx1, by1 = BOX
    tex[by0:by1, bx0:bx1] = 0
    cx0, cy0, cx1, cy1 = CELL
    tex[cy0:cy1, cx0:cx1] = 0
    h, w = rgba.shape[:2]
    x, y = cell_origin(w, h)
    tex[y:y + h, x:x + w] = rgba[..., [2, 1, 0, 3]]               # the texture is BGRA


def painted_reticle(img, px):
    """The picture in the cell as it is stored (RGBA)."""
    x0, y0, x1, y1 = CELL
    return _texture(img, px)[y0:y1, x0:x1][..., [2, 1, 0, 3]].copy()


def ingame_scale(screen_h):
    """On-screen pixels of one stored texture pixel of the reticle, for a game picture screen_h pixels high."""
    return HUD_UNITS_PER_PX * float(screen_h) / HUD_LAYOUT_H


ORIG_CENTER = (1434.0, 24.0)        # centre of the stock reticle (its dot) in the HUD texture; the cell's own centre is (1439, 31)


def centre_patch(scale=1.0):
    """The deviation that puts a reticle centred in the cell where the stock reticle's centre is (the stock art sits 5 px
    left of and 7 px above the cell's middle). Stored pixels -> deviation units. Only Patch Reticle adds it: with
    Original Deviate the stock reticle is already in the right place."""
    cx, cy = (CELL[0] + CELL[2]) / 2.0, (CELL[1] + CELL[3]) / 2.0
    return (int(round((ORIG_CENTER[0] - cx) * HUD_UNITS_PER_PX * scale)),
            int(round((ORIG_CENTER[1] - cy) * HUD_UNITS_PER_PX * scale)))


def fit_preview(rgba):
    """What the HUD will really show of this reticle (the bake, without its colour spreading)."""
    return crop_picture(rgba) if rgba is not None else None


def clean_temp_files(files=None):
    """Delete leftovers of an interrupted write: the .tmp files our atomic writes use, next to the game files and
    next to this program. Only these exact names are touched. `files` = the game files (GameFiles or paths)."""
    paths = []
    if isinstance(files, GameFiles):
        paths = [files.hud, files.base, files.exe]
    elif files:
        paths = [p for p in files if p]
    names = []
    for f in paths:
        names.append(f + ".tmp")
        d, base = os.path.split(f)
        try:
            names += [os.path.join(d, n) for n in os.listdir(d) if n.startswith(base + ".") and n.endswith(".backup.tmp")]
        except OSError:
            pass
    names.append(CFG_PATH + ".tmp")
    try:
        names += [os.path.join(CURRENT_DIR, n) for n in os.listdir(CURRENT_DIR) if n.startswith("~tmp_")]
    except OSError:
        pass
    for p in names:
        try:
            if os.path.isfile(p):
                os.remove(p)
        except OSError:
            pass


def atomic_copy_bytes(dst, data):
    tmp = dst + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    with open(tmp, "rb") as f:
        if f.read() != data:
            os.remove(tmp)
            raise MakerError("the temporary file did not read back correctly - nothing was changed")
    os.replace(tmp, dst)


def _game_manifest(game_file):
    """Text of the game's Steam appmanifest (found from any file inside the game folder), or ''."""
    import re
    d = os.path.abspath(game_file)
    while True:
        parent = os.path.dirname(d)
        if parent == d:
            return ""
        if os.path.basename(d).lower() == "steamapps":
            break
        d = parent
    try:
        names = sorted(n for n in os.listdir(d) if n.startswith("appmanifest_") and n.endswith(".acf"))
    except OSError:
        return ""
    for n in names:
        try:
            with open(os.path.join(d, n), "r", encoding="utf-8", errors="replace") as f:
                txt = f.read()
        except OSError:
            continue
        m = re.search(r'"installdir"\s+"([^"]*)"', txt)
        if m and m.group(1).lower() == GAME_DIR_NAME.lower():
            return txt
    return ""


def game_build(game_file):
    """Steam's build id of the installed game ("" when it cannot be read)."""
    import re
    m = re.search(r'"buildid"\s+"(\d+)"', _game_manifest(game_file))
    return m.group(1) if m else ""


def game_install_complete(game_file):
    """False while Steam is still installing / updating the game (StateFlags 4 = fully installed)."""
    import re
    m = re.search(r'"StateFlags"\s+"(\d+)"', _game_manifest(game_file))
    return m is None or int(m.group(1)) == 4


# what each changed game file is checked against: (display name, checker that raises MakerError unless original)
GAME_CHECKS = {"hud": (UPK_NAME, check_hud), "base": (BASE_NAME, check_base)}


def ensure_backup(game_file, kind, build=""):
    """Keep the unmodified game file as <file>.<buildid>.backup next to it in the game folder (kind: "hud" | "base").
    A clean game file is always the newest truth: when it differs from the saved copy (the game was updated) the
    copy is replaced. A modified game file needs a saved copy that fits this build. Returns the backup path."""
    import Hash_remover as HR
    name, check = GAME_CHECKS[kind]
    usable = HR.valid_backup(game_file, build)
    try:
        check(game_file)
        clean = True
    except MakerError as e:
        clean, why = False, e
    if clean:
        try:
            return str(HR.refresh_backup(game_file, build))
        except (HR.Problem, OSError) as e:
            raise MakerError("Could not save the backup of %s: %s" % (name, e))
    if usable is None:
        extra = (" The saved copy found belongs to an older version of the game." if HR.list_backups(game_file) else "")
        raise MakerError("The game's %s is not the original, so it was not saved as backup: %s%s "
                         "In Steam use 'Verify integrity of game files' to get the original back." % (name, why, extra))
    try:
        check(str(usable))
    except MakerError as e:
        raise MakerError("%s is not the original: %s Replace it with the unmodified %s "
                         "(or delete it to save it again from the game)." % (usable.name, e, name))
    return str(usable)


def apply_reticle(files, rgba, dev_x, dev_y, build="", patch=None):
    """Bake `rgba` (the finished reticle) into the game: UI_HUD_SF.upk gets the picture, BrgGameBase.upk the deviation.
    Both are built from their backups, checked by reading the result back, and only then written. -> (w, h) painted."""
    if not game_install_complete(files.hud):
        raise MakerError("Steam is still installing or updating the game. Wait until it has finished, then try again.")
    clean_temp_files(files)
    b_hud = ensure_backup(files.hud, "hud", build)
    b_base = ensure_backup(files.base, "base", build)
    px_, py_ = Config().values().patch if patch is None else patch
    dev = (int(clamp(dev_x, -DEV_LIMIT, DEV_LIMIT)) + px_, int(clamp(dev_y, -DEV_LIMIT, DEV_LIMIT)) + py_)
    pic = bake_picture(rgba)

    pkg, px = check_hud(b_hud)
    paint_reticle(pkg.img, px, pic)
    out_hud = pkg.build()
    chk = read_hud(out_hud)
    if bytes(chk.img[chk.summary_size:]) != pkg.body() or not np.array_equal(painted_reticle(chk.img, chk.pixel_offset()),
                                                                           painted_reticle(pkg.img, px)):
        raise MakerError("Self-check of %s failed, nothing was written." % UPK_NAME)

    base, offs = check_base(b_base)
    struct.pack_into("<i", base.img, offs[DRAW_X], dev[0])
    struct.pack_into("<i", base.img, offs[DRAW_Y], dev[1])
    out_base = base.build()
    chk = read_hud(out_base)
    if chk.body() != base.body() or sprite_state(chk)[1] != dev:
        raise MakerError("Self-check of %s failed, nothing was written." % BASE_NAME)

    atomic_copy_bytes(files.hud, out_hud)
    try:
        atomic_copy_bytes(files.base, out_base)
    except (MakerError, OSError) as e:
        try:                                                    # keep the two files in step
            with open(b_hud, "rb") as f:
                atomic_copy_bytes(files.hud, f.read())
        except (MakerError, OSError):
            pass
        raise MakerError("Could not write %s: %s - %s was put back." % (BASE_NAME, e, UPK_NAME))
    return pic.shape[1], pic.shape[0]


def deviate_only(files, dev_x, dev_y, build=""):
    """Original Deviate: UI_HUD_SF.upk goes back to the original (when it was changed) and only BrgGameBase.upk is
    modified, so the stock reticle is moved by the deviation. Returns True when the HUD had to be restored."""
    if not game_install_complete(files.hud):
        raise MakerError("Steam is still installing or updating the game. Wait until it has finished, then try again.")
    clean_temp_files(files)
    ensure_backup(files.hud, "hud", build)                     # also refuses a modified HUD that has no usable backup
    b_base = ensure_backup(files.base, "base", build)
    dev = (int(clamp(dev_x, -DEV_LIMIT, DEV_LIMIT)), int(clamp(dev_y, -DEV_LIMIT, DEV_LIMIT)))
    base, offs = check_base(b_base)
    struct.pack_into("<i", base.img, offs[DRAW_X], dev[0])
    struct.pack_into("<i", base.img, offs[DRAW_Y], dev[1])
    out_base = base.build()
    chk = read_hud(out_base)
    if chk.body() != base.body() or sprite_state(chk)[1] != dev:
        raise MakerError("Self-check of %s failed, nothing was written." % BASE_NAME)
    hud_restored = restore_game_file(files.hud, "hud", build)
    try:
        check_hud(files.hud)
    except MakerError as e:
        raise MakerError("%s is not the original and could not be restored: %s" % (UPK_NAME, e))
    atomic_copy_bytes(files.base, out_base)
    return hud_restored


def restore_reticle(files, build="", hud=True, base=True):
    """Put the original HUD and / or BrgGameBase back (the SHA stays as it is). -> names that really changed."""
    changed = []
    for want, kind, path, name in ((hud, "hud", files.hud, UPK_NAME), (base, "base", files.base, BASE_NAME)):
        if want and path and restore_game_file(path, kind, build):
            changed.append(name)
    return changed


def ini_is_original(files, build=""):
    """Is the game's engine ini still the one Steam installed? The game program carries the SHA1 of each of its files:
    True / False when the ini is in that list, None when that cannot be read. The list is read from the saved
    original program when there is one (an unlocked program has its names changed)."""
    import hashlib
    import Hash_remover as HR
    try:
        src = HR.valid_backup(files.exe, build) or files.exe
        with open(src, "rb") as f:
            entries = HR.walk(f.read())
        with open(files.ini, "rb") as f:
            sha = hashlib.sha1(f.read()).hexdigest()
    except Exception:
        return None
    want = INI_NAME.lower()
    for name, _last, h in entries:
        base = name.replace("\\", "/").rsplit("/", 1)[-1]
        if base == want or base[:-1] == want[:-1] and base[-1] in "xy":     # (the last letter of a switched-off name)
            return h == sha
    return None


def ensure_ini_backup(files, build=""):
    """Save the original engine ini next to it (<file>.<buildid>.backup) so Restore SHA can put it back after the game
    rewrote it. -> a note when something needs the user's attention, else ''."""
    import Hash_remover as HR
    ini = getattr(files, "ini", "")
    if not ini:
        return ""
    state = ini_is_original(files, build)
    have = HR.valid_backup(ini, build)
    try:
        if state is True:
            HR.refresh_backup(ini, build)
        elif state is None and have is None:
            HR.refresh_backup(ini, build)           # cannot tell: keep what is there rather than nothing
        elif state is False and have is None:
            return ("The game already rewrote %s, so it could not be saved as backup. In Steam use 'Verify integrity of "
                    "game files' once, then unlock again." % INI_NAME)
    except (HR.Problem, OSError) as e:
        return "Could not save the backup of %s: %s" % (INI_NAME, e)
    return ""


def restore_ini(files, build=""):
    """Put the saved original engine ini back. -> (changed, backup_kept_note)."""
    import Hash_remover as HR
    ini = getattr(files, "ini", "")
    bk = HR.valid_backup(ini, build) if ini else None
    if bk is None:
        return False, ""
    with open(str(bk), "rb") as f:
        data = f.read()
    try:
        with open(ini, "rb") as f:
            same = f.read() == data
    except OSError:
        same = False
    if not same:
        atomic_copy_bytes(ini, data)
    if HR.same_file(ini, bk):
        HR.discard_backups(ini)
        return (not same), ""
    return (not same), "%s does not match its backup, backup kept" % INI_NAME


def restore_game_file(game_file, kind, build=""):
    """Put the original of one game file back ("hud" | "base"). Returns True when it had to change the game file.
    Only a saved copy that fits the game's current build is used."""
    import Hash_remover as HR
    backup = HR.valid_backup(game_file, build)
    if backup is None:
        return False
    backup = str(backup)
    GAME_CHECKS[kind][1](backup)
    with open(backup, "rb") as f:
        data = f.read()
    try:
        with open(game_file, "rb") as f:
            if f.read() == data:
                return False
    except OSError:
        pass
    atomic_copy_bytes(game_file, data)
    return True


def modified_files(files, build=""):
    """Names of the changed game files that differ from their saved original (what Apply put there)."""
    import Hash_remover as HR
    out = []
    for kind, path in (("hud", files.hud), ("base", files.base)):
        bk = HR.valid_backup(path, build)
        if bk is not None and not HR.same_file(path, bk):
            out.append(GAME_CHECKS[kind][0])
    return out


def auto_unlock_sha():
    """Once per start of the borderless app, when "auto_reapply" is true in reticle_config.json, redo what a game
    update undid. The sign is the same for each file: the game's file is original again but the only backup of it
    belongs to an older build (so it was changed here before and nobody restored it).
      - BrgGame-Steam.exe  active again -> unlock the SHA check again
      - UI_HUD_SF.upk / BrgGameBase.upk original again -> apply the last reticle (_Current\\Reticle.webp with the
                                            saved Reticle Deviation) again
    -> a message for the status line, '' when nothing was done."""
    import Hash_remover as HR
    cfg = Config()
    mode = cfg.get("last_apply")
    if not cfg.get("auto_reapply") or mode not in ("patch", "deviate"):
        return ""
    files = find_game_files(cfg.get("steam_exe"))
    if not files or game_running() or not game_install_complete(files.hud):
        return ""
    build = game_build(files.hud)
    done = []
    try:
        clean_temp_files(files)
        if HR.list_backups(files.exe) and HR.valid_backup(files.exe, build) is None \
                and HR.sha_status(files.exe, build)["state"] == "active":
            ensure_ini_backup(files, build)
            HR.turn_off_all(files.exe, build=build)
            done.append("SHA unlocked again")
        stale = []
        for kind, path in (("hud", files.hud), ("base", files.base)):
            if not path or (kind == "hud" and mode == "deviate"):      # Original Deviate never touched the HUD
                continue
            if HR.list_backups(path) and HR.valid_backup(path, build) is None:
                try:
                    GAME_CHECKS[kind][1](path)
                except MakerError:
                    continue                  # the update did not touch the file (or it is not a clean original)
                stale.append(kind)
        if stale and mode == "deviate":
            v = cfg.values()
            deviate_only(files, v.dev_x, v.dev_y, build)
            done.append("deviation applied again")
        elif stale:
            name = current_name()
            if name:
                rgba = load_rgba(os.path.join(CURRENT_DIR, name))
                v = cfg.values()
                apply_reticle(files, rgba, v.dev_x, v.dev_y, build)
                done.append("reticle applied again")
    except (HR.Problem, MakerError, OSError) as e:
        return "Auto update after the game update failed: %s" % e
    return ("The game was updated: " + ", ".join(done) + ".") if done else ""


DEFAULT_SELECTED = {"outer": ["_Outer/_Default/Plus.png"], "center": ["_Center/_Default/Dot.png"]}
CURRENT_FILE = "Reticle.webp"
WHITE = (255, 255, 255)
# Options kept in every folder's Section_configs.json. Colour / opacity / scale exist for both kinds;
# the rotate / dupe / spread extras only for Outer folders and Displace only for Center folders.
DEFAULT_COMMON = {"color": WHITE, "opacity": 100, "size": 0, "stretch_x": 0, "stretch_y": 0}
DEFAULT_OUTER = dict({"dupe": 1, "rotate_dupe": 0, "rotate_dupe_inv": False, "rotate_all": 0, "rotate_all_inv": False,
                      "spread": 0.0}, **DEFAULT_COMMON)
DEFAULT_CENTER = dict(DEFAULT_COMMON, rotate=0, displace_x=0.0, displace_y=0.0)
DEFAULTS = {"outer": DEFAULT_OUTER, "center": DEFAULT_CENTER}
MAX_DUPE = 64
MAX_CANVAS = 1024


def is_image(name):
    return name.lower().endswith(IMG_EXT)


def norm_section(kind, d):
    """Options of one folder with every value valid (invalid ones fall back to their default)."""
    d = d if isinstance(d, dict) else {}
    o = {}
    if kind == "outer":
        o["dupe"] = num(d.get("dupe"), 1, 1, MAX_DUPE, True)
        for k in ("rotate_dupe", "rotate_all"):
            o[k] = num(d.get(k), 0, 0, 359, True)
        o["spread"] = num(d.get("spread"), 0, -100, 100)
        for k in ("rotate_dupe_inv", "rotate_all_inv"):
            o[k] = bool(d.get(k, False))
    else:
        o["rotate"] = num(d.get("rotate"), 0, -359, 359, True)
        o["displace_x"] = num(d.get("displace_x"), 0, -100, 100)
        o["displace_y"] = num(d.get("displace_y"), 0, -100, 100)
    o["color"] = parse_rgb(d.get("color"), WHITE)
    o["opacity"] = num(d.get("opacity"), 100, 0, 100, True)
    o["size"] = num(d.get("size"), 0, -100, 100, True)
    o["stretch_x"] = num(d.get("stretch_x"), 0, -100, 500, True)
    o["stretch_y"] = num(d.get("stretch_y"), 0, -100, 500, True)
    return o


def norm_outer(d):
    return norm_section("outer", d)


def kind_of(fid):
    """'outer' / 'center' for a folder id such as '_Center/_Default'."""
    return "center" if fid.replace("\\", "/").split("/")[0] == os.path.basename(KIND_DIRS["center"]) else "outer"


SECTION_CFG = "Section_configs.json"
_sec_cache = {}


def section_cfg_path(fid):
    return os.path.join(abs_of(fid), SECTION_CFG)


def load_section_cfg(fid):
    """Outer options of ONE folder, read from the Section_configs.json inside it (defaults when missing or
    broken). Subfolders have their own file and are never affected."""
    p = section_cfg_path(fid)
    try:
        st = os.stat(p)
        sig = (st.st_mtime_ns, st.st_size)
    except OSError:
        return norm_section(kind_of(fid), None)
    hit = _sec_cache.get(p)
    if hit and hit[0] == sig:
        return dict(hit[1])
    try:
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = None
    o = norm_section(kind_of(fid), d)
    _sec_cache[p] = (sig, o)
    return dict(o)


def save_section_cfg(fid, opts):
    """Write a folder's Section_configs.json (atomically), only when its content changes."""
    kind = kind_of(fid)
    o = norm_section(kind, opts)
    p = section_cfg_path(fid)
    if not os.path.isdir(os.path.dirname(p)):
        return
    try:
        with open(p, "r", encoding="utf-8") as f:
            if norm_section(kind, json.load(f)) == o and os.path.getsize(p) > 2:
                return
    except (OSError, ValueError):
        pass
    tmp = p + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(o, f, indent=2)
        os.replace(tmp, p)
    except OSError:
        try:
            os.remove(tmp)
        except OSError:
            pass


def ensure_section_cfgs():
    """Every folder under Reticles/_Outer and Reticles/_Center gets its own Section_configs.json."""
    for kind in ("outer", "center"):
        for dirpath, _dirs, names in os.walk(KIND_DIRS[kind]):
            if dirpath == KIND_DIRS[kind] and not any(is_image(n) for n in names):
                continue        # the _Outer / _Center root only counts when images lie directly in it
            if not os.path.isfile(os.path.join(dirpath, SECTION_CFG)):
                save_section_cfg(rel_of(dirpath), None)


def make_default_images():
    """Procedural defaults, used when no bundled Reticles folder exists: {kind: {file name: PIL image}}."""
    from PIL import Image, ImageDraw
    S = 4

    def canvas(n=64):
        return Image.new("RGBA", (n * S, n * S), (0, 0, 0, 0)), n

    def fin(im, n):
        return im.resize((n, n), Image.LANCZOS)

    W = (255, 255, 255, 255)
    outer = {}
    im, n = canvas()
    d = ImageDraw.Draw(im)
    for box in ((30, 10, 34, 26), (30, 38, 34, 54), (10, 30, 26, 34), (38, 30, 54, 34)):
        d.rounded_rectangle([c * S for c in box], radius=2 * S, fill=W)
    outer["Plus.png"] = fin(im, n)
    im, n = canvas()
    d = ImageDraw.Draw(im)
    d.rectangle([30 * S, 4 * S, 34 * S, 60 * S], fill=W)
    d.rectangle([4 * S, 30 * S, 60 * S, 34 * S], fill=W)
    outer["Cross.webp"] = fin(im, n)
    im, n = canvas()
    ImageDraw.Draw(im).ellipse([10 * S, 10 * S, 54 * S, 54 * S], outline=W, width=2 * S)
    outer["Circle.webp"] = fin(im, n)
    im, n = canvas()
    ImageDraw.Draw(im).polygon([(32 * S, 20 * S), (46 * S, 44 * S), (18 * S, 44 * S)], outline=W, width=2 * S)
    outer["Triangle.webp"] = fin(im, n)
    center = {}
    im, n = canvas()
    ImageDraw.Draw(im).ellipse([29 * S, 29 * S, 35 * S, 35 * S], fill=W)
    center["Dot.png"] = fin(im, n)
    return {"outer": outer, "center": center}


KIND_DIRS = {"outer": os.path.join(RETICLES_DIR, "_Outer"), "center": os.path.join(RETICLES_DIR, "_Center")}


def default_folder(kind):
    return os.path.join(KIND_DIRS[kind], "_Default")


# The whole Reticles folder is packed into the exe (the .bat adds it as it is). It is pasted next to the exe when
# there is no Reticles folder yet. After that only two things are watched: the _Default folder of _Outer and of
# _Center (a deleted folder is restored with everything it had) and Plus.png / Dot.png inside them (restored
# when missing). Any other file or folder is never touched, deleted ones are not brought back.
BUNDLE_DIR = os.path.join(RES_DIR, "Reticles")
REQUIRED = {"outer": "Plus.png", "center": "Dot.png"}


def bundle_ok():
    """A packed Reticles folder exists and is not the live one (running from source it is the same folder)."""
    return os.path.isdir(BUNDLE_DIR) and os.path.abspath(BUNDLE_DIR) != os.path.abspath(RETICLES_DIR)


def _copy_tree(src, dst):
    """Copy a folder tree without overwriting anything that already exists."""
    for dirpath, _dirs, names in os.walk(src):
        out = os.path.join(dst, os.path.relpath(dirpath, src))
        os.makedirs(out, exist_ok=True)
        for n in names:
            if not os.path.exists(os.path.join(out, n)):
                shutil.copyfile(os.path.join(dirpath, n), os.path.join(out, n))


def _bundled_default(kind):
    p = os.path.join(BUNDLE_DIR, os.path.basename(KIND_DIRS[kind]), "_Default")
    return p if bundle_ok() and os.path.isdir(p) else ""


def _save_procedural(kind, only=None):
    folder = default_folder(kind)
    os.makedirs(folder, exist_ok=True)
    try:
        for n, im in make_default_images()[kind].items():
            if (only is None or n == only) and not os.path.exists(os.path.join(folder, n)):
                im.save(os.path.join(folder, n), lossless=True)
    except Exception as e:
        print("Could not create the default reticles:", e)


def paste_bundle():
    """No Reticles folder yet (first run): paste the whole packed one."""
    if bundle_ok() and not os.path.isdir(RETICLES_DIR):
        try:
            _copy_tree(BUNDLE_DIR, RETICLES_DIR)
        except OSError as e:
            print("Could not copy the packed Reticles folder:", e)


def restore_default_folder(kind):
    """The _Default folder of a kind was deleted: bring it back with everything it had."""
    src = _bundled_default(kind)
    if src:
        try:
            _copy_tree(src, default_folder(kind))
            return
        except OSError as e:
            print("Could not restore", default_folder(kind), "-", e)
    _save_procedural(kind)


def restore_required(kind):
    """Plus.png (_Outer) / Dot.png (_Center) are the defaults: restored whenever they are missing."""
    name = REQUIRED[kind]
    dst = os.path.join(default_folder(kind), name)
    if os.path.isfile(dst):
        return
    src = _bundled_default(kind)
    if src and os.path.isfile(os.path.join(src, name)):
        os.makedirs(default_folder(kind), exist_ok=True)
        shutil.copyfile(os.path.join(src, name), dst)
    else:
        _save_procedural(kind, name)


def _unique_dest(folder, name):
    base, ext = os.path.splitext(name)
    dst, i = os.path.join(folder, name), 2
    while os.path.exists(dst):
        dst = os.path.join(folder, "%s (%d)%s" % (base, i, ext))
        i += 1
    return dst


def _merge_move(src, dst_dir):
    """Move a file or folder into dst_dir without overwriting anything."""
    name = os.path.basename(src)
    dst = os.path.join(dst_dir, name)
    if os.path.isdir(src) and os.path.isdir(dst):
        for n in os.listdir(src):
            _merge_move(os.path.join(src, n), dst)
        try:
            os.rmdir(src)
        except OSError:
            pass
    else:
        os.makedirs(dst_dir, exist_ok=True)
        shutil.move(src, _unique_dest(dst_dir, name))


def clean_current():
    """_Current must hold a single reticle: all but one (random) are deleted."""
    try:
        files = [n for n in os.listdir(CURRENT_DIR) if is_image(n)]
    except OSError:
        return
    if len(files) > 1:
        keep = random.choice(files)
        for n in files:
            if n != keep:
                try:
                    os.remove(os.path.join(CURRENT_DIR, n))
                except OSError:
                    pass


def ensure_dirs():
    """Make the Reticles tree; anything lying in Reticles outside _Outer/_Center/_Current moves into _Outer."""
    paste_bundle()
    os.makedirs(RETICLES_DIR, exist_ok=True)
    for d in list(KIND_DIRS.values()) + [CURRENT_DIR, SNAP_DIR]:
        os.makedirs(d, exist_ok=True)
    keep = {"_outer", "_center", "_current"}
    for n in os.listdir(RETICLES_DIR):
        if n.lower() in keep:
            continue
        try:
            _merge_move(os.path.join(RETICLES_DIR, n), KIND_DIRS["outer"])
        except OSError as e:
            print("Could not move", n, "into _Outer:", e)
    for kind in KIND_DIRS:
        if not os.path.isdir(default_folder(kind)):
            restore_default_folder(kind)
        restore_required(kind)
    clean_current()
    ensure_section_cfgs()


def rel_of(path):
    return os.path.relpath(path, RETICLES_DIR).replace("\\", "/")


def abs_of(rel):
    return os.path.join(RETICLES_DIR, *rel.split("/"))


def kind_sections(kind):
    """-> [(folder id (path under Reticles), label, [file paths])] ; _Default first, then by name."""
    base = KIND_DIRS[kind]
    out = []
    for dirpath, dirs, names in os.walk(base):
        dirs.sort(key=str.lower)
        files = [os.path.join(dirpath, n) for n in sorted(names, key=str.lower) if is_image(n)]
        if files:
            sub = os.path.relpath(dirpath, base).replace("\\", "/")
            out.append((rel_of(dirpath), "" if sub == "." else sub, files))
    out.sort(key=lambda s: (s[1] != "_Default", s[1].lower()))
    return out


def prune_selected(sel):
    """Selection {kind: [relative paths]} without broken links: missing files, files outside the kind's folder,
    and more than one pick per folder are dropped."""
    out = {}
    sel = sel if isinstance(sel, dict) else {}
    for kind in KIND_DIRS:
        seen, keep = set(), []
        for rel in (sel.get(kind) or []):
            if not isinstance(rel, str):
                continue
            rel = rel.replace("\\", "/")
            p = abs_of(rel)
            try:
                inside = os.path.commonpath([os.path.abspath(p), os.path.abspath(KIND_DIRS[kind])]) == \
                    os.path.abspath(KIND_DIRS[kind])
            except ValueError:
                inside = False
            folder = os.path.dirname(rel)
            if inside and is_image(rel) and os.path.isfile(p) and folder not in seen:
                seen.add(folder)
                keep.append(rel)
        out[kind] = keep
    return out


def current_name():
    try:
        for n in sorted(os.listdir(CURRENT_DIR)):
            if is_image(n):
                return n
    except OSError:
        pass
    return None


_img_cache = {}


def load_rgba(path):
    from PIL import Image
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        stamp = None
    hit = _img_cache.get(path)
    if hit and hit[0] == stamp:
        return hit[1]
    with Image.open(path) as im:
        a = np.asarray(im.convert("RGBA"), np.uint8).copy()
    if len(_img_cache) > 200:
        _img_cache.clear()
    _img_cache[path] = (stamp, a)
    return a


def _premul(rgba):
    a = rgba.astype(np.float32) / 255.0
    a[..., :3] *= a[..., 3:4]
    return a


def _straight(pm):
    a = np.clip(pm[..., 3:4], 0, 1)
    rgb = np.where(a > 1e-6, pm[..., :3] / np.maximum(a, 1e-6), 0.0)
    return np.clip(np.rint(np.concatenate([rgb, a], -1) * 255), 0, 255).astype(np.uint8)


def _resample_pm(pm, size=None, angle=None, filt=None):
    """Resize (size=(w, h)) or rotate (angle, expanding the canvas) a premultiplied float RGBA array.
    Every channel is resampled as a float image, so there is no 8-bit rounding of the edge pixels (that
    rounding is what tinted / bled the soft edges), and the overshoot of the filter is clamped."""
    from PIL import Image
    chans = []
    for k in range(4):
        im = Image.fromarray(np.ascontiguousarray(pm[..., k], np.float32), "F")
        if size is not None:
            im = im.resize(size, filt)
        else:
            im = im.rotate(angle, resample=filt, expand=True)
        chans.append(np.asarray(im, np.float32))
    out = np.stack(chans, -1)
    a = np.clip(out[..., 3], 0.0, 1.0)
    out[..., 3] = a
    out[..., :3] = np.clip(out[..., :3], 0.0, a[..., None])
    return out


def _paste_over(canvas, im, left, top):
    """canvas, im: float premultiplied HxWx4. Pastes im with its top-left at (left, top), alpha 'over'."""
    H, W = canvas.shape[:2]
    h, w = im.shape[:2]
    x0, y0 = max(0, left), max(0, top)
    x1, y1 = min(W, left + w), min(H, top + h)
    if x1 <= x0 or y1 <= y0:
        return
    src = im[y0 - top:y1 - top, x0 - left:x1 - left]
    dst = canvas[y0:y1, x0:x1]
    canvas[y0:y1, x0:x1] = src + dst * (1.0 - src[..., 3:4])


def stack_images(paths):
    """All images centred on one even-sized canvas -> premultiplied float array, or None."""
    ims = []
    for p in paths:
        try:
            ims.append(_premul(load_rgba(p)))
        except Exception:
            pass
    if not ims:
        return None
    W = max(i.shape[1] for i in ims)
    H = max(i.shape[0] for i in ims)
    W += W % 2
    H += H % 2
    c = np.zeros((H, W, 4), np.float32)
    for i in ims:
        _paste_over(c, i, (W - i.shape[1]) // 2, (H - i.shape[0]) // 2)
    return c


def _rotate_pm(pm, deg):
    """Rotate a premultiplied float image clockwise by `deg`, growing the canvas.
    Multiples of 90 are exact (no resampling at all). Other angles are supersampled: the image is
    enlarged smoothly (which also softens the stair-steps of hard-edged sprites), rotated, and averaged
    back down, which gives clean anti-aliased edges instead of stair-stepped or smeared ones."""
    from PIL import Image
    deg = deg % 360
    if deg == 0:
        return pm
    if deg % 90 == 0:
        return np.ascontiguousarray(np.rot90(pm, k=-(deg // 90)))
    big = max(pm.shape[:2])
    ss = 4 if big <= 256 else 2 if big <= 512 else 1
    if ss == 1:
        r = _resample_pm(pm, angle=-deg, filt=Image.BICUBIC)
        return np.pad(r, ((0, r.shape[0] % 2), (0, r.shape[1] % 2), (0, 0)))
    h0, w0 = pm.shape[:2]
    hi = _resample_pm(pm, size=(w0 * ss, h0 * ss), filt=Image.BICUBIC)
    hi = _resample_pm(hi, angle=-deg, filt=Image.BILINEAR)
    h, w = hi.shape[:2]
    # the result must have EVEN sides (a multiple of 2 * ss before averaging down): an odd-sized layer sits
    # half a pixel off the centre of the (even) canvas it is placed on, which showed up as a rotated sight not
    # lining up with a centre dot. Padding is split evenly, so the error is at most 1 / (2 * ss) px.
    m = 2 * ss
    ph, pw = (-h) % m, (-w) % m
    if ph or pw:
        hi = np.pad(hi, ((ph // 2, ph - ph // 2), (pw // 2, pw - pw // 2), (0, 0)))
    h, w = hi.shape[:2]
    return hi.reshape(h // ss, ss, w // ss, ss, 4).mean((1, 3), dtype=np.float32)


def outer_transform(base, opts):
    """Duplicate / rotate / spread the combined outer image around its centre."""
    o = norm_outer(opts)
    n = o["dupe"]
    h0, w0 = base.shape[:2]
    sd = -1 if o["rotate_dupe_inv"] else 1
    sa = -1 if o["rotate_all_inv"] else 1
    # Spread pushes each copy outward along the direction its own content points to (e.g. a line
    # drawn below the centre points down). Symmetric images have no direction -> 0 deg = right.
    al = base[..., 3].astype(np.float64)
    tot = al.sum()
    base_ang = 0.0
    if tot > 0:
        cy = (al.sum(1) * (np.arange(h0) - (h0 - 1) / 2.0)).sum() / tot
        cx = (al.sum(0) * (np.arange(w0) - (w0 - 1) / 2.0)).sum() / tot
        if math.hypot(cx, cy) > 0.5:
            base_ang = math.degrees(math.atan2(cy, cx))
    placed = []
    for i in range(n):
        rot = i * o["rotate_dupe"] * sd + o["rotate_all"] * sa
        arr = _rotate_pm(base, rot)
        # every copy, the original included, moves the same distance from the centre
        ms = 1
        ang = math.radians(base_ang + rot)
        dx = o["spread"] * ms * math.cos(ang)
        dy = o["spread"] * ms * math.sin(ang)
        ih, iw = arr.shape[:2]
        placed.append((arr, int(round(dx - iw / 2.0)), int(round(dy - ih / 2.0))))
    hw = max(max(abs(l), abs(l + a.shape[1])) for a, l, t in placed)
    hh = max(max(abs(t), abs(t + a.shape[0])) for a, l, t in placed)
    W = int(min(MAX_CANVAS, 2 * hw))
    H = int(min(MAX_CANVAS, 2 * hh))
    W, H = max(2, W + W % 2), max(2, H + H % 2)
    c = np.zeros((H, W, 4), np.float32)
    for arr, l, t in placed:
        _paste_over(c, arr, l + W // 2, t + H // 2)
    return c


def _section_layer(kind, paths, opts, plain):
    """One folder's picked image with its own options applied -> (premultiplied array, dx, dy) or None.
    Order: Outer extras (dupe / rotate / spread), Center rotate, colour + opacity, Size, then Center displace.
    `plain` skips everything except the Outer extras (used by the unmodified Outer / Center box previews)."""
    im = stack_images(paths)
    if im is None:
        return None
    o = norm_section(kind, opts)
    if kind == "outer":
        im = outer_transform(im, o)
    if plain:
        return im, 0, 0
    if kind == "center" and o["rotate"]:
        im = _rotate_pm(im, o["rotate"])        # about the image's own centre, before it is displaced
    rgba = _straight(im)
    rgba = recolor(rgba, o["color"], o["opacity"])
    pm = _premul(rgba)
    if o["size"]:
        # Size: grow / shrink the finished image by N px on its longer side (aspect kept), after everything
        # that rotates or spreads it, so those never get distorted by it
        from PIL import Image
        h, w = pm.shape[:2]
        big = max(h, w)
        f = max(2.0, big + o["size"]) / float(big)
        nw, nh = max(2, int(round(w * f))), max(2, int(round(h * f)))
        nw, nh = nw + nw % 2, nh + nh % 2           # even sides keep the layer exactly centred on the canvas
        pm = _resample_pm(pm, size=(nw, nh), filt=Image.LANCZOS if f < 1 else Image.BICUBIC)
    if o["stretch_x"] or o["stretch_y"]:
        # Stretch: the very last step on the folder's image (after Size, rotation, spread...), along the canvas
        # horizontal / vertical, in percent (-100 flattens it down to a hairline, +100 doubles it)
        from PIL import Image
        h, w = pm.shape[:2]
        nw = int(round(w * max(0.0, 1 + o["stretch_x"] / 100.0)))
        nh = int(round(h * max(0.0, 1 + o["stretch_y"] / 100.0)))
        nw, nh = min(max(2, nw), 2 * MAX_CANVAS), min(max(2, nh), 2 * MAX_CANVAS)
        nw, nh = nw + nw % 2, nh + nh % 2
        pm = _resample_pm(pm, size=(nw, nh), filt=Image.LANCZOS if nw * nh < w * h else Image.BICUBIC)
    dx = dy = 0
    if kind == "center":
        dx, dy = int(round(o["displace_x"])), int(round(o["displace_y"]))
    return pm, dx, dy


def compose(outer_paths, center_paths, overrides=None, plain=False):
    """Outer folders, then Center folders on top -> uint8 RGBA array (None when nothing is picked).
    Every folder is built on its own from ITS Section_configs.json (`overrides` {folder id: options} replaces a
    folder's file, used for live previews) and the results are layered around one common centre."""
    placed = []
    for kind, paths in (("outer", outer_paths), ("center", center_paths)):
        groups = {}
        for p in paths:
            groups.setdefault(rel_of(os.path.dirname(p)), []).append(p)
        for fid, ps in groups.items():
            opts = (overrides or {}).get(fid)
            lay = _section_layer(kind, ps, load_section_cfg(fid) if opts is None else opts, plain)
            if lay is not None:
                arr, dx, dy = lay
                ih, iw = arr.shape[:2]
                placed.append((arr, int(round(dx - iw / 2.0)), int(round(dy - ih / 2.0))))
    if not placed:
        return None
    hw = max(max(abs(l), abs(l + a.shape[1])) for a, l, t in placed)
    hh = max(max(abs(t), abs(t + a.shape[0])) for a, l, t in placed)
    W = int(min(MAX_CANVAS, 2 * hw))
    H = int(min(MAX_CANVAS, 2 * hh))
    W, H = max(2, W + W % 2), max(2, H + H % 2)
    cv = np.zeros((H, W, 4), np.float32)
    for arr, l, t in placed:
        _paste_over(cv, arr, l + W // 2, t + H // 2)
    return _straight(cv)


def recolor(rgba, color, opacity):
    """Pure white (and grey) parts become the colour; coloured parts get a proportional hue shift so
    their shading survives. Opacity (0-100) scales the alpha."""
    a = rgba.astype(np.float32) / 255.0
    r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    mx, mn = a[..., :3].max(-1), a[..., :3].min(-1)
    v = mx
    s = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-6), 0.0)
    tr, tg, tb = (c / 255.0 for c in color)
    th, ts, _tv = colorsys.rgb_to_hsv(tr, tg, tb)
    tmax = max(tr, tg, tb)
    out = np.zeros_like(a[..., :3])
    grey = s < 0.15
    # grey/white: v scales the colour, so pure white becomes exactly the colour
    gscale = v[..., None]
    out[:] = np.stack([tr, tg, tb])[None, None, :] * gscale
    # coloured: rotate hue by (target hue - dominant hue)
    col = ~grey & (al > 0)
    if col.any():
        d = mx - mn
        dd = np.where(d == 0, 1, d)
        h = np.where(mx == r, ((g - b) / dd) % 6, np.where(mx == g, (b - r) / dd + 2, (r - g) / dd + 4)) / 6.0
        wts = (s * al)[col]
        ang = h[col] * 2 * math.pi
        ref = math.atan2(float((np.sin(ang) * wts).sum()), float((np.cos(ang) * wts).sum())) / (2 * math.pi)
        if ts > 0.05:
            nh, ns, shade = (h + (th - ref)) % 1.0, s, 1.0
        else:
            nh, ns, shade = h, s * 0.0, (tmax if tmax > 0 else 1.0)
        i = np.floor(nh * 6).astype(int) % 6
        f = nh * 6 - np.floor(nh * 6)
        p, q, t = v * (1 - ns), v * (1 - f * ns), v * (1 - (1 - f) * ns)
        rr = np.choose(i, [v, q, p, p, t, v])
        gg = np.choose(i, [t, v, v, q, p, p])
        bb = np.choose(i, [p, p, t, v, v, q])
        out[col] = (np.stack([rr, gg, bb], -1) * shade)[col]
    res = np.empty_like(rgba)
    res[..., :3] = np.clip(np.rint(out * 255), 0, 255).astype(np.uint8)
    res[..., 3] = np.clip(np.rint(al * (clamp(opacity, 0, 100) / 100.0) * 255), 0, 255).astype(np.uint8)
    return res


def scale_min(rgba):
    """The smallest Scale Adjust (%) that still leaves the reticle at least 1 px on its short side."""
    m = max(1, min(rgba.shape[0], rgba.shape[1]))
    return min(0.0, math.ceil((-100.0 + 100.0 / m) * 10) / 10.0)


def outline_rgba(rgba, width=1.5, blur=3.0, opacity=70.0):
    """POST Outline: a soft black outline drawn *behind* the finished reticle (the reticle itself is untouched).
    width = thickness in px (fractions allowed), blur = strength (Gaussian sigma = blur / 2 px),
    opacity = 0-100. The canvas grows by the outline's reach so nothing is cut off."""
    width, blur, op = max(0.0, float(width)), max(0.0, float(blur)), clamp(float(opacity), 0, 100) / 100.0
    if (width <= 0 and blur <= 0) or op <= 0:
        return rgba
    sigma = blur / 2.0
    pad = int(np.ceil(width + 2.5 * sigma)) + 1
    pm = np.pad(_premul(rgba), ((pad, pad), (pad, pad), (0, 0)))
    a = pm[..., 3]
    # dilate the alpha by `width`: every offset inside the radius contributes with its coverage (soft edge)
    grown = a.copy()
    r = int(np.ceil(width + 0.5))
    h, w = a.shape
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            wgt = min(1.0, max(0.0, width + 0.5 - (dx * dx + dy * dy) ** 0.5))
            if wgt <= 0 or (dx == 0 and dy == 0):
                continue
            sh = np.zeros_like(a)
            sh[max(0, dy):h + min(0, dy), max(0, dx):w + min(0, dx)] = \
                a[max(0, -dy):h - max(0, dy), max(0, -dx):w - max(0, dx)] * wgt
            np.maximum(grown, sh, out=grown)
    if sigma > 0:
        grown = _blur_f(grown, sigma)
    # "own pixels" = how much of a pixel the reticle covers, judged against its neighbours so that a semi-transparent
    # reticle (alpha 0.5 all over its strokes) counts as fully covered inside and the black never darkens it there
    near = a.copy()
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            if dx or dy:
                sh = np.zeros_like(a)
                sh[max(0, dy):h + min(0, dy), max(0, dx):w + min(0, dx)] = \
                    a[max(0, -dy):h - max(0, dy), max(0, -dx):w - max(0, dx)]
                np.maximum(near, sh, out=near)
    cover = np.where(near > 0, a / np.maximum(near, 1e-6), 0.0)
    ring = np.clip(grown, 0, 1) * op * (1.0 - cover)
    out = pm.copy()
    out[..., 3] = a + ring                              # black underneath: premultiplied colour stays as it is
    return _straight(out)


def _blur_f(arr, sigma):
    """Gaussian blur of a float image (separable kernel, edge-zero)."""
    k = int(np.ceil(sigma * 3))
    x = np.arange(-k, k + 1, dtype=np.float32)
    g = np.exp(-(x * x) / (2 * sigma * sigma))
    g /= g.sum()
    p = np.pad(arr, k)
    t = sum(g[i] * p[:, i:i + arr.shape[1]] for i in range(2 * k + 1))
    return sum(g[i] * t[i:i + arr.shape[0], :] for i in range(2 * k + 1))


def scale_rgba(rgba, pct):
    """Resize around the image centre: +pct% bigger, -pct% smaller (0 leaves it alone)."""
    from PIL import Image
    h, w = rgba.shape[:2]
    f = 1.0 + max(float(pct), scale_min(rgba)) / 100.0
    nw, nh = max(1, int(round(w * f))), max(1, int(round(h * f)))
    if (nw, nh) == (w, h):
        return rgba
    return _straight(_resample_pm(_premul(rgba), size=(nw, nh), filt=Image.LANCZOS if f < 1 else Image.BICUBIC))




def write_current(rgba, scale=0):
    """Scale the finished reticle (every folder already has its own colour / opacity / extras / displace)
    and make it the only file in _Current."""
    from PIL import Image
    ensure_dirs()
    img = scale_rgba(rgba, scale)
    dst = os.path.join(CURRENT_DIR, CURRENT_FILE)
    tmp = os.path.join(CURRENT_DIR, "~tmp_" + CURRENT_FILE)
    Image.fromarray(img, "RGBA").save(tmp, "WEBP", lossless=True)
    for n in os.listdir(CURRENT_DIR):
        if n != os.path.basename(tmp) and is_image(n):
            try:
                os.remove(os.path.join(CURRENT_DIR, n))
            except OSError:
                pass
    os.replace(tmp, dst)
    return dst


def game_resolution_id(files):
    """The game's resolution setting (mResolutionType in BrgGame\\Config\\BrgGraphicsConfig.ini), None when unreadable."""
    import re
    if not files or not files.game:
        return None
    p = os.path.join(files.game, "BrgGame", "Config", "BrgGraphicsConfig.ini")
    try:
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            m = re.search(r"^\s*mResolutionType\s*=\s*(\d+)", f.read(), re.M | re.I)
    except OSError:
        return None
    return int(m.group(1)) if m else None


def os_resolution():
    """Pixel size of the computer's (primary) screen: (0, 0) when it cannot be read."""
    try:
        u = ctypes.windll.user32
        return int(u.GetSystemMetrics(0)), int(u.GetSystemMetrics(1))
    except Exception:
        return 0, 0


def screen_resolution():
    """Pixel size of the monitor the game is on: the borderless tool reports it (it knows which monitor it put the game
    on, even a second one); without it, the computer's primary screen."""
    try:
        with open(BORDERLESS_STATUS, "r", encoding="utf-8") as f:
            d = json.load(f)
        w, h = (int(v) for v in d["monitor"])
        if w > 0 and h > 0 and pid_alive(int(d["pid"])):
            return w, h
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return os_resolution()


def snapshot_key(files):
    """Name of the photo that fits the game's resolution setting AND the computer's screen, e.g. '12_1920x1080'.
    '' when either cannot be read."""
    rid, (w, h) = game_resolution_id(files), screen_resolution()
    return "%d_%dx%d" % (rid, w, h) if rid is not None and w and h else ""


def save_snapshot(rgb, key):
    """Keep the photo of the game (RGB uint8 array) in _Current\\_InGameAim\\<key>.webp (lossy, small). It is only ever
    shown behind the preview; it is not a reticle and no reticle list looks into that folder."""
    from PIL import Image
    if not key:
        raise MakerError("the resolution of the game or of the screen is unknown")
    os.makedirs(SNAP_DIR, exist_ok=True)
    dst = os.path.join(SNAP_DIR, key + ".webp")
    tmp = os.path.join(SNAP_DIR, "~tmp_" + key + ".webp")
    Image.fromarray(np.ascontiguousarray(rgb), "RGB").save(tmp, "WEBP", quality=SNAP_QUALITY, method=4)
    old = snapshot_meta(key)                    # a retake keeps the deviation stored in the photo it replaces
    os.replace(tmp, dst)
    if old:
        try:
            set_snapshot_meta(key, old[0], old[1])
        except Exception:
            pass
    return dst


def load_snapshot(key):
    """-> (RGB uint8 array, file mtime) of the photo for this resolution combination, or (None, None)."""
    from PIL import Image
    if not key:
        return None, None
    p = os.path.join(SNAP_DIR, key + ".webp")
    try:
        with Image.open(p) as im:
            return np.array(im.convert("RGB")), os.path.getmtime(p)
    except Exception:
        return None, None


def _riff_chunks(data):
    out, i = [], 12
    while i + 8 <= len(data):
        tag, size = data[i:i + 4], int.from_bytes(data[i + 4:i + 8], "little")
        out.append((tag, data[i + 8:i + 8 + size]))
        i += 8 + size + (size & 1)
    return out


def _riff_build(chunks):
    body = b"WEBP"
    for tag, payload in chunks:
        body += tag + len(payload).to_bytes(4, "little") + payload + (b"\0" if len(payload) & 1 else b"")
    return b"RIFF" + len(body).to_bytes(4, "little") + body


_META_TAG = b"LIDv"


def set_snapshot_meta(key, dev_x, dev_y):
    """Write the deviation this photo needs inside the photo itself (an extra chunk of the .webp: the picture is not
    re-encoded, so nothing is lost). Used by Patch Reticle / Original Deviate to remember it per photo."""
    p = os.path.join(SNAP_DIR, key + ".webp")
    with open(p, "rb") as f:
        data = f.read()
    if data[:4] != b"RIFF" or data[8:12] != b"WEBP":
        raise MakerError("the photo is not a webp file")
    chunks = [c for c in _riff_chunks(data) if c[0] != _META_TAG]
    chunks.append((_META_TAG, ("%d,%d" % (int(dev_x), int(dev_y))).encode("ascii")))
    tmp = p + ".tmp"
    with open(tmp, "wb") as f:
        f.write(_riff_build(chunks))
    os.replace(tmp, p)


def snapshot_meta(key):
    """-> (dev_x, dev_y) stored in the photo, or None when it has none (or there is no photo)."""
    if not key:
        return None
    try:
        with open(os.path.join(SNAP_DIR, key + ".webp"), "rb") as f:
            data = f.read()
        for tag, payload in _riff_chunks(data):
            if tag == _META_TAG:
                x, y = payload.decode("ascii").split(",")
                return int(x), int(y)
    except Exception:
        pass
    return None


def user_deviation(files, patch=None):
    """The deviation the user set, as it is in the game now: BrgGameBase.upk minus the fixed centring patch that
    Patch Reticle adds (only while the HUD holds the custom reticle). 0 / 0 = nothing deviated. None when unreadable."""
    raw = base_deviation(files)
    if raw is None:
        return None
    try:
        check_hud(files.hud)
        return raw                                  # original HUD: nothing was patched
    except MakerError:
        px_, py_ = Config().values().patch if patch is None else patch
        return (raw[0] - px_, raw[1] - py_)


def base_deviation(files):
    """The deviation now written in the game's BrgGameBase.upk: (x, y), or None when it cannot be read."""
    try:
        with open(files.base, "rb") as f:
            return tuple(sprite_state(read_hud(f.read()))[1])
    except Exception:
        return None


# ---------------------------------------------------------------- presets
PRESET_FORMAT = "reticle-maker-preset"
_BAD = object()


def _p_bool(v):
    return v if isinstance(v, bool) else _BAD


def _p_num(lo, hi, integer=False):
    def f(v):
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            return _BAD
        v = clamp(v, lo, hi)
        return int(round(v)) if integer else float(v)
    return f


def _p_color(v):
    out = parse_rgb(v, None) if isinstance(v, (list, tuple, str)) else None
    return list(out) if out else _BAD


def _p_choice(choices):
    def f(v):
        return next((c for c in choices if isinstance(v, str) and c.lower() == v.lower()), _BAD)
    return f


def _p_key(v):
    if v == "":
        return ""
    vk = vk_of(v) if isinstance(v, str) else 0
    return VK_NAMES[vk] if vk else _BAD


def _p_selected(v):
    return v if isinstance(v, dict) else _BAD


# what a preset carries from reticle_config.json: the Reticle Deviation, shortcuts, the global reticle options
PRESET_RULES = {
    "deviation_x": _p_num(-DEV_LIMIT, DEV_LIMIT, True), "deviation_y": _p_num(-DEV_LIMIT, DEV_LIMIT, True),
    "snapshot_hold_seconds": _p_num(0.2, 60),
    "mouse_key": _p_choice(MOUSE_CHOICES), "keyboard_key": _p_key,
    "joystick_key": _p_choice(JOY_CHOICES), "ui_hotkey": _p_key,
    "hide_grid": _p_bool, "hide_preview_grid": _p_bool, "reticle_scale": _p_num(-99.9, 500), "override_color": _p_color,
    "override_enabled": _p_bool, "subtract_opacity": _p_num(0, 100, True), "post_outline": _p_bool,
    "outline_width": _p_num(0, 20), "outline_blur": _p_num(0, 30), "outline_opacity": _p_num(0, 100),
    "selected": _p_selected,
}


def build_preset(cfg):
    """Everything the UI is configured with, as one JSON-able dict. Machine specific values (the steam.exe path
    and the warning choice) are not included."""
    sections = {}
    for kind in ("outer", "center"):
        for fid, _label, _files in kind_sections(kind):
            sections[fid] = norm_section(kind, load_section_cfg(fid))
    settings = {k: json.loads(json.dumps(cfg.get(k))) for k in PRESET_RULES if cfg.get(k) is not None}
    return {"format": PRESET_FORMAT, "version": 1, "settings": settings, "sections": sections}


def reset_all(cfg):
    """Start over: every folder's Section_configs.json and every preset setting back to its default.
    The steam.exe path is kept. -> (folders reset, settings reset)."""
    n = 0
    for kind in ("outer", "center"):
        for fid, _l, _f in kind_sections(kind):
            save_section_cfg(fid, None)
            n += 1
    defaults = {k: json.loads(json.dumps(DEFAULT_CFG[k])) for k in PRESET_RULES if k in DEFAULT_CFG}
    cfg.set(**defaults)
    return n, len(defaults)


def apply_preset(data, cfg):
    """Apply a preset dict. Whatever is unknown, not found here or invalid is ignored.
    -> (folders applied, settings applied)."""
    if not isinstance(data, dict) or data.get("format") != PRESET_FORMAT:
        raise ValueError("not a Reticle Maker preset")
    known = {fid: kind for kind in ("outer", "center") for fid, _l, _f in kind_sections(kind)}
    secs = data.get("sections") if isinstance(data.get("sections"), dict) else {}
    n_sec = 0
    for fid, o in secs.items():
        fid = fid.replace("\\", "/") if isinstance(fid, str) else None
        if fid in known and isinstance(o, dict):
            save_section_cfg(fid, o)
            n_sec += 1
    setts = data.get("settings") if isinstance(data.get("settings"), dict) else {}
    good = {}
    for k, rule in PRESET_RULES.items():
        if k in setts:
            v = rule(setts[k])
            if v is not _BAD:
                good[k] = v
    if "selected" in good:
        good["selected"] = prune_selected(good["selected"])     # picks whose files are not here are dropped
    if good:
        cfg.set(**good)
    return n_sec, len(good)


# ---------------------------------------------------------------- reticles that remember how they were made
META_FORMAT = "reticle-maker-reticle"
META_KEYS = ("reticle_scale", "override_enabled", "override_color", "subtract_opacity", "post_outline",
             "outline_width", "outline_blur", "outline_opacity")
META_TAG = "reticle_maker_config"            # PNG text chunk name; WebP keeps it inside an XMP packet
_XMP = ('<x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
        '<rdf:Description rdf:about="" xmlns:rm="urn:reticlemaker:1"><rm:config>%s</rm:config></rdf:Description>'
        '</rdf:RDF></x:xmpmeta>')


def build_reticle_meta(cfg, sel):
    """Only what shaped THIS reticle: the picked images, the options of the folders they come from and the global
    options that touch the final image. Nothing else of the UI."""
    picks = {k: [r for r in sel.get(k, [])] for k in ("outer", "center")}
    sections = {}
    for kind in ("outer", "center"):
        for rel in picks[kind]:
            fid = os.path.dirname(rel)
            sections[fid] = norm_section(kind, load_section_cfg(fid))
    glob = {k: json.loads(json.dumps(cfg.get(k))) for k in META_KEYS if cfg.get(k) is not None}
    return {"format": META_FORMAT, "version": 1, "selected": picks, "sections": sections, "global": glob}


def _meta_blob(meta):
    import base64
    return base64.b64encode(json.dumps(meta, separators=(",", ":")).encode("utf-8")).decode("ascii")


def read_reticle_meta(path):
    """The metadata dict stored in a .config.png / .config.webp, or None when the image has none."""
    import base64
    import re
    from PIL import Image
    try:
        with Image.open(path) as im:
            info = dict(im.info)
        blob = info.get(META_TAG)
        if blob is None and info.get("xmp"):
            m = re.search(rb"<rm:config>([A-Za-z0-9+/=]+)</rm:config>", info["xmp"])
            blob = m.group(1).decode("ascii") if m else None
        if not blob:
            return None
        data = json.loads(base64.b64decode(blob).decode("utf-8"))
    except Exception:
        return None
    return data if isinstance(data, dict) and data.get("format") == META_FORMAT else None


def apply_reticle_meta(meta, cfg):
    """Bring back the options of a saved reticle. Images or folders that are not here are ignored, and only the
    folders of the (still existing) picks are touched. -> the valid picks {kind: [paths]}.
    Raises ValueError when none of its images exist any more (nothing is changed then)."""
    sel = prune_selected(meta.get("selected") if isinstance(meta.get("selected"), dict) else {})
    if not (sel["outer"] or sel["center"]):
        raise ValueError("none of its images were found")
    secs = meta.get("sections") if isinstance(meta.get("sections"), dict) else {}
    for kind in ("outer", "center"):
        for rel in sel[kind]:
            fid = os.path.dirname(rel)
            if isinstance(secs.get(fid), dict):
                save_section_cfg(fid, secs[fid])
    good = {}
    g = meta.get("global") if isinstance(meta.get("global"), dict) else {}
    for k in META_KEYS:
        if k in g and k in PRESET_RULES:
            v = PRESET_RULES[k](g[k])
            if v is not _BAD:
                good[k] = v
    good["selected"] = sel
    cfg.set(**good)
    return sel


def save_preview(rgba, scale=0, meta=None):
    """Same image Apply makes, but kept as a new reticle straight inside _Outer (not in _Default or _Current),
    named <unix time><3 random letters>.config.webp, with `meta` (how it was built) stored inside the file."""
    from PIL import Image
    ensure_dirs()
    img = scale_rgba(rgba, scale)
    while True:
        name = "%d%s.config.webp" % (int(time.time()), "".join(random.choice("abcdefghijklmnopqrstuvwxyz") for _ in range(3)))
        dst = os.path.join(KIND_DIRS["outer"], name)
        if not os.path.exists(dst):
            break
    tmp = dst + ".tmp"
    kw = {"xmp": (_XMP % _meta_blob(meta)).encode("utf-8")} if meta else {}
    Image.fromarray(img, "RGBA").save(tmp, "WEBP", lossless=True, **kw)
    os.replace(tmp, dst)
    return dst