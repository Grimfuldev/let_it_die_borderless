#!/usr/bin/env python3
"""
Let It Die Borderless Tool

Forces Let It Die (BrgGame-Steam.exe) into borderless windowed mode when the
game is running in regular Windowed mode (NOT exclusive fullscreen).

Requirements (running from source):
    pip install pywin32 pygame-ce pillow

Build a standalone exe:
    run build_exe.bat   (UI_Assets\\ must sit next to this script)

Usage:
  1. Set the game to Windowed (BrgGraphicsConfig.ini -> mbFullScreen=False).
  2. Start the game and wait until it is past the launch screen.
  3. Run this tool (as Administrator if the game runs elevated).
  4. Pick an aspect option and click "Make Borderless".
  5. "Stop Borderless" restores the original window.
  6. "Reticle" opens the Reticle Maker (reticle_maker.py) in its own window.

Aspect options:
  - Fill Screen        : cover the whole monitor (what you normally want)
  - 16:9, 16:10, ...   : largest centered area of that ratio on the monitor
  - Native size        : keep the game's current pixel size, centered
"""
import configparser
import ctypes
import json
import math
import os
import socket
import subprocess
import sys
import threading
import time
from ctypes import wintypes

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True

APP_TITLE = "Let It Die Borderless"
VERSION = "v0.4"


def fatal(msg):
    """Show a message even when running as a windowed exe (no console)."""
    try:
        ctypes.windll.user32.MessageBoxW(None, msg, APP_TITLE, 0x10)
    except Exception:
        print(msg)
    sys.exit(1)


try:
    import pygame
    import pywintypes
    import win32api
    import win32con
    import win32gui
    import win32process
    from PIL import Image
except ImportError as e:
    fatal(f"Missing dependency: {e.name}\n\nInstall with:\n"
          "pip install pywin32 pygame-ce pillow")

# ------------------------------------------------------------------ config
EXE_PREFIX = "brggame"          # matches BrgGame-Steam.exe (case-insensitive)
MIN_WINDOW_AREA = 100 * 100     # ignore tiny helper windows
POLL_MS = 1000                  # how often to recheck once the game is found
WAIT_POLL_MS = 3000             # how often to look for the game while waiting
GWL_STYLE, GWL_EXSTYLE = -16, -20
ERROR_ACCESS_DENIED = 5
APP_ID = "Grimfuldev.LID.Borderless"

NATIVE = "native"
ASPECTS = {                     # label -> ratio | None (fill) | NATIVE
    "Fill Screen (ignore aspect)": None,
    "16:9": 16 / 9,
    "16:10": 16 / 10,
    "4:3": 4 / 3,
    "21:9": 21 / 9,
    "32:9": 32 / 9,
    "Native size (centered)": NATIVE,
}

# Extended-style bits that draw an edge/3D frame
EX_EDGE_BITS = (
    win32con.WS_EX_DLGMODALFRAME | win32con.WS_EX_CLIENTEDGE
    | win32con.WS_EX_STATICEDGE | win32con.WS_EX_WINDOWEDGE
)

# ------------------------------------------------------------------- paths
FROZEN = getattr(sys, "frozen", False)
SCRIPT_DIR = os.path.dirname(sys.executable if FROZEN else os.path.abspath(__file__))
RES_DIR = getattr(sys, "_MEIPASS", SCRIPT_DIR)          # packed assets live here
UI_ASSETS = os.path.join(RES_DIR, "UI_Assets")

BG_FILE = "UI background.webp"
GLASSES_FILE = "uncle glasses ready.webp"
CURSOR_FILE = "let it die cursor.webp"
ICO_FILE = "Lidico.ico"


def find_ui(name):
    for root in (UI_ASSETS, SCRIPT_DIR):
        p = os.path.join(root, name)
        if os.path.isfile(p):
            return p
    return ""


# ---------------------------------------------------------------- settings
SETTINGS_FILE = os.path.join(SCRIPT_DIR, "borderless_settings.ini")   # next to the exe
LOCK_FILE = os.path.join(SCRIPT_DIR, "borderless.lock")
CANCEL_FILE = os.path.join(SCRIPT_DIR, "borderless_cancel_close.flag")   # the Reticle window's Cancel button
STATUS_FILE = os.path.join(SCRIPT_DIR, "borderless_status.json")   # tells the Reticle window if borderless is on
STATE_FILE = os.path.join(SCRIPT_DIR, "borderless_state.json")   # the window's original style (Stop after a restart)
DEFAULT_ASPECT = next(iter(ASPECTS))
DEFAULT_HOTKEY = ""           # no shortcut until the user picks one
DEFAULT_AUTO_DELAY_SECONDS = 10  # configurable in borderless_settings.ini


def load_settings():
    """-> aspect, auto_borderless, hotkey, start_minimized, disable_shortcut, auto_delay_seconds, close_with_game."""
    aspect, auto, hotkey, start_min, disable_sc = DEFAULT_ASPECT, False, DEFAULT_HOTKEY, False, False
    auto_delay_seconds = DEFAULT_AUTO_DELAY_SECONDS
    close_with_game = False
    cp = configparser.ConfigParser()
    try:
        cp.read(SETTINGS_FILE, encoding="utf-8")
        if cp.has_section("borderless"):
            a = cp.get("borderless", "aspect", fallback=DEFAULT_ASPECT).strip()
            aspect = a if a in ASPECTS else DEFAULT_ASPECT
            auto = cp.getboolean("borderless", "auto_borderless", fallback=False)
            h = cp.get("borderless", "hotkey", fallback=DEFAULT_HOTKEY).strip()
            hotkey = h
            start_min = cp.getboolean("borderless", "start_minimized", fallback=False)
            disable_sc = cp.getboolean("borderless", "disable_shortcut", fallback=False)
            auto_delay_seconds = cp.getint(
                "borderless", "auto_delay_seconds",
                fallback=DEFAULT_AUTO_DELAY_SECONDS)
            auto_delay_seconds = max(0, min(auto_delay_seconds, 3600))
            close_with_game = cp.getboolean("borderless", "close_with_game", fallback=False)
    except (configparser.Error, ValueError, OSError):
        auto_delay_seconds = DEFAULT_AUTO_DELAY_SECONDS
    return aspect, auto, hotkey, start_min, disable_sc, auto_delay_seconds, close_with_game


def save_settings(aspect, auto, hotkey):
    """Write UI-changeable settings. start_minimized is left as-is (ini-only)."""
    cp = configparser.ConfigParser()
    try:
        cp.read(SETTINGS_FILE, encoding="utf-8")
    except (configparser.Error, OSError):
        pass
    if not cp.has_section("borderless"):
        cp.add_section("borderless")
    cp.set("borderless", "aspect", aspect)
    cp.set("borderless", "auto_borderless", "true" if auto else "false")
    cp.set("borderless", "hotkey", hotkey)
    # preserve ini-only options
    if not cp.has_option("borderless", "start_minimized"):
        cp.set("borderless", "start_minimized", "false")
    if not cp.has_option("borderless", "disable_shortcut"):
        cp.set("borderless", "disable_shortcut", "false")
    if not cp.has_option("borderless", "close_with_game"):
        cp.set("borderless", "close_with_game", "false")    # true: exit 5 s after the game closes (with a Cancel)
    if not cp.has_option("borderless", "auto_delay_seconds"):
        cp.set("borderless", "auto_delay_seconds", str(DEFAULT_AUTO_DELAY_SECONDS))
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            cp.write(f)
    except OSError:
        pass


# ------------------------------------------------------------ hotkeys
# RegisterHotKey, not a low-level keyboard hook. A hook sits on every
# key and can make the game lose the key-up (W stays pressed).
_HOTKEY_ID = 0xB10          # Hide UI
_RET_HOTKEY_ID = 0xB11      # show / hide the Reticle window (its key is chosen in that window)
_registered = {}            # id -> virtual key currently registered


def _vk_from_char(ch):
    """Virtual-key code for a single character (0 when there is none)."""
    if not ch:
        return 0
    ch = ch[0]
    if ch == "=":
        return 0xBB          # VK_OEM_PLUS on US layouts
    if ch == "-":
        return 0xBD
    try:
        vk = ctypes.windll.user32.VkKeyScanW(ord(ch))
        return 0 if vk == -1 else vk & 0xFF
    except Exception:
        return 0


def _unregister(hid):
    _registered.pop(hid, None)
    try:
        ctypes.windll.user32.UnregisterHotKey(None, hid)
    except Exception:
        pass


def _register(hid, vk):
    """Register one hotkey (MOD_NOREPEAT: holding the key does not spam). vk 0 only removes it."""
    _unregister(hid)
    if not vk:
        return
    try:
        if ctypes.windll.user32.RegisterHotKey(None, hid, 0x4000, vk) or \
                ctypes.windll.user32.RegisterHotKey(None, hid, 0, vk):
            _registered[hid] = vk
    except Exception:
        pass


def _uninstall_hooks():
    for hid in (_HOTKEY_ID, _RET_HOTKEY_ID):
        _unregister(hid)


def consume_hotkeys():
    """Pull WM_HOTKEY only (the ids that fired). Leaves every other message for pygame."""
    ids = set()
    try:
        user32 = ctypes.windll.user32
        msg = wintypes.MSG()
        while user32.PeekMessageW(ctypes.byref(msg), None, 0x0312, 0x0312, 1):   # WM_HOTKEY, PM_REMOVE
            ids.add(int(msg.wParam))
    except Exception:
        pass
    return ids


def reticle_hotkey_vk():
    """Virtual key of the Reticle window's shortcut (saved in reticle_config.json), 0 when it has none."""
    try:
        with open(os.path.join(SCRIPT_DIR, "reticle_config.json"), "r", encoding="utf-8") as f:
            name = str(json.load(f).get("ui_hotkey") or "")
    except (OSError, ValueError, AttributeError):
        return 0
    if not name:
        return 0
    try:
        import reticle_maker
        return reticle_maker.vk_of(name)
    except Exception:
        return 0


# ---------------------------------------------------------------- lock file
def write_lock():
    try:
        with open(LOCK_FILE, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
    except OSError:
        pass


def clear_lock():
    try:
        if os.path.isfile(LOCK_FILE):
            os.remove(LOCK_FILE)
    except OSError:
        pass


def pid_alive(pid):
    if pid <= 0:
        return False
    try:
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
        if h:
            ctypes.windll.kernel32.CloseHandle(h)
            return True
    except Exception:
        pass
    return False


def clear_stale_lock():
    """Remove a lock left by a previous crash / force-shutdown."""
    if not os.path.isfile(LOCK_FILE):
        return
    try:
        raw = open(LOCK_FILE, "r", encoding="utf-8").read().strip()
        old = int(raw or "0")
        if not pid_alive(old):
            os.remove(LOCK_FILE)
    except Exception:
        try:
            os.remove(LOCK_FILE)
        except Exception:
            pass
_K32 = None
_PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


def _kernel32():
    global _K32
    if _K32 is None:
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.OpenProcess.restype = wintypes.HANDLE
        k.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        k.QueryFullProcessImageNameW.argtypes = (
            wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD))
        k.CloseHandle.argtypes = (wintypes.HANDLE,)
        _K32 = k
    return _K32


def enable_dpi_awareness():
    """Must run before any window is created, or screen sizes come back scaled."""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)      # per-monitor
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def ui_scale():
    """System DPI scale (1.0 = 96 dpi) so the window isn't tiny on HiDPI screens."""
    try:
        return min(3.0, max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96))
    except Exception:
        return 1.0


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin():
    """True if the elevated copy was started (False if the UAC prompt was declined)."""
    args = sys.argv[1:] if FROZEN else sys.argv
    params = " ".join(f'"{a}"' for a in args) or None
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)
    return int(ret) > 32


def to_signed32(v):
    v &= 0xFFFFFFFF
    return v - 0x100000000 if v & 0x80000000 else v


def exe_name(pid):
    """Lowercase exe file name of a process, or '' if it can't be read."""
    k = _kernel32()
    h = k.OpenProcess(_PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = wintypes.DWORD(len(buf))
        if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return buf.value.rsplit("\\", 1)[-1].lower()
        return ""
    finally:
        k.CloseHandle(h)


def find_game_pids():
    """PIDs of BrgGame-Steam.exe via tasklist. Avoids matching editors."""
    pids = set()
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq BrgGame-Steam.exe", "/FO", "CSV", "/NH"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stderr=subprocess.DEVNULL,
            text=True,
            errors="ignore",
        )
    except Exception:
        return pids
    for line in out.splitlines():
        line = line.strip()
        if not line or "brggame" not in line.lower():
            continue
        # "BrgGame-Steam.exe","1234","Console","1","12,345 K"
        parts = [p.strip().strip('"') for p in line.split(",")]
        if len(parts) >= 2 and parts[1].isdigit():
            pids.add(int(parts[1]))
    return pids


def find_game_window():
    """Largest visible top-level window owned by BrgGame-Steam.exe, or None."""
    game_pids = find_game_pids()
    if not game_pids:
        return None
    best = [0, None]

    def visit(hwnd, _):
        if not win32gui.IsWindowVisible(hwnd):
            return True
        try:
            pid = win32process.GetWindowThreadProcessId(hwnd)[1]
            if pid not in game_pids:
                return True
            l, t, r, b = win32gui.GetWindowRect(hwnd)
        except pywintypes.error:
            return True
        area = (r - l) * (b - t)
        if area > MIN_WINDOW_AREA and area > best[0]:
            best[0], best[1] = area, hwnd
        return True

    win32gui.EnumWindows(visit, None)
    return best[1]


class _GUID(ctypes.Structure):
    _fields_ = [("d1", ctypes.c_uint32), ("d2", ctypes.c_ushort), ("d3", ctypes.c_ushort), ("d4", ctypes.c_ubyte * 8)]


def _guid(text):
    import uuid
    return _GUID.from_buffer_copy(uuid.UUID(text).bytes_le)


def mark_fullscreen(hwnd, on):
    """Tell the Windows shell to treat this window as a fullscreen one (ITaskbarList2::MarkFullscreenWindow), so the
    taskbar stays hidden / does not pop up over it even when it does not cover the whole monitor. Best effort:
    returns False when it did not work, and nothing else depends on it."""
    try:
        ole = ctypes.windll.ole32
        ole.CoInitializeEx(None, 2)                     # apartment threaded; S_FALSE (already done) is fine
        obj = ctypes.c_void_p()
        hr = ole.CoCreateInstance(ctypes.byref(_guid("56FDF344-FD6D-11d0-958A-006097C9A090")), None, 1,
                                  ctypes.byref(_guid("602D4995-B13A-429b-A66E-1935E44F4317")), ctypes.byref(obj))
        if hr != 0 or not obj.value:
            return False
        vtbl = ctypes.cast(obj, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        this = obj
        init = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p)(vtbl[3])
        mark = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int)(vtbl[8])
        release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtbl[2])
        ok = init(this) == 0 and mark(this, hwnd, 1 if on else 0) == 0
        release(this)
        return ok
    except Exception:
        return False


_BD_CLASS = ""


def _backdrop_class():
    """Register (once) the window class of the black backdrop and return its name."""
    global _BD_CLASS
    if not _BD_CLASS:
        wc = win32gui.WNDCLASS()
        wc.lpszClassName = "LIDBorderlessBackdrop"
        wc.hInstance = win32api.GetModuleHandle(None)
        wc.hbrBackground = win32gui.GetStockObject(win32con.BLACK_BRUSH)
        wc.hCursor = win32gui.LoadCursor(0, win32con.IDC_ARROW)
        wc.lpfnWndProc = {win32con.WM_NCHITTEST: lambda hwnd, msg, wp, lp: -1}     # HTTRANSPARENT: clicks go through
        try:
            win32gui.RegisterClass(wc)
        except pywintypes.error:
            pass                                    # already registered
        _BD_CLASS = wc.lpszClassName
    return _BD_CLASS


def monitor_rect(hwnd):
    """(left, top, right, bottom) of the monitor the window is on."""
    try:
        mon = win32api.MonitorFromWindow(hwnd, win32con.MONITOR_DEFAULTTONEAREST)
        return win32api.GetMonitorInfo(mon)["Monitor"]
    except pywintypes.error:
        return 0, 0, win32api.GetSystemMetrics(0), win32api.GetSystemMetrics(1)


def client_size(hwnd):
    l, t, r, b = win32gui.GetClientRect(hwnd)
    return r - l, b - t


# ----------------------------------------------------------- image helpers
def load_image(path):
    """Any image (webp/png/...) -> pygame surface with per-pixel alpha."""
    im = Image.open(path).convert("RGBA")
    return pygame.image.frombuffer(im.tobytes(), im.size, "RGBA").convert_alpha()


def load_background(path, w, h):
    """Scale-to-cover + center-crop, done once at start-up."""
    im = Image.open(path).convert("RGB")
    k = max(w / im.width, h / im.height)
    nw, nh = round(im.width * k), round(im.height * k)
    im = im.resize((nw, nh), Image.Resampling.LANCZOS)
    left, top = (nw - w) // 2, (nh - h) // 2
    im = im.crop((left, top, left + w, top + h))
    return pygame.image.frombuffer(im.tobytes(), im.size, "RGB").convert()


def scaled(surf, size):
    if size == surf.get_width():
        return surf
    fn = pygame.transform.scale if size % surf.get_width() == 0 else pygame.transform.smoothscale
    return fn(surf, (size, size))


def wrap_text(font, text, width):
    """Word-wrap `text` (honours \\n) to `width` pixels; breaks over-long words."""
    lines = []
    for para in text.split("\n"):
        cur = ""
        for word in para.split(" "):
            trial = f"{cur} {word}".strip()
            if font.size(trial)[0] <= width:
                cur = trial
                continue
            if cur:
                lines.append(cur)
            while font.size(word)[0] > width and len(word) > 1:   # hard-break
                n = len(word)
                while n > 1 and font.size(word[:n])[0] > width:
                    n -= 1
                lines.append(word[:n])
                word = word[n:]
            cur = word
        lines.append(cur)
    return lines


# ------------------------------------------------------------------ theme
C_TEXT = (224, 224, 228)
C_DIM = (146, 146, 154)
C_FAINT = (92, 92, 100)
C_LINE = (62, 62, 70)
C_BTN = (40, 40, 46)
C_BTN_HOT = (56, 56, 64)
C_BTN_DOWN = (28, 28, 32)
C_BTN_OFF = (24, 24, 28)
C_BORDER = (98, 98, 106)
C_BORDER_HOT = (176, 176, 184)
C_BORDER_OFF = (50, 50, 56)

WIN_W, WIN_H = 440, 322


# --------------------------------------------------------------------- app
class App:
    def __init__(self):
        pygame.display.init()
        pygame.font.init()
        self.S = ui_scale()
        s = self.s
        # settings before the window, so we can create it already hidden
        (aspect, self.auto, self.hotkey, self.start_minimized,
         self.disable_shortcut, self.auto_delay_seconds, self.close_with_game) = load_settings()
        if not self.hotkey or self.disable_shortcut:
            self.start_minimized = False    # nothing could bring a hidden window back
        self.auto_delay_ms = self.auto_delay_seconds * 1000
        flags = 0
        if self.start_minimized and hasattr(pygame, "HIDDEN"):
            flags |= pygame.HIDDEN
        self.screen = pygame.display.set_mode((s(WIN_W), s(WIN_H)), flags)
        pygame.display.set_caption(f"{APP_TITLE} {VERSION}")
        # hide immediately, before chrome or the first frame can show it
        self._win_hwnd = pygame.display.get_wm_info().get("window")
        if self.start_minimized and self._win_hwnd:
            try:
                win32gui.ShowWindow(self._win_hwnd, win32con.SW_HIDE)
            except Exception:
                pass

        # state
        self.running = True
        self.hwnd = None
        self.is_borderless = False
        self._saved = None              # (style, exstyle, rect) for restore
        self.status = "Looking for the game..."
        self.options = list(ASPECTS)
        self.aspect_idx = self.options.index(aspect)
        self.auto_deadline = None       # tick (ms) at which auto-borderless fires
        self._prev_found = None         # None = first poll; then True/False
        self.game_seen = False          # True once the game has been found this session
        self.ui_visible = not self.start_minimized
        self.capturing_hotkey = False
        if not os.path.isfile(SETTINGS_FILE):
            self.save()                 # create the ini on first launch
        self.want = False               # the user asked for borderless: kept (or re-applied) until Stop
        self._applied = None            # (x, y, w, h) the window was put at
        self._native = None             # the game's own client size before the first Make Borderless
        self._reapply_at = None         # tick (ms) at which a lost borderless is applied again
        self._gone_since = None         # tick (ms) since which no game process was seen
        self._backdrop = 0              # black window behind the game when it does not fill its monitor
        self._bd_at = 0
        self._closing_until = None      # tick (ms) at which the program exits after the game closed (close_with_game)
        self._published = None          # (is_borderless, monitor size) as last written to STATUS_FILE
        self._mon = None                # pixel size of the monitor the game is on (last one seen)
        self._fix_at = 0                # last time a reset of the window was repaired
        self.reticle_proc = None
        self.reticle_port = 0
        self._ret_vk = 0
        self._next_hk_sync = 0
        self.notice = ""                # message of the automatic update step (shown under the status)
        self.notice_until = 0.0
        self.dd_open = False
        self.pressed = None             # "make" | "stop" | "reticle" | ("modal", i)
        self.modal = None               # {"lines": [...], "buttons": [(label, cb)], ...}
        self._next_poll = 0

        # fonts
        names = "segoeui,arial"
        self.f_body = pygame.font.SysFont(names, s(13))
        self.f_btn = pygame.font.SysFont(names, s(13), bold=True)
        self.f_small = pygame.font.SysFont(names, s(11))

        # layout
        self.r_status = pygame.Rect(s(16), s(16), s(408), s(58))
        self.r_dd = pygame.Rect(s(16), s(110), s(408), s(30))
        self.r_make = pygame.Rect(s(16), s(158), s(196), s(38))
        self.r_stop = pygame.Rect(s(228), s(158), s(196), s(38))
        self.r_auto = pygame.Rect(s(16), s(212), s(160), s(24))
        self.r_hotkey = pygame.Rect(s(190), s(212), s(234), s(24))
        self.r_reticle = pygame.Rect(s(16), s(254), s(408), s(38))
        self.item_h = s(24)
        self.r_list = pygame.Rect(self.r_dd.x, self.r_dd.bottom + s(2),
                                  self.r_dd.w, self.item_h * len(self.options) + s(2))

        self.r_list = pygame.Rect(self.r_dd.x, self.r_dd.bottom + s(2),
                                  self.r_dd.w, self.item_h * len(self.options) + s(2))

        # assets (every one is optional: the tool still works without them)
        self.bg = None
        self.glasses = None
        p = find_ui(BG_FILE)
        if p:
            try:
                self.bg = load_background(p, *self.screen.get_size())
            except Exception:
                pass
        p = find_ui(GLASSES_FILE)
        if p:
            try:
                self.glasses = load_image(p)
            except Exception:
                pass
        self.panel = pygame.Surface(self.r_status.size, pygame.SRCALPHA)
        self.panel.fill((0, 0, 0, 120))
        self.dim = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        self.dim.fill((0, 0, 0, 170))

        self._chrome()
        self._win_hwnd = pygame.display.get_wm_info().get("window")
        self._install_main_hotkey()
        if self.start_minimized:
            self._hide_ui()
        if reticle_wanted():
            self.spawn_reticle("hidden")        # a baked reticle is in use: its window waits for its shortcut
        threading.Thread(target=self._auto_update, daemon=True).start()

    def s(self, v):
        return int(round(v * self.S))

    # ---- window chrome: dark title bar, glasses title icon, Lidico taskbar icon, cursor
    def _chrome(self):
        if self.glasses:
            try:
                pygame.display.set_icon(self.glasses)       # title bar (small) icon
            except Exception:
                pass
        try:
            hwnd = pygame.display.get_wm_info().get("window")
            if hwnd:
                ico = find_ui(ICO_FILE)
                if ico:                                     # taskbar (big) + title bar icon
                    self._ico, self._hwnd_ico = ico, hwnd
                    apply_taskbar_icon(hwnd, ico)
                black, dark = ctypes.c_int(0), ctypes.c_int(1)
                dwm = ctypes.windll.dwmapi
                dwm.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(dark), 4)    # dark mode
                dwm.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(black), 4)   # caption color
                dwm.DwmSetWindowAttribute(hwnd, 34, ctypes.byref(black), 4)   # border color
        except Exception:
            pass
        p = find_ui(CURSOR_FILE)
        if p:
            try:
                pygame.mouse.set_cursor((0, 0), scaled(load_image(p), self.s(32)))
            except Exception:
                pass

    # ---- logic (unchanged behaviour) ---------------------------------------
    def _now(self):
        return pygame.time.get_ticks()

    def save(self):
        save_settings(self.options[self.aspect_idx], self.auto, self.hotkey)

    def _hide_ui(self):
        if not self._win_hwnd:
            return
        try:
            win32gui.ShowWindow(self._win_hwnd, win32con.SW_HIDE)
        except Exception:
            pass
        self.ui_visible = False

    def _show_ui(self):
        if not self._win_hwnd:
            return
        try:
            win32gui.ShowWindow(self._win_hwnd, win32con.SW_SHOW)
            win32gui.SetForegroundWindow(self._win_hwnd)
        except Exception:
            pass
        self.ui_visible = True

    def toggle_ui(self):
        if self.ui_visible:
            self._hide_ui()
        else:
            self._show_ui()

    def _install_main_hotkey(self):
        _register(_HOTKEY_ID, 0 if self.disable_shortcut else _vk_from_char(self.hotkey))
        self._next_hk_sync = 0

    def set_hotkey(self, ch):
        if not ch or len(ch) != 1 or not _vk_from_char(ch):
            return
        self.hotkey = ch
        self.save()

    def clear_hotkey(self):
        """Right click on the shortcut removes it."""
        self.hotkey = ""
        self.capturing_hotkey = False
        self.save()
        self._install_main_hotkey()

    def _begin_hotkey_capture(self):
        """While a new key is being picked no shortcut may be listening: a registered hotkey swallows its key."""
        self.capturing_hotkey = True
        _unregister(_HOTKEY_ID)
        _unregister(_RET_HOTKEY_ID)

    def _end_hotkey_capture(self):
        self.capturing_hotkey = False
        self._install_main_hotkey()

    def sync_reticle_hotkey(self):
        """The Reticle window's show/hide key lives in reticle_config.json; this program listens for it
        (a key equal to the Hide UI key is left to Hide UI, which then hides both windows)."""
        now = self._now()
        if now < self._next_hk_sync:
            return
        self._next_hk_sync = now + 1000
        vk = reticle_hotkey_vk()
        main_vk = _registered.get(_HOTKEY_ID, 0)
        want = 0 if (vk and vk == main_vk) else vk
        self._ret_vk = vk
        if want != _registered.get(_RET_HOTKEY_ID, 0):
            _register(_RET_HOTKEY_ID, want)

    def on_main_hotkey(self):
        if self._ret_vk and self._ret_vk == _registered.get(_HOTKEY_ID, 0):
            if self.ui_visible:
                self._hide_ui()
                self.send_reticle("hide_keep")
            else:
                self._show_ui()
                self.send_reticle("restore")
        else:
            self.toggle_ui()

    def can_make(self):
        # greyed out while an automatic apply is already pending
        return bool(self.hwnd) and not self.is_borderless and self.auto_deadline is None

    def _window_alive(self):
        return bool(self.hwnd) and win32gui.IsWindow(self.hwnd)

    def set_auto(self, on):
        if on == self.auto:
            return
        self.auto = on
        self.auto_deadline = None
        # Ticked while the game is already running -> short delay
        if on and self.hwnd and not self.is_borderless:
            self.auto_deadline = self._now() + self.auto_delay_ms
        self.save()

    def tick(self):
        """Called every loop: poll on a timer, fire a due auto-borderless, and repair a lost borderless."""
        now = self._now()
        if self._backdrop and now >= self._bd_at:
            self._bd_at = now + 500
            self._backdrop_keep()
        if now >= self._next_poll:
            self.poll()
            # While waiting for the game, check every 3 seconds.
            # Once found, check every second so a close is noticed quickly.
            interval = POLL_MS if (self.hwnd or self.game_seen) else WAIT_POLL_MS
            self._next_poll = now + interval
        if self.auto_deadline is not None and now >= self.auto_deadline:
            self.auto_deadline = None
            if self.auto and not self.is_borderless and not self.modal:
                self.hwnd = find_game_window() or self.hwnd
                if self._window_alive():
                    self.make_borderless()
        if self._window_alive():
            try:
                l, t, r, b = monitor_rect(self.hwnd)
                self._mon = (r - l, b - t)
            except Exception:
                pass
        if (self.is_borderless, self._mon) != self._published:
            self._publish()
        if self._closing_until is not None:
            if os.path.isfile(CANCEL_FILE):
                self.modal = None
                self._cancel_closing()
            elif now >= self._closing_until:
                self.running = False
        if self._reapply_at is not None and now >= self._reapply_at:
            self._reapply_at = None
            if self.want and self._window_alive() and not self.modal:
                self._reapply("The game made a new window: borderless applied again.")

    def poll(self):
        """Cheap while the game is up: one IsWindow call. Borderless is kept for as long as the game runs:
        the game re-creates or resets its window (main menu, loading) and that must not switch it off."""
        try:
            if not self._window_alive():
                self.hwnd = find_game_window()
                if self.hwnd:
                    self._gone_since = None
                    self.game_seen = True
                    title = win32gui.GetWindowText(self.hwnd) or "Let It Die"
                    w, h = client_size(self.hwnd)
                    self.status = f"Found: {title}\nClient size: {w}x{h}"
                    if self.want:               # a new window of the same game: borderless goes back on
                        self._reapply_at = self._now() + 1200
                elif self.game_seen:
                    # No window: gone for good only when the game process is gone as well (a window that is only
                    # being re-created, as in the main menu, comes back). 3 polls in a row = really closed.
                    if find_game_pids():
                        self._gone_since = None
                    elif self._gone_since is None:
                        self._gone_since = self._now()
                    # no game process for 1.5 s in a row: the game really stopped, so borderless is switched off
                    if self._gone_since is not None and self._now() - self._gone_since >= 1500:
                        if self.close_with_game:
                            self._begin_closing()
                            return
                        self._game_gone()
                        return
                elif self.want:
                    self.status = "Game closed. Start it again and click Make Borderless."
                else:
                    self.status = "Waiting for the game... (checking every 3s)"
            elif self.want and self.is_borderless and self._reapply_at is None:
                self._repair_if_reset()

            if self.hwnd and not self.is_borderless and self._already_borderless():
                self._adopt()               # never apply borderless on top of borderless

            # Auto Borderless scheduling
            found = bool(self.hwnd)
            if not found:
                self.auto_deadline = None
            elif (self.auto and not self.is_borderless and self.auto_deadline is None
                  and self._prev_found is not True):
                # first poll => game was already running; False->True => it just launched
                self.auto_deadline = self._now() + self.auto_delay_ms
            self._prev_found = found
        except Exception as e:      # show problems instead of hiding them
            self.status = f"Error while looking for the game: {e}"

    def _repair_if_reset(self):
        """The game put its frame or size back (main menu, loading screen): apply borderless again."""
        hwnd = self.hwnd
        if win32gui.IsIconic(hwnd) or not self._applied:
            return
        framed = win32gui.GetWindowLong(hwnd, GWL_STYLE) & (win32con.WS_CAPTION | win32con.WS_THICKFRAME)
        l, t, r, b = win32gui.GetWindowRect(hwnd)
        x, y, w, h = self._applied
        moved = any(abs(a - c) > 2 for a, c in zip((l, t, r - l, b - t), (x, y, w, h)))
        if (framed or moved) and self._now() - self._fix_at > 2000:
            self._fix_at = self._now()
            self._reapply("The game reset its window: borderless applied again.")

    def target_rect(self, native_size):
        l, t, r, b = monitor_rect(self.hwnd)
        mw, mh = r - l, b - t
        ratio = ASPECTS[self.options[self.aspect_idx]]

        if ratio is None:                                   # fill monitor
            return l, t, mw, mh
        if ratio == NATIVE:                                 # game's own size
            w, h = min(native_size[0], mw), min(native_size[1], mh)
        elif mw / mh > ratio:                               # height-limited
            h = mh
            w = int(h * ratio)
        else:                                               # width-limited
            w = mw
            h = int(w / ratio)
        return l + (mw - w) // 2, t + (mh - h) // 2, w, h

    def _publish(self):
        """The Reticle window takes photos only while borderless is on: tell it (and keep the file only while running)."""
        self._published = (self.is_borderless, self._mon)
        try:
            tmp = STATUS_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"pid": os.getpid(), "on": bool(self.is_borderless),
                           "monitor": list(self._mon) if self._mon else None}, f)
            os.replace(tmp, STATUS_FILE)
        except OSError:
            pass

    def _exclusive_fullscreen(self):
        """The game window has no frame and fills its whole monitor, and this tool did not make it so (no saved
        state of its own for this game run): that is how exclusive fullscreen looks from outside, and borderless
        cannot be applied on top of it."""
        try:
            if not self._window_alive() or win32gui.IsIconic(self.hwnd):
                return False
            if win32gui.GetWindowLong(self.hwnd, GWL_STYLE) & (win32con.WS_CAPTION | win32con.WS_THICKFRAME):
                return False
            if self._load_state() is not None:
                return False
            l, t, r, b = monitor_rect(self.hwnd)
            return all(abs(a - c) <= 1 for a, c in zip(win32gui.GetWindowRect(self.hwnd), (l, t, r, b)))
        except pywintypes.error:
            return False

    def _already_borderless(self):
        """The game window has no frame and already sits where the chosen aspect would put it (a previous run of this
        tool made it borderless). Applying it again would record that frame-less look as the 'original'."""
        try:
            if not self._window_alive() or win32gui.IsIconic(self.hwnd) or self._exclusive_fullscreen():
                return False
            if win32gui.GetWindowLong(self.hwnd, GWL_STYLE) & (win32con.WS_CAPTION | win32con.WS_THICKFRAME):
                return False
            x, y, w, h = self.target_rect(client_size(self.hwnd))
            return all(abs(a - b) <= 2 for a, b in zip(win32gui.GetWindowRect(self.hwnd), (x, y, x + w, y + h)))
        except pywintypes.error:
            return False

    def _window_pid(self):
        try:
            return win32process.GetWindowThreadProcessId(self.hwnd)[1]
        except pywintypes.error:
            return 0

    def _process_start(self):
        """When the game process was started (tells two processes with the same pid apart), '' when unknown."""
        try:
            h = win32api.OpenProcess(0x1000, False, self._window_pid())     # PROCESS_QUERY_LIMITED_INFORMATION
            try:
                return str(win32process.GetProcessTimes(h)["CreationTime"])
            finally:
                win32api.CloseHandle(h)
        except Exception:
            return ""

    def _save_state(self):
        """Remember the original window style so Stop Borderless still works after this program is restarted."""
        if not self._saved:
            return
        style, exstyle, rect = self._saved
        try:                                    # written to a temp file first: a force shutdown never leaves half a file
            tmp = STATE_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"pid": self._window_pid(), "started": self._process_start(), "style": style,
                           "exstyle": exstyle, "rect": list(rect), "native": list(self._native or ())}, f)
            os.replace(tmp, STATE_FILE)
        except OSError:
            pass

    def _load_state(self):
        """(style, exstyle, rect, native) saved for this game process, or None."""
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
            if int(d["pid"]) != self._window_pid() or str(d.get("started", "")) != self._process_start():
                return None                     # another game run (a pid can be reused): the file is stale
            return int(d["style"]), int(d["exstyle"]), tuple(int(v) for v in d["rect"]), tuple(d.get("native") or ())
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def _clear_state(self):
        try:
            if os.path.isfile(STATE_FILE):
                os.remove(STATE_FILE)
        except OSError:
            pass

    def _adopt(self):
        """Take over a window that is already borderless without changing it. Its original look comes from the
        saved state of the earlier run; without it a normal framed window in the middle of the monitor is used."""
        try:
            st = self._load_state()
            l, t, r, b = win32gui.GetWindowRect(self.hwnd)
            if st:
                self._saved, self._native = st[:3], (st[3] or None)
            else:
                ml, mt, mr, mb = monitor_rect(self.hwnd)
                w, h = min(1280, mr - ml), min(720, mb - mt)
                ex = win32gui.GetWindowLong(self.hwnd, GWL_EXSTYLE) | win32con.WS_EX_WINDOWEDGE
                self._saved = (0x10CF0000, ex, (ml + (mr - ml - w) // 2, mt + (mb - mt - h) // 2,
                                                ml + (mr - ml + w) // 2, mt + (mb - mt + h) // 2))
                self._native = None
            self._applied = (l, t, r - l, b - t)
            self.is_borderless = self.want = True
            self.auto_deadline = None
            self.status = (self.status + "\n" if self.status else "") + "Already borderless, left as it is."
        except pywintypes.error:
            pass

    def _begin_closing(self):
        """close_with_game: the program exits in 5 seconds, unless Cancel is pressed (here or in the Reticle window)."""
        if self._closing_until is not None:
            return
        try:
            os.remove(CANCEL_FILE)
        except OSError:
            pass
        self._closing_until = self._now() + 5000
        self.status = "Game closed. The program will be closed in 5 seconds."
        self.send_reticle("closing")
        if self.ui_visible:
            self.show_modal("The program will be closed in 5 seconds", [("Cancel", self._cancel_closing)])

    def _cancel_closing(self):
        self._closing_until = None
        self.send_reticle("closing_abort")
        try:
            os.remove(CANCEL_FILE)
        except OSError:
            pass
        self._game_gone()                   # carry on, waiting for the next start of the game

    def _game_gone(self):
        """The game closed and this program stays (close_with_game = false): back to waiting for it."""
        self.hwnd = None
        self.is_borderless = self.want = False
        self._saved = self._applied = self._native = None
        self._backdrop_off()
        self._reapply_at = None
        self.auto_deadline = None
        self._prev_found = False
        self.game_seen = False
        self._gone_since = None
        self._clear_state()
        self.status = "Game closed. Waiting for the game... (checking every 3s)"

    def _apply_frame(self, hwnd):
        """Style, size and place of the borderless window (the same recipe as the known-working Let It Die mod).
        WS_BORDER is left out on purpose: it draws a thin 1px line."""
        # A minimized/maximized window ignores SetWindowPos
        if win32gui.IsIconic(hwnd) or win32gui.GetWindowPlacement(hwnd)[1] == win32con.SW_SHOWMAXIMIZED:
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        exstyle = win32gui.GetWindowLong(hwnd, GWL_EXSTYLE)
        x, y, w, h = self.target_rect(self._native or client_size(hwnd))
        win32gui.SetWindowLong(hwnd, GWL_STYLE, to_signed32(win32con.WS_MAXIMIZE))
        win32gui.SetWindowLong(hwnd, GWL_EXSTYLE, to_signed32(exstyle & ~EX_EDGE_BITS))
        win32gui.SetWindowPos(hwnd, 0, x, y, w, h, win32con.SWP_SHOWWINDOW | win32con.SWP_FRAMECHANGED)
        self._applied = (x, y, w, h)
        mark_fullscreen(hwnd, True)             # taskbar stays hidden, also when the game does not fill the monitor
        self._backdrop_sync(hwnd, (x, y, w, h))
        return x, y, w, h

    # ---- black backdrop: everything on the monitor outside the game's picture is black
    def _backdrop_sync(self, hwnd, rect):
        """Show a plain black window over the whole monitor, right behind the game, when the game does not fill the
        monitor (any target other than Fill Screen). Hidden otherwise."""
        try:
            l, t, r, b = monitor_rect(hwnd)
            x, y, w, h = rect
            if x <= l and y <= t and x + w >= r and y + h >= b:
                self._backdrop_off()
                return
            if not self._backdrop or not win32gui.IsWindow(self._backdrop):
                # own window class with a black brush (a STATIC "black rect" shows grey in dark themes);
                # click-through, no taskbar button, never takes the focus
                self._backdrop = win32gui.CreateWindowEx(
                    0x80 | 0x08000000, _backdrop_class(), "", 0x80000000 | 0x10000000, l, t, r - l, b - t, 0, 0, 0, None)
            win32gui.SetWindowPos(self._backdrop, hwnd, l, t, r - l, b - t, win32con.SWP_NOACTIVATE | win32con.SWP_SHOWWINDOW)
        except Exception:
            self._backdrop_off()

    def _backdrop_off(self):
        bd, self._backdrop = self._backdrop, 0
        if bd:
            try:
                win32gui.DestroyWindow(bd)
            except Exception:
                pass

    def _backdrop_keep(self):
        """Keep the backdrop just behind the game window (and gone while the game is minimized or closed)."""
        if not self._backdrop:
            return
        try:
            if not self._window_alive() or win32gui.IsIconic(self.hwnd):
                win32gui.ShowWindow(self._backdrop, win32con.SW_HIDE)
                return
            win32gui.SetWindowPos(self._backdrop, self.hwnd, 0, 0, 0, 0,
                                  win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_NOACTIVATE | win32con.SWP_SHOWWINDOW)
        except Exception:
            pass

    def _reapply(self, text):
        try:
            self._apply_frame(self.hwnd)
            self.status = text
        except pywintypes.error as e:
            self.status = f"Could not apply borderless again: {e}"

    def make_borderless(self):
        if not self._window_alive():
            self.hwnd = find_game_window()
            if not self.hwnd:
                self.show_modal("Could not find the Let It Die window.", [("OK", None)])
                return
        if self.is_borderless:
            return
        if self._exclusive_fullscreen():
            self.auto_deadline = None
            self.status = "The game is in exclusive fullscreen: set it to Windowed first."
            self.show_modal("The game looks like it is in exclusive fullscreen, which borderless cannot change.\n\n"
                            "Set the game to Windowed (BrgGraphicsConfig.ini: mbFullScreen=False), restart it "
                            "and try again.", [("OK", None)])
            return
        if self._already_borderless():
            self._adopt()
            return
        hwnd = self.hwnd
        try:
            style = win32gui.GetWindowLong(hwnd, GWL_STYLE)
            exstyle = win32gui.GetWindowLong(hwnd, GWL_EXSTYLE)
            rect = win32gui.GetWindowRect(hwnd)
            self._native = client_size(hwnd)
            x, y, w, h = self._apply_frame(hwnd)
            self._saved = (style, exstyle, rect)
            self._save_state()
            self.is_borderless = True
            self.want = True
            self.status = f"Borderless active: {w}x{h} at ({x},{y})"
        except pywintypes.error as e:
            if e.winerror == ERROR_ACCESS_DENIED and not is_admin():
                self.show_modal(
                    "The game window can't be modified from a normal account.\n\n"
                    "Restart this tool as Administrator?",
                    [("Restart as Admin", self._restart_admin), ("Cancel", None)])
                return
            self.show_modal(f"Failed to apply borderless:\n{e}", [("OK", None)])
        except Exception as e:
            self.show_modal(f"Failed to apply borderless:\n{e}", [("OK", None)])

    def stop_borderless(self):
        self.is_borderless = False
        self.want = False
        self._reapply_at = None
        self.set_auto(False)            # Stop while Auto Borderless is on -> untick it
        try:
            if self._window_alive():
                mark_fullscreen(self.hwnd, False)
            if self._window_alive() and self._saved:
                style, exstyle, (l, t, r, b) = self._saved
                win32gui.SetWindowLong(self.hwnd, GWL_STYLE, style)
                win32gui.SetWindowLong(self.hwnd, GWL_EXSTYLE, exstyle)
                win32gui.SetWindowPos(self.hwnd, 0, l, t, r - l, b - t,
                                      win32con.SWP_SHOWWINDOW | win32con.SWP_FRAMECHANGED)
                self.status = "Restored original window."
        except Exception as e:
            self.show_modal(f"Failed to restore:\n{e}", [("OK", None)])
        self._saved = None
        self._applied = None
        self._native = None
        self._backdrop_off()
        self._clear_state()

    # ---- Reticle Maker (its own window, run as a second process of this program)
    def reticle_alive(self):
        return self.reticle_proc is not None and self.reticle_proc.poll() is None

    def spawn_reticle(self, mode):
        if self.reticle_alive():
            return True
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as t:
                t.bind(("127.0.0.1", 0))
                self.reticle_port = t.getsockname()[1]
            args = ["--reticle-ui", str(os.getpid()), str(self.reticle_port), mode]
            env = dict(os.environ)
            if FROZEN:
                cmd = [sys.executable] + args
                env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
            else:
                exe = sys.executable
                pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
                cmd = [pyw if os.path.isfile(pyw) else exe, os.path.abspath(__file__)] + args
            self.reticle_proc = subprocess.Popen(cmd, cwd=SCRIPT_DIR, env=env, creationflags=0x08000000)
            return True
        except Exception as e:
            self.status = f"Could not start the Reticle window: {e}"
            self.reticle_proc = None
            return False

    def send_reticle(self, cmd):
        if not self.reticle_alive() or not self.reticle_port:
            return
        try:
            ctypes.windll.user32.AllowSetForegroundWindow(-1)
        except Exception:
            pass
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as t:
                t.sendto(cmd.encode(), ("127.0.0.1", self.reticle_port))
        except OSError:
            pass

    def open_reticle(self):
        if self.reticle_alive():
            self.send_reticle("show")
        else:
            try:
                ctypes.windll.user32.AllowSetForegroundWindow(-1)
            except Exception:
                pass
            self.spawn_reticle("show")

    def shutdown_reticle(self):
        if self.reticle_alive():
            self.send_reticle("quit")
            try:
                self.reticle_proc.wait(2.0)
            except Exception:
                pass
            if self.reticle_alive():
                try:
                    self.reticle_proc.terminate()
                except Exception:
                    pass

    def _auto_update(self):
        """Once per start: redo what a game update undid (SHA unlock, baked reticle) when "auto_reapply" is on."""
        try:
            import reticle_maker
            msg = reticle_maker.auto_unlock_sha()
        except Exception as e:
            msg = f"Auto update failed: {e}"
        if msg:
            self.notice_until = time.time() + 30       # stays visible a while: the status line changes every 3 s
            self.notice = msg

    def _restart_admin(self):
        if relaunch_as_admin():
            self.running = False
        else:
            self.status = "Administrator restart was cancelled."

    # ---- modal dialog (dark, in-app) ----------------------------------------
    def show_modal(self, text, buttons):
        s = self.s
        box_w = s(372)
        lines = wrap_text(self.f_body, text, box_w - s(40))
        lh = self.f_body.get_linesize()
        btn_h, btn_w, gap = s(32), s(148), s(12)
        box_h = s(20) + lh * len(lines) + s(20) + btn_h + s(20)
        box = pygame.Rect(0, 0, box_w, box_h)
        box.center = self.screen.get_rect().center
        total = len(buttons) * btn_w + (len(buttons) - 1) * gap
        x0 = box.centerx - total // 2
        rects = [pygame.Rect(x0 + i * (btn_w + gap), box.bottom - s(20) - btn_h, btn_w, btn_h)
                 for i in range(len(buttons))]
        self.modal = {"lines": lines, "buttons": buttons, "box": box, "rects": rects}
        self.dd_open = False
        self.pressed = None

    def _modal_pick(self, i):
        cb = self.modal["buttons"][i][1]
        self.modal = None
        if cb:
            cb()

    # ---- input ---------------------------------------------------------------
    def handle(self, ev):
        t = ev.type
        if t == pygame.QUIT:
            self.running = False
        elif t == pygame.KEYDOWN:
            if self.capturing_hotkey:
                # Accept a single printable character as the new hotkey (Esc cancels)
                if ev.unicode and len(ev.unicode) == 1 and ev.unicode.isprintable():
                    self.set_hotkey(ev.unicode)
                self._end_hotkey_capture()
                return
            if self.modal:
                if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self._modal_pick(0)
                elif ev.key == pygame.K_ESCAPE:
                    self._modal_pick(len(self.modal["buttons"]) - 1)
            elif ev.key == pygame.K_ESCAPE:
                self.dd_open = False
        elif t == pygame.MOUSEBUTTONDOWN and ev.button == 3:
            if not self.modal and not self.dd_open and self.r_hotkey.collidepoint(ev.pos):
                self.clear_hotkey()
        elif t == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            if self.capturing_hotkey:
                self._end_hotkey_capture()      # a click anywhere ends the capture
                return
            self._mouse_down(ev.pos)
        elif t == pygame.MOUSEBUTTONUP and ev.button == 1:
            self._mouse_up(ev.pos)

    def _mouse_down(self, pos):
        if self.modal:
            for i, r in enumerate(self.modal["rects"]):
                if r.collidepoint(pos):
                    self.pressed = ("modal", i)
            return
        if self.dd_open:                                    # list swallows the click
            if self.r_list.collidepoint(pos):
                i = (pos[1] - self.r_list.y - self.s(1)) // self.item_h
                if 0 <= i < len(self.options) and i != self.aspect_idx:
                    self.aspect_idx = i
                    self.save()
            self.dd_open = False
            return
        if self.r_dd.collidepoint(pos):
            self.dd_open = True
        elif self.r_auto.collidepoint(pos):
            self.set_auto(not self.auto)
        elif self.r_hotkey.collidepoint(pos):
            self._begin_hotkey_capture()
        elif self.r_reticle.collidepoint(pos):
            self.pressed = "reticle"
        elif self.r_make.collidepoint(pos) and self.can_make():
            self.pressed = "make"
        elif self.r_stop.collidepoint(pos) and self.is_borderless:
            self.pressed = "stop"

    def _mouse_up(self, pos):
        p, self.pressed = self.pressed, None
        if p is None:
            return
        if isinstance(p, tuple):
            if self.modal and self.modal["rects"][p[1]].collidepoint(pos):
                self._modal_pick(p[1])
        elif p == "make" and self.r_make.collidepoint(pos) and self.can_make():
            self.make_borderless()
        elif p == "stop" and self.r_stop.collidepoint(pos) and self.is_borderless:
            self.stop_borderless()
        elif p == "reticle" and self.r_reticle.collidepoint(pos):
            self.open_reticle()

    # ---- drawing ---------------------------------------------------------------
    def _text(self, font, txt, color, x, y, center=False):
        img = font.render(txt, True, color)
        self.screen.blit(img, (x - img.get_width() // 2 if center else x, y))

    def _button(self, key, rect, label, enabled, mouse):
        if not enabled:
            fill, border, fg = C_BTN_OFF, C_BORDER_OFF, C_FAINT
        elif self.pressed == key and rect.collidepoint(mouse):
            fill, border, fg = C_BTN_DOWN, C_BORDER_HOT, C_TEXT
        elif rect.collidepoint(mouse):
            fill, border, fg = C_BTN_HOT, C_BORDER_HOT, C_TEXT
        else:
            fill, border, fg = C_BTN, C_BORDER, C_TEXT
        pygame.draw.rect(self.screen, fill, rect, border_radius=self.s(3))
        pygame.draw.rect(self.screen, border, rect, 1, border_radius=self.s(3))
        img = self.f_btn.render(label, True, fg)
        self.screen.blit(img, img.get_rect(center=rect.center))

    def draw(self):
        s, scr = self.s, self.screen
        mouse = pygame.mouse.get_pos() if pygame.mouse.get_focused() else (-1, -1)
        if self.modal:                                      # nothing underneath reacts
            mouse_ui = (-1, -1)
        else:
            mouse_ui = mouse

        if self.bg:
            scr.blit(self.bg, (0, 0))
        else:
            scr.fill((18, 18, 22))

        # status panel
        scr.blit(self.panel, self.r_status)
        pygame.draw.rect(scr, C_LINE, self.r_status, 1, border_radius=s(3))
        lines = []
        status = self.status
        if self.auto_deadline is not None:
            left = max(1, math.ceil((self.auto_deadline - self._now()) / 1000))
            status = status.split("\n")[0] + f"\nAuto Borderless: applying in {left}s..."
        if self.notice and time.time() < self.notice_until:
            status = status.split("\n")[0] + "\n" + self.notice
        for para in status.split("\n"):
            lines += wrap_text(self.f_body, para, self.r_status.w - s(20))
        lh = self.f_body.get_linesize()
        y = self.r_status.centery - lh * len(lines) // 2
        for ln in lines:
            self._text(self.f_body, ln, C_TEXT, self.r_status.centerx, y, center=True)
            y += lh

        # aspect dropdown (closed state)
        self._text(self.f_small, "TARGET ASPECT RATIO", C_DIM, self.r_dd.x, self.r_dd.y - s(18))
        hot = self.r_dd.collidepoint(mouse_ui) or self.dd_open
        pygame.draw.rect(scr, C_BTN_HOT if hot else C_BTN, self.r_dd, border_radius=s(3))
        pygame.draw.rect(scr, C_BORDER_HOT if hot else C_BORDER, self.r_dd, 1, border_radius=s(3))
        self._text(self.f_body, self.options[self.aspect_idx], C_TEXT, self.r_dd.x + s(10),
                   self.r_dd.centery - self.f_body.get_height() // 2)
        ax, ay, aw = self.r_dd.right - s(20), self.r_dd.centery, s(5)
        tip = [(ax - aw, ay - s(2)), (ax + aw, ay - s(2)), (ax, ay + s(3))]
        if self.dd_open:
            tip = [(ax - aw, ay + s(2)), (ax + aw, ay + s(2)), (ax, ay - s(3))]
        pygame.draw.polygon(scr, C_DIM, tip)

        # buttons
        self._button("make", self.r_make, "Make Borderless", self.can_make(), mouse_ui)
        self._button("stop", self.r_stop, "Stop Borderless", self.is_borderless, mouse_ui)
        self._button("reticle", self.r_reticle, "Reticle", True, mouse_ui)

        # Auto Borderless checkbox
        hot = self.r_auto.collidepoint(mouse_ui)
        box = pygame.Rect(self.r_auto.x, self.r_auto.centery - s(9), s(18), s(18))
        pygame.draw.rect(scr, C_BTN_HOT if hot else C_BTN, box, border_radius=s(3))
        pygame.draw.rect(scr, C_BORDER_HOT if hot else C_BORDER, box, 1, border_radius=s(3))
        if self.auto:
            pts = [(box.x + s(4), box.centery), (box.x + s(8), box.bottom - s(5)),
                   (box.right - s(4), box.y + s(5))]
            pygame.draw.lines(scr, C_TEXT, False, pts, max(2, s(2)))
        self._text(self.f_body, "Auto Borderless", C_TEXT if hot or self.auto else C_DIM,
                   box.right + s(10), self.r_auto.centery - self.f_body.get_height() // 2)

        # Hide/show shortcut (click to change)
        hk_label = "Press a key..." if self.capturing_hotkey else f"Hide UI: {self.hotkey or '(none)'}"
        hk_hot = self.r_hotkey.collidepoint(mouse_ui) or self.capturing_hotkey
        self._text(self.f_body, hk_label, C_TEXT if hk_hot else C_DIM,
                   self.r_hotkey.x, self.r_hotkey.centery - self.f_body.get_height() // 2)

        # dropdown list (drawn last so it overlays the buttons)
        if self.dd_open:
            pygame.draw.rect(scr, (30, 30, 35), self.r_list, border_radius=s(3))
            pygame.draw.rect(scr, C_BORDER_HOT, self.r_list, 1, border_radius=s(3))
            for i, label in enumerate(self.options):
                r = pygame.Rect(self.r_list.x + s(1), self.r_list.y + s(1) + i * self.item_h,
                                self.r_list.w - s(2), self.item_h)
                if r.collidepoint(mouse_ui):
                    pygame.draw.rect(scr, C_BTN_HOT, r)
                sel = i == self.aspect_idx
                self._text(self.f_body, label, C_TEXT if sel else C_DIM, r.x + s(10),
                           r.centery - self.f_body.get_height() // 2)
                if sel:
                    pygame.draw.circle(scr, C_TEXT, (r.right - s(14), r.centery), s(3))

        # modal
        if self.modal:
            scr.blit(self.dim, (0, 0))
            box = self.modal["box"]
            pygame.draw.rect(scr, (28, 28, 33), box, border_radius=s(4))
            pygame.draw.rect(scr, C_BORDER, box, 1, border_radius=s(4))
            y = box.y + s(20)
            for ln in self.modal["lines"]:
                self._text(self.f_body, ln, C_TEXT, box.centerx, y, center=True)
                y += self.f_body.get_linesize()
            for i, ((label, _), r) in enumerate(zip(self.modal["buttons"], self.modal["rects"])):
                down = self.pressed == ("modal", i) and r.collidepoint(mouse)
                fill = C_BTN_DOWN if down else (C_BTN_HOT if r.collidepoint(mouse) else C_BTN)
                pygame.draw.rect(scr, fill, r, border_radius=s(3))
                pygame.draw.rect(scr, C_BORDER_HOT if r.collidepoint(mouse) else C_BORDER, r, 1,
                                 border_radius=s(3))
                img = self.f_btn.render(label, True, C_TEXT)
                scr.blit(img, img.get_rect(center=r.center))

    # ---- main loop -------------------------------------------------------------
    def run(self):
        icon_at, icon_n = 0.0, 0
        while self.running:
            if icon_n < 12 and getattr(self, "_ico", None) and time.time() >= icon_at:
                apply_taskbar_icon(self._hwnd_ico, self._ico)    # again for a few seconds: it sometimes does not stick
                icon_n += 1
                icon_at = time.time() + 0.5
            ids = set() if self.capturing_hotkey else consume_hotkeys()     # a key being picked is no command
            if _HOTKEY_ID in ids and not self.disable_shortcut:
                self.on_main_hotkey()
            if _RET_HOTKEY_ID in ids:
                self.send_reticle("toggle")
            if not self.capturing_hotkey:
                self.sync_reticle_hotkey()
            self.tick()
            if self.ui_visible:
                self.draw()
                pygame.display.flip()
            # Always pump events and sleep a short time so the 3s check
            # still runs when the window is hidden or idle (no mouse events).
            for ev in pygame.event.get():
                self.handle(ev)
            pygame.time.wait(50)


def reticle_wanted():
    """True when the Reticle window should already wait in the background (it has a shortcut to listen for)."""
    return bool(reticle_hotkey_vk())


def apply_taskbar_icon(hwnd, ico):
    """Give the window the Lidico icon (big = taskbar / Alt+Tab, small = title bar). Windows sometimes keeps the default
    Python icon when this is done while the window is still being set up, so callers repeat it for a few seconds."""
    try:
        u = ctypes.windll.user32
        for which, metric in ((1, 11), (0, 49)):                 # ICON_BIG / SM_CXICON, ICON_SMALL / SM_CXSMICON
            size = u.GetSystemMetrics(metric)
            hicon = u.LoadImageW(None, ico, 1, size, size, 0x0010)
            if hicon:
                u.SendMessageW(hwnd, 0x0080, which, hicon)
        return True
    except Exception:
        return False


_MUTEX = None


def single_instance():
    """Only one copy may run: a named mutex lives as long as the first copy does (a crash or force close frees it).
    A second copy brings the first one's window forward (when it is showing) and ends."""
    global _MUTEX
    try:
        k = ctypes.windll.kernel32
        k.CreateMutexW.restype = ctypes.c_void_p
        _MUTEX = k.CreateMutexW(None, False, "Local\\" + APP_ID + ".SingleInstance")
        if ctypes.windll.kernel32.GetLastError() != 183:        # ERROR_ALREADY_EXISTS
            return True
    except Exception:
        return True
    try:
        u = ctypes.windll.user32
        u.FindWindowW.restype = ctypes.c_void_p
        hwnd = u.FindWindowW(None, "%s %s" % (APP_TITLE, VERSION))
        if hwnd and u.IsWindowVisible(ctypes.c_void_p(hwnd)):
            u.ShowWindow(ctypes.c_void_p(hwnd), 9)
            u.SetForegroundWindow(ctypes.c_void_p(hwnd))
    except Exception:
        pass
    return False


def main():
    if "--reticle-ui" in sys.argv:
        import reticle_maker
        sys.exit(reticle_maker.main(sys.argv[1:]))
    if sys.platform != "win32":
        fatal("This tool only works on Windows.")
    enable_dpi_awareness()          # before SDL creates any window
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:
        pass
    if not single_instance():
        return
    for f in (STATUS_FILE, STATUS_FILE + ".tmp", CANCEL_FILE):      # leftovers of a crash must not claim a state
        try:
            os.remove(f)
        except OSError:
            pass
    clear_stale_lock()
    if not find_game_pids():                # no game running: a saved window state can only be a leftover
        for f in (STATE_FILE, STATE_FILE + ".tmp"):
            try:
                os.remove(f)
            except OSError:
                pass
    write_lock()
    app = None
    try:
        app = App()
        app.run()
    except Exception:
        import traceback
        fatal("Unexpected error:\n\n" + traceback.format_exc())
    finally:
        if app is not None:
            app._backdrop_off()
            app.shutdown_reticle()
        _uninstall_hooks()
        for f in (STATUS_FILE, STATUS_FILE + ".tmp", CANCEL_FILE):
            try:
                os.remove(f)
            except OSError:
                pass
        clear_lock()
        pygame.quit()


if __name__ == "__main__":
    main()