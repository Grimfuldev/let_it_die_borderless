#!/usr/bin/env python3
"""Reticle Maker: builds a reticle and bakes it into the game HUD (UI_HUD_SF.upk), moved by BrgGameBase.upk.

Started from the Reticle button of borderless_letitdie.py (it runs as its own process so the
two windows stay independent). Both share reticle_config.json.

Layout: rt_core (constants, Config, Steam / UPK, reticle images) <- rt_snapshot (Make preview banner + game picture)
        <- rt_widgets (UI widgets + catalog popups) <- rt_ui (window).  This file is the entry point.
"""
import sys

from rt_core import *  # noqa: F401,F403  (re-exported for borderless_letitdie.py)
from rt_snapshot import *  # noqa: F401,F403
from rt_widgets import *  # noqa: F401,F403
from rt_ui import *  # noqa: F401,F403
from rt_ui import main

if __name__ == "__main__":
    sys.exit(main())