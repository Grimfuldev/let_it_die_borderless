#!/usr/bin/env python3
"""
Let It Die Borderless Tool

Forces Let It Die (BrgGame-Steam.exe) into borderless windowed mode when the
game is running in regular Windowed mode (NOT exclusive fullscreen).

Requirements (running from source):
    pip install pywin32 pygame-ce pillow

Build a standalone exe:
    run build_exe.bat   (UI_Assets\\ must sit next to this script)

Usage:
  1. Set the game to Windowed (BrgGraphicsConfig.ini -> mbFullScreen=False).
  2. Start the game and wait until it is past the launch screen.
  3. Run this tool (as Administrator if the game runs elevated).
  4. Pick an aspect option and click "Make Borderless".
  5. "Stop Borderless" restores the original window.

Aspect options:
  - Fill Screen        : cover the whole monitor (what you normally want)
  - 16:9, 16:10, ...   : largest centered area of that ratio on the monitor
  - Native size        : keep the game's current pixel size, centered
"""
import configparser
import ctypes
import math
import os
import subprocess
import sys
from ctypes import wintypes

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True

APP_TITLE = "Let It Die Borderless"
VERSION = "v0.1"


def fatal(msg):
    """Show a message even when running as a windowed exe (no console)."""
    try:
        ctypes.windll.user32.MessageBoxW(None, msg, APP_TITLE, 0x10)
    except Exception:
        print(msg)
    sys.exit(1)


try:
    import pygame
    import pywintypes
    import win32api
    import win32con
    import win32gui
    import win32process
    from PIL import Image
except ImportError as e:
    fatal(f"Missing dependency: {e.name}\n\nInstall with:\n"
          "pip install pywin32 pygame-ce pillow")

# ------------------------------------------------------------------ config
EXE_PREFIX = "brggame"          # matches BrgGame-Steam.exe (case-insensitive)
MIN_WINDOW_AREA = 100 * 100     # ignore tiny helper windows
POLL_MS = 1000                  # how often to recheck once the game is found
WAIT_POLL_MS = 3000             # how often to look for the game while waiting
GWL_STYLE, GWL_EXSTYLE = -16, -20
ERROR_ACCESS_DENIED = 5
APP_ID = "Grimfuldev.LID.Borderless"

NATIVE = "native"
ASPECTS = {                     # label -> ratio | None (fill) | NATIVE
    "Fill Screen (ignore aspect)": None,
    "16:9": 16 / 9,
    "16:10": 16 / 10,
    "4:3": 4 / 3,
    "21:9": 21 / 9,
    "32:9": 32 / 9,
    "Native size (centered)": NATIVE,
}

# Extended-style bits that draw an edge/3D frame
EX_EDGE_BITS = (
    win32con.WS_EX_DLGMODALFRAME | win32con.WS_EX_CLIENTEDGE
    | win32con.WS_EX_STATICEDGE | win32con.WS_EX_WINDOWEDGE
)

# ------------------------------------------------------------------- paths
FROZEN = getattr(sys, "frozen", False)
SCRIPT_DIR = os.path.dirname(sys.executable if FROZEN else os.path.abspath(__file__))
RES_DIR = getattr(sys, "_MEIPASS", SCRIPT_DIR)          # packed assets live here
UI_ASSETS = os.path.join(RES_DIR, "UI_Assets")

BG_FILE = "UI background.webp"
GLASSES_FILE = "uncle glasses ready.webp"
CURSOR_FILE = "let it die cursor.webp"
ICO_FILE = "Lidico.ico"


def find_ui(name):
    for root in (UI_ASSETS, SCRIPT_DIR):
        p = os.path.join(root, name)
        if os.path.isfile(p):
            return p
    return ""


# ---------------------------------------------------------------- settings
SETTINGS_FILE = os.path.join(SCRIPT_DIR, "borderless_settings.ini")   # next to the exe
LOCK_FILE = os.path.join(SCRIPT_DIR, "borderless.lock")
DEFAULT_ASPECT = next(iter(ASPECTS))
DEFAULT_HOTKEY = "="
DEFAULT_AUTO_DELAY_SECONDS = 10  # configurable in borderless_settings.ini


def load_settings():
    """-> aspect, auto_borderless, hotkey, start_minimized, disable_shortcut, auto_delay_seconds."""
    aspect, auto, hotkey, start_min, disable_sc = DEFAULT_ASPECT, False, DEFAULT_HOTKEY, False, False
    auto_delay_seconds = DEFAULT_AUTO_DELAY_SECONDS
    cp = configparser.ConfigParser()
    try:
        cp.read(SETTINGS_FILE, encoding="utf-8")
        if cp.has_section("borderless"):
            a = cp.get("borderless", "aspect", fallback=DEFAULT_ASPECT).strip()
            aspect = a if a in ASPECTS else DEFAULT_ASPECT
            auto = cp.getboolean("borderless", "auto_borderless", fallback=False)
            h = cp.get("borderless", "hotkey", fallback=DEFAULT_HOTKEY).strip()
            hotkey = h if h else DEFAULT_HOTKEY
            start_min = cp.getboolean("borderless", "start_minimized", fallback=False)
            disable_sc = cp.getboolean("borderless", "disable_shortcut", fallback=False)
            auto_delay_seconds = cp.getint(
                "borderless", "auto_delay_seconds",
                fallback=DEFAULT_AUTO_DELAY_SECONDS)
            auto_delay_seconds = max(0, min(auto_delay_seconds, 3600))
    except (configparser.Error, ValueError, OSError):
        auto_delay_seconds = DEFAULT_AUTO_DELAY_SECONDS
    return aspect, auto, hotkey, start_min, disable_sc, auto_delay_seconds


def save_settings(aspect, auto, hotkey):
    """Write UI-changeable settings. start_minimized is left as-is (ini-only)."""
    cp = configparser.ConfigParser()
    try:
        cp.read(SETTINGS_FILE, encoding="utf-8")
    except (configparser.Error, OSError):
        pass
    if not cp.has_section("borderless"):
        cp.add_section("borderless")
    cp.set("borderless", "aspect", aspect)
    cp.set("borderless", "auto_borderless", "true" if auto else "false")
    cp.set("borderless", "hotkey", hotkey)
    # preserve ini-only options
    if not cp.has_option("borderless", "start_minimized"):
        cp.set("borderless", "start_minimized", "false")
    if not cp.has_option("borderless", "disable_shortcut"):
        cp.set("borderless", "disable_shortcut", "false")
    if not cp.has_option("borderless", "auto_delay_seconds"):
        cp.set("borderless", "auto_delay_seconds", str(DEFAULT_AUTO_DELAY_SECONDS))
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            cp.write(f)
    except OSError:
        pass


# ------------------------------------------------------------ hotkey
# RegisterHotKey, not a low-level keyboard hook. A hook sits on every
# key and can make the game lose the key-up (W stays pressed).
_HOTKEY_ID = 0xB10
_HOTKEY_VK = None
_HOTKEY_PRESSED = False


def _vk_from_char(ch):
    """Best-effort virtual-key code for a single character (default '=' -> 0xBB)."""
    if not ch:
        return 0xBB
    ch = ch[0]
    if ch == "=":
        return 0xBB          # VK_OEM_PLUS on US layouts
    if ch == "-":
        return 0xBD
    try:
        return ctypes.windll.user32.VkKeyScanW(ord(ch)) & 0xFF
    except Exception:
        return 0xBB


def _install_hook(vk):
    """Register one hotkey. Does not intercept other keys."""
    global _HOTKEY_VK
    _uninstall_hook()
    _HOTKEY_VK = vk
    try:
        ok = ctypes.windll.user32.RegisterHotKey(None, _HOTKEY_ID, 0, vk)
        if not ok:
            # try with MOD_NOREPEAT so holding the key does not spam
            ctypes.windll.user32.RegisterHotKey(None, _HOTKEY_ID, 0x4000, vk)
    except Exception:
        pass


def _uninstall_hook():
    try:
        ctypes.windll.user32.UnregisterHotKey(None, _HOTKEY_ID)
    except Exception:
        pass


def consume_hotkey():
    """Pull WM_HOTKEY only. Leaves every other message for pygame."""
    global _HOTKEY_PRESSED
    try:
        user32 = ctypes.windll.user32
        msg = wintypes.MSG()
        # 0x0312 = WM_HOTKEY, 1 = PM_REMOVE
        while user32.PeekMessageW(ctypes.byref(msg), None, 0x0312, 0x0312, 1):
            _HOTKEY_PRESSED = True
    except Exception:
        pass
    if _HOTKEY_PRESSED:
        _HOTKEY_PRESSED = False
        return True
    return False


# ---------------------------------------------------------------- lock file
def write_lock():
    try:
        with open(LOCK_FILE, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
    except OSError:
        pass


def clear_lock():
    try:
        if os.path.isfile(LOCK_FILE):
            os.remove(LOCK_FILE)
    except OSError:
        pass


def pid_alive(pid):
    if pid <= 0:
        return False
    try:
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
        if h:
            ctypes.windll.kernel32.CloseHandle(h)
            return True
    except Exception:
        pass
    return False


def clear_stale_lock():
    """Remove a lock left by a previous crash / force-shutdown."""
    if not os.path.isfile(LOCK_FILE):
        return
    try:
        raw = open(LOCK_FILE, "r", encoding="utf-8").read().strip()
        old = int(raw or "0")
        if not pid_alive(old):
            os.remove(LOCK_FILE)
    except Exception:
        try:
            os.remove(LOCK_FILE)
        except Exception:
            pass
_K32 = None
_PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


def _kernel32():
    global _K32
    if _K32 is None:
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.OpenProcess.restype = wintypes.HANDLE
        k.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        k.QueryFullProcessImageNameW.argtypes = (
            wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD))
        k.CloseHandle.argtypes = (wintypes.HANDLE,)
        _K32 = k
    return _K32


def enable_dpi_awareness():
    """Must run before any window is created, or screen sizes come back scaled."""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)      # per-monitor
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def ui_scale():
    """System DPI scale (1.0 = 96 dpi) so the window isn't tiny on HiDPI screens."""
    try:
        return min(3.0, max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96))
    except Exception:
        return 1.0


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin():
    """True if the elevated copy was started (False if the UAC prompt was declined)."""
    args = sys.argv[1:] if FROZEN else sys.argv
    params = " ".join(f'"{a}"' for a in args) or None
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)
    return int(ret) > 32


def to_signed32(v):
    v &= 0xFFFFFFFF
    return v - 0x100000000 if v & 0x80000000 else v


def exe_name(pid):
    """Lowercase exe file name of a process, or '' if it can't be read."""
    k = _kernel32()
    h = k.OpenProcess(_PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = wintypes.DWORD(len(buf))
        if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return buf.value.rsplit("\\", 1)[-1].lower()
        return ""
    finally:
        k.CloseHandle(h)


def find_game_pids():
    """PIDs of BrgGame-Steam.exe via tasklist. Avoids matching editors."""
    pids = set()
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq BrgGame-Steam.exe", "/FO", "CSV", "/NH"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stderr=subprocess.DEVNULL,
            text=True,
            errors="ignore",
        )
    except Exception:
        return pids
    for line in out.splitlines():
        line = line.strip()
        if not line or "brggame" not in line.lower():
            continue
        # "BrgGame-Steam.exe","1234","Console","1","12,345 K"
        parts = [p.strip().strip('"') for p in line.split(",")]
        if len(parts) >= 2 and parts[1].isdigit():
            pids.add(int(parts[1]))
    return pids


def find_game_window():
    """Largest visible top-level window owned by BrgGame-Steam.exe, or None."""
    game_pids = find_game_pids()
    if not game_pids:
        return None
    best = [0, None]

    def visit(hwnd, _):
        if not win32gui.IsWindowVisible(hwnd):
            return True
        try:
            pid = win32process.GetWindowThreadProcessId(hwnd)[1]
            if pid not in game_pids:
                return True
            l, t, r, b = win32gui.GetWindowRect(hwnd)
        except pywintypes.error:
            return True
        area = (r - l) * (b - t)
        if area > MIN_WINDOW_AREA and area > best[0]:
            best[0], best[1] = area, hwnd
        return True

    win32gui.EnumWindows(visit, None)
    return best[1]


def monitor_rect(hwnd):
    """(left, top, right, bottom) of the monitor the window is on."""
    try:
        mon = win32api.MonitorFromWindow(hwnd, win32con.MONITOR_DEFAULTTONEAREST)
        return win32api.GetMonitorInfo(mon)["Monitor"]
    except pywintypes.error:
        return 0, 0, win32api.GetSystemMetrics(0), win32api.GetSystemMetrics(1)


def client_size(hwnd):
    l, t, r, b = win32gui.GetClientRect(hwnd)
    return r - l, b - t


# ----------------------------------------------------------- image helpers
def load_image(path):
    """Any image (webp/png/...) -> pygame surface with per-pixel alpha."""
    im = Image.open(path).convert("RGBA")
    return pygame.image.frombuffer(im.tobytes(), im.size, "RGBA").convert_alpha()


def load_background(path, w, h):
    """Scale-to-cover + center-crop, done once at start-up."""
    im = Image.open(path).convert("RGB")
    k = max(w / im.width, h / im.height)
    nw, nh = round(im.width * k), round(im.height * k)
    im = im.resize((nw, nh), Image.Resampling.LANCZOS)
    left, top = (nw - w) // 2, (nh - h) // 2
    im = im.crop((left, top, left + w, top + h))
    return pygame.image.frombuffer(im.tobytes(), im.size, "RGB").convert()


def scaled(surf, size):
    if size == surf.get_width():
        return surf
    fn = pygame.transform.scale if size % surf.get_width() == 0 else pygame.transform.smoothscale
    return fn(surf, (size, size))


def wrap_text(font, text, width):
    """Word-wrap `text` (honours \\n) to `width` pixels; breaks over-long words."""
    lines = []
    for para in text.split("\n"):
        cur = ""
        for word in para.split(" "):
            trial = f"{cur} {word}".strip()
            if font.size(trial)[0] <= width:
                cur = trial
                continue
            if cur:
                lines.append(cur)
            while font.size(word)[0] > width and len(word) > 1:   # hard-break
                n = len(word)
                while n > 1 and font.size(word[:n])[0] > width:
                    n -= 1
                lines.append(word[:n])
                word = word[n:]
            cur = word
        lines.append(cur)
    return lines


# ------------------------------------------------------------------ theme
C_TEXT = (224, 224, 228)
C_DIM = (146, 146, 154)
C_FAINT = (92, 92, 100)
C_LINE = (62, 62, 70)
C_BTN = (40, 40, 46)
C_BTN_HOT = (56, 56, 64)
C_BTN_DOWN = (28, 28, 32)
C_BTN_OFF = (24, 24, 28)
C_BORDER = (98, 98, 106)
C_BORDER_HOT = (176, 176, 184)
C_BORDER_OFF = (50, 50, 56)

WIN_W, WIN_H = 440, 322


# --------------------------------------------------------------------- app
class App:
    def __init__(self):
        pygame.display.init()
        pygame.font.init()
        self.S = ui_scale()
        s = self.s
        # settings before the window, so we can create it already hidden
        (aspect, self.auto, self.hotkey, self.start_minimized,
         self.disable_shortcut, self.auto_delay_seconds) = load_settings()
        self.auto_delay_ms = self.auto_delay_seconds * 1000
        flags = 0
        if self.start_minimized and hasattr(pygame, "HIDDEN"):
            flags |= pygame.HIDDEN
        self.screen = pygame.display.set_mode((s(WIN_W), s(WIN_H)), flags)
        pygame.display.set_caption(f"{APP_TITLE} {VERSION}")
        # hide immediately, before chrome or the first frame can show it
        self._win_hwnd = pygame.display.get_wm_info().get("window")
        if self.start_minimized and self._win_hwnd:
            try:
                win32gui.ShowWindow(self._win_hwnd, win32con.SW_HIDE)
            except Exception:
                pass

        # state
        self.running = True
        self.hwnd = None
        self.is_borderless = False
        self._saved = None              # (style, exstyle, rect) for restore
        self.status = "Looking for the game..."
        self.options = list(ASPECTS)
        self.aspect_idx = self.options.index(aspect)
        self.auto_deadline = None       # tick (ms) at which auto-borderless fires
        self._prev_found = None         # None = first poll; then True/False
        self.game_seen = False          # True once the game has been found this session
        self.ui_visible = not self.start_minimized
        self.capturing_hotkey = False
        if not os.path.isfile(SETTINGS_FILE):
            self.save()                 # create the ini on first launch
        self.dd_open = False
        self.pressed = None             # "make" | "stop" | ("modal", i)
        self.modal = None               # {"lines": [...], "buttons": [(label, cb)], ...}
        self._next_poll = 0

        # fonts
        names = "segoeui,arial"
        self.f_body = pygame.font.SysFont(names, s(13))
        self.f_btn = pygame.font.SysFont(names, s(13), bold=True)
        self.f_small = pygame.font.SysFont(names, s(11))

        # layout
        self.r_status = pygame.Rect(s(16), s(16), s(408), s(58))
        self.r_dd = pygame.Rect(s(16), s(110), s(408), s(30))
        self.r_make = pygame.Rect(s(16), s(158), s(196), s(38))
        self.r_stop = pygame.Rect(s(228), s(158), s(196), s(38))
        self.r_auto = pygame.Rect(s(16), s(212), s(160), s(24))
        self.r_hotkey = pygame.Rect(s(190), s(212), s(234), s(24))
        self.item_h = s(24)
        self.r_list = pygame.Rect(self.r_dd.x, self.r_dd.bottom + s(2),
                                  self.r_dd.w, self.item_h * len(self.options) + s(2))

        # fonts
        names = "segoeui,arial"
        self.f_body = pygame.font.SysFont(names, s(13))
        self.f_btn = pygame.font.SysFont(names, s(13), bold=True)
        self.f_small = pygame.font.SysFont(names, s(11))

        # layout
        self.r_status = pygame.Rect(s(16), s(16), s(408), s(58))
        self.r_dd = pygame.Rect(s(16), s(110), s(408), s(30))
        self.r_make = pygame.Rect(s(16), s(158), s(196), s(38))
        self.r_stop = pygame.Rect(s(228), s(158), s(196), s(38))
        self.r_auto = pygame.Rect(s(16), s(212), s(160), s(24))
        self.item_h = s(24)
        self.r_list = pygame.Rect(self.r_dd.x, self.r_dd.bottom + s(2),
                                  self.r_dd.w, self.item_h * len(self.options) + s(2))

        # assets (every one is optional: the tool still works without them)
        self.bg = None
        self.glasses = None
        p = find_ui(BG_FILE)
        if p:
            try:
                self.bg = load_background(p, *self.screen.get_size())
            except Exception:
                pass
        p = find_ui(GLASSES_FILE)
        if p:
            try:
                self.glasses = load_image(p)
            except Exception:
                pass
        self.panel = pygame.Surface(self.r_status.size, pygame.SRCALPHA)
        self.panel.fill((0, 0, 0, 120))
        self.dim = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        self.dim.fill((0, 0, 0, 170))

        self._chrome()
        self._win_hwnd = pygame.display.get_wm_info().get("window")
        if not self.disable_shortcut:
            _install_hook(_vk_from_char(self.hotkey))
        if self.start_minimized:
            self._hide_ui()

    def s(self, v):
        return int(round(v * self.S))

    # ---- window chrome: dark title bar, glasses title icon, Lidico taskbar icon, cursor
    def _chrome(self):
        if self.glasses:
            try:
                pygame.display.set_icon(self.glasses)       # title bar (small) icon
            except Exception:
                pass
        try:
            hwnd = pygame.display.get_wm_info().get("window")
            if hwnd:
                user32 = ctypes.windll.user32
                ico = find_ui(ICO_FILE)
                if ico:                                     # taskbar (big) icon
                    hicon = user32.LoadImageW(None, ico, 1, 0, 0, 0x0010 | 0x0040)
                    if hicon:
                        user32.SendMessageW(hwnd, 0x0080, 1, hicon)
                black, dark = ctypes.c_int(0), ctypes.c_int(1)
                dwm = ctypes.windll.dwmapi
                dwm.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(dark), 4)    # dark mode
                dwm.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(black), 4)   # caption color
                dwm.DwmSetWindowAttribute(hwnd, 34, ctypes.byref(black), 4)   # border color
        except Exception:
            pass
        p = find_ui(CURSOR_FILE)
        if p:
            try:
                pygame.mouse.set_cursor((0, 0), scaled(load_image(p), self.s(32)))
            except Exception:
                pass

    # ---- logic (unchanged behaviour) ---------------------------------------
    def _now(self):
        return pygame.time.get_ticks()

    def save(self):
        save_settings(self.options[self.aspect_idx], self.auto, self.hotkey)

    def _hide_ui(self):
        if not self._win_hwnd:
            return
        try:
            win32gui.ShowWindow(self._win_hwnd, win32con.SW_HIDE)
        except Exception:
            pass
        self.ui_visible = False

    def _show_ui(self):
        if not self._win_hwnd:
            return
        try:
            win32gui.ShowWindow(self._win_hwnd, win32con.SW_SHOW)
            win32gui.SetForegroundWindow(self._win_hwnd)
        except Exception:
            pass
        self.ui_visible = True

    def toggle_ui(self):
        if self.ui_visible:
            self._hide_ui()
        else:
            self._show_ui()

    def set_hotkey(self, ch):
        if not ch or len(ch) != 1:
            return
        self.hotkey = ch
        self.save()
        if not self.disable_shortcut:
            _install_hook(_vk_from_char(ch))

    def can_make(self):
        # greyed out while an automatic apply is already pending
        return bool(self.hwnd) and not self.is_borderless and self.auto_deadline is None

    def _window_alive(self):
        return bool(self.hwnd) and win32gui.IsWindow(self.hwnd)

    def set_auto(self, on):
        if on == self.auto:
            return
        self.auto = on
        self.auto_deadline = None
        # Ticked while the game is already running -> short delay
        if on and self.hwnd and not self.is_borderless:
            self.auto_deadline = self._now() + self.auto_delay_ms
        self.save()

    def tick(self):
        """Called every loop: poll on a timer and fire a due auto-borderless."""
        now = self._now()
        if now >= self._next_poll:
            self.poll()
            # While waiting for the game, check every 3 seconds.
            # Once found, check every second so a close is noticed quickly.
            interval = POLL_MS if self.hwnd else WAIT_POLL_MS
            self._next_poll = now + interval
        if self.auto_deadline is not None and now >= self.auto_deadline:
            self.auto_deadline = None
            if self.auto and not self.is_borderless and not self.modal:
                self.hwnd = find_game_window() or self.hwnd
                if self._window_alive():
                    self.make_borderless()

    def poll(self):
        """Cheap while the game is up: one IsWindow call."""
        try:
            if not self._window_alive():
                was_active = self.is_borderless
                self.hwnd = None
                self.is_borderless = False
                self._saved = None
                self.hwnd = find_game_window()
                if self.hwnd:
                    self.game_seen = True
                    title = win32gui.GetWindowText(self.hwnd) or "Let It Die"
                    w, h = client_size(self.hwnd)
                    self.status = f"Found: {title}\nClient size: {w}x{h}"
                elif self.game_seen:
                    # Game was seen this session and is now gone -> exit completely
                    self.running = False
                    return
                elif was_active:
                    self.status = "Game closed. Start it again and click Make Borderless."
                else:
                    self.status = "Waiting for the game... (checking every 3s)"

            # Auto Borderless scheduling
            found = bool(self.hwnd)
            if not found:
                self.auto_deadline = None
            elif (self.auto and not self.is_borderless and self.auto_deadline is None
                  and self._prev_found is not True):
                # first poll => game was already running; False->True => it just launched
                self.auto_deadline = self._now() + self.auto_delay_ms
            self._prev_found = found
        except Exception as e:      # show problems instead of hiding them
            self.status = f"Error while looking for the game: {e}"

    def target_rect(self, native_size):
        l, t, r, b = monitor_rect(self.hwnd)
        mw, mh = r - l, b - t
        ratio = ASPECTS[self.options[self.aspect_idx]]

        if ratio is None:                                   # fill monitor
            return l, t, mw, mh
        if ratio == NATIVE:                                 # game's own size
            w, h = min(native_size[0], mw), min(native_size[1], mh)
        elif mw / mh > ratio:                               # height-limited
            h = mh
            w = int(h * ratio)
        else:                                               # width-limited
            w = mw
            h = int(w / ratio)
        return l + (mw - w) // 2, t + (mh - h) // 2, w, h

    def make_borderless(self):
        if not self._window_alive():
            self.hwnd = find_game_window()
            if not self.hwnd:
                self.show_modal("Could not find the Let It Die window.", [("OK", None)])
                return
        hwnd = self.hwnd
        try:
            # A minimized/maximized window ignores SetWindowPos
            if win32gui.IsIconic(hwnd) or win32gui.GetWindowPlacement(hwnd)[1] == win32con.SW_SHOWMAXIMIZED:
                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)

            style = win32gui.GetWindowLong(hwnd, GWL_STYLE)
            exstyle = win32gui.GetWindowLong(hwnd, GWL_EXSTYLE)
            rect = win32gui.GetWindowRect(hwnd)
            x, y, w, h = self.target_rect(client_size(hwnd))

            # One-shot, same recipe as the known-working Let It Die mod.
            # WS_BORDER is left out on purpose: it draws a thin 1px line.
            win32gui.SetWindowLong(hwnd, GWL_STYLE, to_signed32(win32con.WS_MAXIMIZE))
            win32gui.SetWindowLong(hwnd, GWL_EXSTYLE, to_signed32(exstyle & ~EX_EDGE_BITS))
            win32gui.SetWindowPos(hwnd, 0, x, y, w, h,
                                  win32con.SWP_SHOWWINDOW | win32con.SWP_FRAMECHANGED)

            self._saved = (style, exstyle, rect)
            self.is_borderless = True
            self.status = f"Borderless active: {w}x{h} at ({x},{y})"
        except pywintypes.error as e:
            if e.winerror == ERROR_ACCESS_DENIED and not is_admin():
                self.show_modal(
                    "The game window can't be modified from a normal account.\n\n"
                    "Restart this tool as Administrator?",
                    [("Restart as Admin", self._restart_admin), ("Cancel", None)])
                return
            self.show_modal(f"Failed to apply borderless:\n{e}", [("OK", None)])
        except Exception as e:
            self.show_modal(f"Failed to apply borderless:\n{e}", [("OK", None)])

    def stop_borderless(self):
        self.is_borderless = False
        self.set_auto(False)            # Stop while Auto Borderless is on -> untick it
        try:
            if self._window_alive() and self._saved:
                style, exstyle, (l, t, r, b) = self._saved
                win32gui.SetWindowLong(self.hwnd, GWL_STYLE, style)
                win32gui.SetWindowLong(self.hwnd, GWL_EXSTYLE, exstyle)
                win32gui.SetWindowPos(self.hwnd, 0, l, t, r - l, b - t,
                                      win32con.SWP_SHOWWINDOW | win32con.SWP_FRAMECHANGED)
                self.status = "Restored original window."
        except Exception as e:
            self.show_modal(f"Failed to restore:\n{e}", [("OK", None)])
        self._saved = None

    def _restart_admin(self):
        if relaunch_as_admin():
            self.running = False
        else:
            self.status = "Administrator restart was cancelled."

    # ---- modal dialog (dark, in-app) ----------------------------------------
    def show_modal(self, text, buttons):
        s = self.s
        box_w = s(372)
        lines = wrap_text(self.f_body, text, box_w - s(40))
        lh = self.f_body.get_linesize()
        btn_h, btn_w, gap = s(32), s(148), s(12)
        box_h = s(20) + lh * len(lines) + s(20) + btn_h + s(20)
        box = pygame.Rect(0, 0, box_w, box_h)
        box.center = self.screen.get_rect().center
        total = len(buttons) * btn_w + (len(buttons) - 1) * gap
        x0 = box.centerx - total // 2
        rects = [pygame.Rect(x0 + i * (btn_w + gap), box.bottom - s(20) - btn_h, btn_w, btn_h)
                 for i in range(len(buttons))]
        self.modal = {"lines": lines, "buttons": buttons, "box": box, "rects": rects}
        self.dd_open = False
        self.pressed = None

    def _modal_pick(self, i):
        cb = self.modal["buttons"][i][1]
        self.modal = None
        if cb:
            cb()

    # ---- input ---------------------------------------------------------------
    def handle(self, ev):
        t = ev.type
        if t == pygame.QUIT:
            self.running = False
        elif t == pygame.KEYDOWN:
            if self.capturing_hotkey:
                # Accept a single printable character as the new hotkey
                if ev.unicode and len(ev.unicode) == 1 and ev.unicode.isprintable():
                    self.set_hotkey(ev.unicode)
                self.capturing_hotkey = False
                return
            if self.modal:
                if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self._modal_pick(0)
                elif ev.key == pygame.K_ESCAPE:
                    self._modal_pick(len(self.modal["buttons"]) - 1)
            elif ev.key == pygame.K_ESCAPE:
                self.dd_open = False
        elif t == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            self._mouse_down(ev.pos)
        elif t == pygame.MOUSEBUTTONUP and ev.button == 1:
            self._mouse_up(ev.pos)

    def _mouse_down(self, pos):
        if self.modal:
            for i, r in enumerate(self.modal["rects"]):
                if r.collidepoint(pos):
                    self.pressed = ("modal", i)
            return
        if self.dd_open:                                    # list swallows the click
            if self.r_list.collidepoint(pos):
                i = (pos[1] - self.r_list.y - self.s(1)) // self.item_h
                if 0 <= i < len(self.options) and i != self.aspect_idx:
                    self.aspect_idx = i
                    self.save()
            self.dd_open = False
            return
        if self.r_dd.collidepoint(pos):
            self.dd_open = True
        elif self.r_auto.collidepoint(pos):
            self.set_auto(not self.auto)
        elif self.r_hotkey.collidepoint(pos):
            self.capturing_hotkey = True
        elif self.r_make.collidepoint(pos) and self.can_make():
            self.pressed = "make"
        elif self.r_stop.collidepoint(pos) and self.is_borderless:
            self.pressed = "stop"

    def _mouse_up(self, pos):
        p, self.pressed = self.pressed, None
        if p is None:
            return
        if isinstance(p, tuple):
            if self.modal and self.modal["rects"][p[1]].collidepoint(pos):
                self._modal_pick(p[1])
        elif p == "make" and self.r_make.collidepoint(pos) and self.can_make():
            self.make_borderless()
        elif p == "stop" and self.r_stop.collidepoint(pos) and self.is_borderless:
            self.stop_borderless()

    # ---- drawing ---------------------------------------------------------------
    def _text(self, font, txt, color, x, y, center=False):
        img = font.render(txt, True, color)
        self.screen.blit(img, (x - img.get_width() // 2 if center else x, y))

    def _button(self, key, rect, label, enabled, mouse):
        if not enabled:
            fill, border, fg = C_BTN_OFF, C_BORDER_OFF, C_FAINT
        elif self.pressed == key and rect.collidepoint(mouse):
            fill, border, fg = C_BTN_DOWN, C_BORDER_HOT, C_TEXT
        elif rect.collidepoint(mouse):
            fill, border, fg = C_BTN_HOT, C_BORDER_HOT, C_TEXT
        else:
            fill, border, fg = C_BTN, C_BORDER, C_TEXT
        pygame.draw.rect(self.screen, fill, rect, border_radius=self.s(3))
        pygame.draw.rect(self.screen, border, rect, 1, border_radius=self.s(3))
        img = self.f_btn.render(label, True, fg)
        self.screen.blit(img, img.get_rect(center=rect.center))

    def draw(self):
        s, scr = self.s, self.screen
        mouse = pygame.mouse.get_pos() if pygame.mouse.get_focused() else (-1, -1)
        if self.modal:                                      # nothing underneath reacts
            mouse_ui = (-1, -1)
        else:
            mouse_ui = mouse

        if self.bg:
            scr.blit(self.bg, (0, 0))
        else:
            scr.fill((18, 18, 22))

        # status panel
        scr.blit(self.panel, self.r_status)
        pygame.draw.rect(scr, C_LINE, self.r_status, 1, border_radius=s(3))
        lines = []
        status = self.status
        if self.auto_deadline is not None:
            left = max(1, math.ceil((self.auto_deadline - self._now()) / 1000))
            status = status.split("\n")[0] + f"\nAuto Borderless: applying in {left}s..."
        for para in status.split("\n"):
            lines += wrap_text(self.f_body, para, self.r_status.w - s(20))
        lh = self.f_body.get_linesize()
        y = self.r_status.centery - lh * len(lines) // 2
        for ln in lines:
            self._text(self.f_body, ln, C_TEXT, self.r_status.centerx, y, center=True)
            y += lh

        # aspect dropdown (closed state)
        self._text(self.f_small, "TARGET ASPECT RATIO", C_DIM, self.r_dd.x, self.r_dd.y - s(18))
        hot = self.r_dd.collidepoint(mouse_ui) or self.dd_open
        pygame.draw.rect(scr, C_BTN_HOT if hot else C_BTN, self.r_dd, border_radius=s(3))
        pygame.draw.rect(scr, C_BORDER_HOT if hot else C_BORDER, self.r_dd, 1, border_radius=s(3))
        self._text(self.f_body, self.options[self.aspect_idx], C_TEXT, self.r_dd.x + s(10),
                   self.r_dd.centery - self.f_body.get_height() // 2)
        ax, ay, aw = self.r_dd.right - s(20), self.r_dd.centery, s(5)
        tip = [(ax - aw, ay - s(2)), (ax + aw, ay - s(2)), (ax, ay + s(3))]
        if self.dd_open:
            tip = [(ax - aw, ay + s(2)), (ax + aw, ay + s(2)), (ax, ay - s(3))]
        pygame.draw.polygon(scr, C_DIM, tip)

        # buttons
        self._button("make", self.r_make, "Make Borderless", self.can_make(), mouse_ui)
        self._button("stop", self.r_stop, "Stop Borderless", self.is_borderless, mouse_ui)

        # Auto Borderless checkbox
        hot = self.r_auto.collidepoint(mouse_ui)
        box = pygame.Rect(self.r_auto.x, self.r_auto.centery - s(9), s(18), s(18))
        pygame.draw.rect(scr, C_BTN_HOT if hot else C_BTN, box, border_radius=s(3))
        pygame.draw.rect(scr, C_BORDER_HOT if hot else C_BORDER, box, 1, border_radius=s(3))
        if self.auto:
            pts = [(box.x + s(4), box.centery), (box.x + s(8), box.bottom - s(5)),
                   (box.right - s(4), box.y + s(5))]
            pygame.draw.lines(scr, C_TEXT, False, pts, max(2, s(2)))
        self._text(self.f_body, "Auto Borderless", C_TEXT if hot or self.auto else C_DIM,
                   box.right + s(10), self.r_auto.centery - self.f_body.get_height() // 2)

        # Hide/show shortcut (click to change)
        hk_label = "Press a key..." if self.capturing_hotkey else f"Hide UI: {self.hotkey}"
        hk_hot = self.r_hotkey.collidepoint(mouse_ui) or self.capturing_hotkey
        self._text(self.f_body, hk_label, C_TEXT if hk_hot else C_DIM,
                   self.r_hotkey.x, self.r_hotkey.centery - self.f_body.get_height() // 2)

        # dropdown list (drawn last so it overlays the buttons)
        if self.dd_open:
            pygame.draw.rect(scr, (30, 30, 35), self.r_list, border_radius=s(3))
            pygame.draw.rect(scr, C_BORDER_HOT, self.r_list, 1, border_radius=s(3))
            for i, label in enumerate(self.options):
                r = pygame.Rect(self.r_list.x + s(1), self.r_list.y + s(1) + i * self.item_h,
                                self.r_list.w - s(2), self.item_h)
                if r.collidepoint(mouse_ui):
                    pygame.draw.rect(scr, C_BTN_HOT, r)
                sel = i == self.aspect_idx
                self._text(self.f_body, label, C_TEXT if sel else C_DIM, r.x + s(10),
                           r.centery - self.f_body.get_height() // 2)
                if sel:
                    pygame.draw.circle(scr, C_TEXT, (r.right - s(14), r.centery), s(3))

        # modal
        if self.modal:
            scr.blit(self.dim, (0, 0))
            box = self.modal["box"]
            pygame.draw.rect(scr, (28, 28, 33), box, border_radius=s(4))
            pygame.draw.rect(scr, C_BORDER, box, 1, border_radius=s(4))
            y = box.y + s(20)
            for ln in self.modal["lines"]:
                self._text(self.f_body, ln, C_TEXT, box.centerx, y, center=True)
                y += self.f_body.get_linesize()
            for i, ((label, _), r) in enumerate(zip(self.modal["buttons"], self.modal["rects"])):
                down = self.pressed == ("modal", i) and r.collidepoint(mouse)
                fill = C_BTN_DOWN if down else (C_BTN_HOT if r.collidepoint(mouse) else C_BTN)
                pygame.draw.rect(scr, fill, r, border_radius=s(3))
                pygame.draw.rect(scr, C_BORDER_HOT if r.collidepoint(mouse) else C_BORDER, r, 1,
                                 border_radius=s(3))
                img = self.f_btn.render(label, True, C_TEXT)
                scr.blit(img, img.get_rect(center=r.center))

    # ---- main loop -------------------------------------------------------------
    def run(self):
        while self.running:
            if consume_hotkey() and not self.disable_shortcut:
                self.toggle_ui()
            self.tick()
            if self.ui_visible:
                self.draw()
                pygame.display.flip()
            # Always pump events and sleep a short time so the 3s check
            # still runs when the window is hidden or idle (no mouse events).
            for ev in pygame.event.get():
                self.handle(ev)
            pygame.time.wait(50)


def main():
    if sys.platform != "win32":
        fatal("This tool only works on Windows.")
    enable_dpi_awareness()          # before SDL creates any window
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:
        pass
    clear_stale_lock()
    write_lock()
    try:
        App().run()
    except Exception:
        import traceback
        fatal("Unexpected error:\n\n" + traceback.format_exc())
    finally:
        _uninstall_hook()
        clear_lock()
        pygame.quit()


if __name__ == "__main__":
    main()