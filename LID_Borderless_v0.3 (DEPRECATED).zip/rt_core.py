"""Core: shared constants / Config, Steam + UPK mark injector, and the reticle image pipeline (folders, Section_configs.json, compose, recolor, _Current)."""
import colorsys
import ctypes
import json
import math
import os
import random
import shutil
import struct
import sys
import threading
import time
from types import SimpleNamespace
import numpy as np


os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
sys.dont_write_bytecode = True

APP_TITLE = "Reticle Maker"
VERSION = "v0.3"
APP_ID = "Grimfuldev.LID.Borderless"
GAME_EXE = "brggame-steam.exe"
GAME_DIR_NAME = "LET IT DIE"

FROZEN = getattr(sys, "frozen", False)
HERE = os.path.dirname(os.path.abspath(sys.executable if FROZEN else __file__))
RES_DIR = getattr(sys, "_MEIPASS", HERE)
UI_ASSETS = os.path.join(RES_DIR, "UI_Assets")
CFG_PATH = os.path.join(HERE, "reticle_config.json")
RETICLES_DIR = os.path.join(HERE, "Reticles")
CURRENT_DIR = os.path.join(RETICLES_DIR, "_Current")
UPK_NAME = "UI_HUD_SF.upk"
IMG_EXT = (".webp", ".png")
IS_WIN = sys.platform == "win32"


def find_ui(name):
    for root in (UI_ASSETS, HERE):
        p = os.path.join(root, name)
        if os.path.isfile(p):
            return p
    return ""


# ----------------------------------------------------------------------------- keys

VK_NAMES = {0x08: "Backspace", 0x09: "Tab", 0x0D: "Enter", 0x13: "Pause", 0x14: "CapsLock", 0x1B: "Esc",
            0x20: "Space", 0x21: "PageUp", 0x22: "PageDown", 0x23: "End", 0x24: "Home", 0x25: "Left",
            0x26: "Up", 0x27: "Right", 0x28: "Down", 0x2C: "PrintScreen", 0x2D: "Insert", 0x2E: "Delete",
            0x6A: "Num*", 0x6B: "Num+", 0x6D: "Num-", 0x6E: "Num.", 0x6F: "Num/", 0x90: "NumLock",
            0x91: "ScrollLock", 0xA0: "LShift", 0xA1: "RShift", 0xA2: "LCtrl", 0xA3: "RCtrl", 0xA4: "LAlt",
            0xA5: "RAlt", 0xBA: ";", 0xBB: "=", 0xBC: ",", 0xBD: "-", 0xBE: ".", 0xBF: "/", 0xC0: "`",
            0xDB: "[", 0xDC: "\\", 0xDD: "]", 0xDE: "'", 0x05: "Mouse4", 0x06: "Mouse5"}
for _i in range(10):
    VK_NAMES[0x30 + _i] = str(_i)
    VK_NAMES[0x60 + _i] = "Num%d" % _i
for _i in range(26):
    VK_NAMES[0x41 + _i] = chr(65 + _i)
for _i in range(24):
    VK_NAMES[0x70 + _i] = "F%d" % (_i + 1)
NAME_VK = {v.lower(): k for k, v in VK_NAMES.items()}
MOUSE_VK = {"lmb": 0x01, "rmb": 0x02, "mmb": 0x04}
MOUSE_CHOICES = ["RMB", "LMB", "MMB"]
JOY_CHOICES = ["None", "A_Cross", "B_Circle", "X_Square", "Y_Triangle", "LB", "LT", "RB", "RT", "Start"]
JOY_BITS = {"a_cross": 0x1000, "b_circle": 0x2000, "x_square": 0x4000, "y_triangle": 0x8000,
            "lb": 0x0100, "rb": 0x0200, "start": 0x0010}


def vk_of(name):
    return NAME_VK.get(str(name or "").strip().lower(), 0)


# ----------------------------------------------------------------------------- config

DEFAULT_CFG = {
    "steam_exe": "",
    "hide_grid": False,
    "dot": None,
    "overlay": {"x": 0, "y": 0},
    "show_marker": True,
    "reticle_scale": 0,
    "override_color": [255, 255, 255],
    "override_enabled": False,
    "subtract_opacity": 0,
    "auto_unlock_sha_mark": False,
    "auto_unlock_sha_mark_note": "Advanced. true = when the borderless app starts (game closed, Steam done installing) and a game update undid your changes, unlock the SHA check again and reinject the last mark (marker_color / inject_size, default black 2 px). Default: false",
    "post_outline": True,
    "outline_width": 1.5,
    "outline_width_note": "Outline thickness in pixels. Original value: 1.5",
    "outline_blur": 3,
    "outline_blur_note": "Outline blur strength (the Gaussian sigma in pixels is this value / 2). Original value: 3",
    "outline_opacity": 70,
    "outline_opacity_note": "How visible the outline is, 0-100 (100 = solid black, 0 = invisible). Original value: 70",
    "marker_color": [0, 0, 0],
    "marker_size": 1,
    "inject_size": 2,
    "deviation_level": 5,
    "persist_seconds": 0.2,
    "wait_to_engage": 0.1,
    "Mark_retry_delay": 0.1,
    "calibration_hold_seconds": 1.5,
    "mouse_key": "LMB",
    "keyboard_key": "",
    "keyboard_key_2": "",
    "joystick_key": "None",
    "ui_hotkey": "",
    "selected": None,
}
DROPPED = ("auto_unlock_sha", "auto_unlock_sha_note", "verbose", "_help", "mask_margin", "search_radius", "white_level", "disable_hide",
           "look_interval_seconds", "hold_key", "calibration_key")


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def num(v, default, lo, hi, integer=False):
    try:
        v = float(v)
        if v != v:
            raise ValueError
    except (TypeError, ValueError):
        v = default
    v = clamp(v, lo, hi)
    return int(round(v)) if integer else v


def parse_rgb(v, default=(255, 255, 255)):
    """'12,34,56' / '#aabbcc' / [r,g,b] -> (r,g,b) or the default."""
    try:
        if isinstance(v, str):
            t = v.strip()
            if t.startswith("#") or (len(t) == 6 and all(c in "0123456789abcdefABCDEF" for c in t)
                                     and "," not in t):
                t = t.lstrip("#")
                return (int(t[0:2], 16), int(t[2:4], 16), int(t[4:6], 16))
            parts = [p for p in t.replace(";", ",").replace(" ", ",").split(",") if p != ""]
            v = parts
        if len(v) != 3:
            raise ValueError
        out = tuple(int(float(c)) for c in v)
        if any(c < 0 or c > 255 for c in out):
            raise ValueError
        return out
    except (TypeError, ValueError):
        return default


def rgb_text(c):
    return "%d,%d,%d" % tuple(c)


class Config:
    """The shared JSON. Thread-safe; writes are atomic; reloads when the file changes on disk."""

    def __init__(self, path=CFG_PATH):
        self.path = path
        self.lock = threading.RLock()
        self.data = json.loads(json.dumps(DEFAULT_CFG))
        self.mtime = None
        self.warned = False
        if not os.path.isfile(self.path):
            self._write()
        self.reload(force=True)

    def _write(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
            os.replace(tmp, self.path)
            self.mtime = os.path.getmtime(self.path)
        except OSError as e:
            print("Could not write", self.path, "-", e)

    @staticmethod
    def migrate(d):
        """Old key names -> new ones. Returns True when something changed."""
        changed = False
        if "disable_hide" in d and "show_marker" not in d:
            d["show_marker"] = bool(d["disable_hide"])
        if "look_interval_seconds" in d and "Mark_retry_delay" not in d:
            d["Mark_retry_delay"] = d["look_interval_seconds"]
        key = d.get("hold_key", d.get("calibration_key"))
        if key and "mouse_key" not in d:
            k = str(key).strip().upper()
            if k in MOUSE_CHOICES:
                d["mouse_key"] = k
            elif vk_of(k):
                d["keyboard_key"] = VK_NAMES[vk_of(k)]
        if "white_level" in d and "deviation_level" not in d:
            try:
                d["deviation_level"] = clamp(255 - int(float(d["white_level"])), 0, 255)
            except (TypeError, ValueError):
                pass
        if "auto_unlock_sha" in d and "auto_unlock_sha_mark" not in d:      # renamed
            d["auto_unlock_sha_mark"] = bool(d["auto_unlock_sha"])
        for k in DROPPED:
            if k in d:
                del d[k]
                changed = True
        for k, v in DEFAULT_CFG.items():
            if k not in d:
                d[k] = json.loads(json.dumps(v))
                changed = True
        return changed

    def reload(self, force=False):
        """True when the file was re-read (its contents changed on disk)."""
        with self.lock:
            try:
                m = os.path.getmtime(self.path)
                if not force and m == self.mtime:
                    return False
                with open(self.path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if not isinstance(data, dict):
                    raise ValueError("top level must be an object")
                self.warned = False
                before = json.dumps(data, sort_keys=True)
                self.migrate(data)
                self.data = data
                self.mtime = m
                if json.dumps(data, sort_keys=True) != before:
                    self._write()
                return True
            except (OSError, ValueError) as e:
                if not self.warned:
                    print("reticle_config.json is not valid, keeping the last good values:", e)
                    self.warned = True
                return False

    def get(self, key, default=None):
        with self.lock:
            return self.data.get(key, default)

    def set(self, **kw):
        with self.lock:
            self.data.update(kw)
            self._write()

    def set_overlay(self, x=None, y=None):
        with self.lock:
            ov = self.data.get("overlay") if isinstance(self.data.get("overlay"), dict) else {}
            ov = dict(ov)
            if x is not None:
                ov["x"] = x
            if y is not None:
                ov["y"] = y
            self.data["overlay"] = ov
            self._write()

    def values(self):
        with self.lock:
            d = self.data
            ov = d.get("overlay") if isinstance(d.get("overlay"), dict) else {}
            mouse = str(d.get("mouse_key", "LMB")).strip().lower()
            joy = str(d.get("joystick_key", "None")).strip().lower()
            rgb = parse_rgb(d.get("marker_color"), (0, 0, 0))
            return SimpleNamespace(
                off_x=num(ov.get("x"), 0, -2000, 2000), off_y=num(ov.get("y"), 0, -2000, 2000),
                size=num(d.get("marker_size"), 1, 1, 6, True), hide=not bool(d.get("show_marker", False)),
                dev=num(d.get("deviation_level"), 5, 0, 255, True), color=(rgb[2], rgb[1], rgb[0]),
                hold=num(d.get("calibration_hold_seconds"), 1.5, 0.2, 60),
                mouse_vk=MOUSE_VK.get(mouse, 0x01), kb_vk=vk_of(d.get("keyboard_key")),
                kb2_vk=vk_of(d.get("keyboard_key_2")), joy=joy if joy in JOY_BITS or joy in ("lt", "rt") else "",
                wait=num(d.get("wait_to_engage"), 0.1, 0, 5), every=num(d.get("Mark_retry_delay"), 0.1, 0.03, 5),
                persist=num(d.get("persist_seconds"), 0.2, 0, 60), dot=d.get("dot"))

    @staticmethod
    def dot_for(dot, res):
        try:
            if dot and dot.get("resolution") == res:
                return (float(dot["x"]), float(dot["y"]), int(dot["w"]), int(dot["h"]))
        except (AttributeError, KeyError, TypeError, ValueError):
            pass
        return None


def steam_roots(steam_exe):
    """Every Steam library folder (the Steam folder itself plus those in libraryfolders.vdf)."""
    base = os.path.dirname(os.path.abspath(steam_exe))
    roots = [base]
    vdf = os.path.join(base, "steamapps", "libraryfolders.vdf")
    try:
        with open(vdf, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                parts = line.split('"')
                if len(parts) >= 4 and parts[1].lower() == "path":
                    p = parts[3].replace("\\\\", "\\")
                    if p and p not in roots:
                        roots.append(p)
    except OSError:
        pass
    return roots


def find_game_dirs(steam_exe):
    """-> (upk_path, bin_dir, exe_path) or None."""
    if not steam_exe or os.path.basename(steam_exe).lower() != "steam.exe":
        return None
    for root in steam_roots(steam_exe):
        game = os.path.join(root, "steamapps", "common", GAME_DIR_NAME)
        upk = os.path.join(game, "BrgGame", "CookedPCConsole", UPK_NAME)
        bin_dir = os.path.join(game, "Binaries", "Win64")
        exe = os.path.join(bin_dir, "BrgGame-Steam.exe")
        if os.path.isfile(upk) and os.path.isfile(exe):
            return upk, bin_dir, exe
    return None


def game_running():
    """True while BrgGame-Steam.exe is a running process."""
    if not IS_WIN:
        return False
    try:
        from ctypes import wintypes as wt

        class PE(ctypes.Structure):
            _fields_ = [("dwSize", wt.DWORD), ("cntUsage", wt.DWORD), ("th32ProcessID", wt.DWORD),
                        ("th32DefaultHeapID", ctypes.c_size_t), ("th32ModuleID", wt.DWORD),
                        ("cntThreads", wt.DWORD), ("th32ParentProcessID", wt.DWORD),
                        ("pcPriClassBase", wt.LONG), ("dwFlags", wt.DWORD), ("szExeFile", wt.WCHAR * 260)]

        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.CreateToolhelp32Snapshot.restype = ctypes.c_void_p
        k.CreateToolhelp32Snapshot.argtypes = [wt.DWORD, wt.DWORD]
        k.Process32FirstW.argtypes = [ctypes.c_void_p, ctypes.POINTER(PE)]
        k.Process32NextW.argtypes = [ctypes.c_void_p, ctypes.POINTER(PE)]
        k.CloseHandle.argtypes = [ctypes.c_void_p]
        snap = k.CreateToolhelp32Snapshot(0x2, 0)
        if not snap or snap == ctypes.c_void_p(-1).value:
            return False
        try:
            pe = PE()
            pe.dwSize = ctypes.sizeof(PE)
            ok = k.Process32FirstW(snap, ctypes.byref(pe))
            while ok:
                if pe.szExeFile.lower() == GAME_EXE:
                    return True
                ok = k.Process32NextW(snap, ctypes.byref(pe))
        finally:
            k.CloseHandle(snap)
    except Exception:
        pass
    return False


def pid_alive(pid):
    if not IS_WIN:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    try:
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.OpenProcess.restype = ctypes.c_void_p
        h = k.OpenProcess(0x1000, False, pid)
        if not h:
            return False
        code = ctypes.c_ulong()
        k.GetExitCodeProcess(ctypes.c_void_p(h), ctypes.byref(code))
        k.CloseHandle(ctypes.c_void_p(h))
        return code.value == 259
    except Exception:
        return True


# ----------------------------------------------------------------------------- UPK maker

UPK_TAG = 0x9E2A83C1
TEXTURE = "TX_UI_HUD_Base_Status_v06_00"
TEX_W, TEX_H = 2048, 860
PIXEL_BYTES = TEX_W * TEX_H * 4
BOX = (1405, 0, 1463, 50)
EXPECT_VISIBLE = 1527
OLD_CENTER = (1434, 24)
MARKER_SHIFT_X = -20
BLOCK = 0x20000
INJECT_MIN = 2      # a 1 px mark gets blurred away by the game scaling, so it is not offered
INJECT_MAX = 4


class MakerError(Exception):
    pass


class Package:
    def __init__(self, data):
        self.d = data
        if struct.unpack_from("<I", data, 0)[0] != UPK_TAG:
            raise ValueError("this is not an Unreal Engine package")
        o = 12
        n, = struct.unpack_from("<i", data, o)
        o += 4 + n
        self.flags, = struct.unpack_from("<I", data, o)
        o += 4
        (self.name_count, self.name_off, self.export_count, self.export_off,
         self.import_count, self.import_off) = struct.unpack_from("<6i", data, o)
        o += 24 + 20 + 16
        gens, = struct.unpack_from("<i", data, o)
        o += 4 + 12 * gens + 8
        cflags, nchunks = struct.unpack_from("<Ii", data, o)
        o += 8
        self.compressed = bool(self.flags & 0x02000000) and nchunks > 0
        if self.compressed:
            if cflags != 2:
                raise ValueError("unsupported compression type (only LZO is supported)")
            try:
                import lzallright
            except ImportError:
                raise MakerError("Missing dependency: pip install lzallright")
            self.lzo = lzallright.LZOCompressor
            self.table_off = o
            self.chunks = [list(struct.unpack_from("<4i", data, o + 16 * i)) for i in range(nchunks)]
            self.summary_size = self.chunks[0][0]
            self.parts = []
            for uo, us, co, cs in self.chunks:
                _tag, bsz, _ctot, utot = struct.unpack_from("<IiiI", data, co)
                nb = (utot + bsz - 1) // bsz
                p = co + 16 + 8 * nb
                out = bytearray()
                for i in range(nb):
                    bc = struct.unpack_from("<ii", data, co + 16 + 8 * i)[0]
                    out += bytes(self.lzo.decompress(data[p:p + bc]))
                    p += bc
                if len(out) != us:
                    raise ValueError("chunk size mismatch")
                self.parts.append(out)
            self.orig_parts = [bytes(x) for x in self.parts]
            self.img = bytearray(data[:self.summary_size])
            for part in self.parts:
                self.img += part
        else:
            self.img = bytearray(data)
        self._read_tables()

    def _fname(self, idx, num_):
        s = self.names[idx]
        return s if num_ == 0 else "%s_%d" % (s, num_ - 1)

    def _read_tables(self):
        img, o = self.img, self.name_off
        self.names = []
        for _ in range(self.name_count):
            n, = struct.unpack_from("<i", img, o)
            o += 4
            self.names.append(img[o:o + n - 1].decode("latin1"))
            o += n + 8
        o = self.export_off
        self.exports = {}
        for _ in range(self.export_count):
            nm, nmn = struct.unpack_from("<ii", img, o + 12)
            size, off = struct.unpack_from("<ii", img, o + 32)
            netc = struct.unpack_from("<Ii", img, o + 40)[1]
            o += 24 + 16 + 8 + 4 * netc + 20
            self.exports[self._fname(nm, nmn)] = (off, size)

    def pixel_offset(self):
        off, size = self.exports[TEXTURE]
        k = bytes(self.img[off:off + size]).find(struct.pack("<ii", PIXEL_BYTES, PIXEL_BYTES))
        if k < 0:
            raise ValueError("texture pixel data not found")
        return off + k + 12

    def build(self):
        if not self.compressed:
            return bytes(self.img)
        d = self.d
        for i, (uo, us, co, cs) in enumerate(self.chunks):
            self.parts[i] = bytearray(self.img[uo:uo + us])
        comp = []
        for idx, part in enumerate(self.parts):
            uo, us, co, cs = self.chunks[idx]
            if bytes(part) == self.orig_parts[idx]:
                comp.append(d[co:co + cs])
                continue
            nb = (len(part) + BLOCK - 1) // BLOCK
            blocks = [bytes(self.lzo().compress(bytes(part[i * BLOCK:(i + 1) * BLOCK]))) for i in range(nb)]
            head = struct.pack("<IiiI", UPK_TAG, BLOCK, sum(len(b) for b in blocks), len(part))
            head += b"".join(struct.pack("<ii", len(b), min(BLOCK, len(part) - i * BLOCK))
                             for i, b in enumerate(blocks))
            comp.append(head + b"".join(blocks))
        out = bytearray(d[:self.table_off])
        pos = self.chunks[0][2]
        table = bytearray()
        for (uo, us, co, cs), blob in zip(self.chunks, comp):
            table += struct.pack("<4i", uo, us, pos, len(blob))
            pos += len(blob)
        out += table
        out += d[self.table_off + len(table):self.chunks[0][2]]
        for blob in comp:
            out += blob
        return bytes(out)


def visible(img, px, box):
    x0, y0, x1, y1 = box
    return sum(1 for y in range(y0, y1) for x in range(x0, x1) if img[px + (y * TEX_W + x) * 4 + 3])


def clear_box(img, px, box):
    x0, y0, x1, y1 = box
    for y in range(y0, y1):
        row = px + (y * TEX_W + x0) * 4
        img[row:row + (x1 - x0) * 4] = bytes((x1 - x0) * 4)


def marker_geom(size):
    size = int(clamp(size, INJECT_MIN, INJECT_MAX))
    x, y = OLD_CENTER[0] + MARKER_SHIFT_X - size // 2, OLD_CENTER[1] - size // 2
    return size, x, y


def marker_row(color, size):
    r, g, b = (int(clamp(c, 0, 255)) for c in color)
    return bytes((b, g, r, 255)) * size


def paint_marker(img, px, color, size):
    size, mx, my = marker_geom(size)
    for y in range(my, my + size):
        row = px + (y * TEX_W + mx) * 4
        img[row:row + size * 4] = marker_row(color, size)


def has_marker(img, px, color, size):
    size, mx, my = marker_geom(size)
    if visible(img, px, BOX) != size * size:
        return False
    for y in range(my, my + size):
        row = px + (y * TEX_W + mx) * 4
        if bytes(img[row:row + size * 4]) != marker_row(color, size):
            return False
    return True


def check_original(path):
    try:
        with open(path, "rb") as f:
            pkg = Package(f.read())
    except (OSError, ValueError, struct.error) as e:
        raise MakerError("cannot read it as a package: %s" % e)
    if TEXTURE not in pkg.exports:
        raise MakerError("this is not UI_HUD_SF.upk (texture %s not found)." % TEXTURE)
    px = pkg.pixel_offset()
    n = visible(pkg.img, px, BOX)
    if n != EXPECT_VISIBLE:
        raise MakerError("the reticle area has %d visible pixels instead of %d: this file is already modified "
                         "(or is a different version of the game)." % (n, EXPECT_VISIBLE))
    return pkg, px


def clean_temp_files(game_upk=None, exe=None):
    """Delete leftovers of an interrupted write: the .tmp files our atomic writes use, in the game folder
    and next to this program. Only these exact names are touched."""
    names = []
    if game_upk:
        names.append(game_upk + ".tmp")
        d, base = os.path.split(game_upk)
        try:
            names += [os.path.join(d, n) for n in os.listdir(d) if n.startswith(base + ".") and n.endswith(".backup.tmp")]
        except OSError:
            pass
    if exe:
        names.append(exe + ".tmp")
        d, base = os.path.split(exe)
        try:
            names += [os.path.join(d, n) for n in os.listdir(d) if n.startswith(base + ".") and n.endswith(".backup.tmp")]
        except OSError:
            pass
    names.append(CFG_PATH + ".tmp")
    try:
        names += [os.path.join(CURRENT_DIR, n) for n in os.listdir(CURRENT_DIR) if n.startswith("~tmp_")]
    except OSError:
        pass
    for p in names:
        try:
            if os.path.isfile(p):
                os.remove(p)
        except OSError:
            pass


def atomic_copy_bytes(dst, data):
    tmp = dst + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    with open(tmp, "rb") as f:
        if f.read() != data:
            os.remove(tmp)
            raise MakerError("the temporary file did not read back correctly - nothing was changed")
    os.replace(tmp, dst)


def _game_manifest(game_file):
    """Text of the game's Steam appmanifest (found from any file inside the game folder), or ''."""
    import re
    d = os.path.abspath(game_file)
    while True:
        parent = os.path.dirname(d)
        if parent == d:
            return ""
        if os.path.basename(d).lower() == "steamapps":
            break
        d = parent
    try:
        names = sorted(n for n in os.listdir(d) if n.startswith("appmanifest_") and n.endswith(".acf"))
    except OSError:
        return ""
    for n in names:
        try:
            with open(os.path.join(d, n), "r", encoding="utf-8", errors="replace") as f:
                txt = f.read()
        except OSError:
            continue
        m = re.search(r'"installdir"\s+"([^"]*)"', txt)
        if m and m.group(1).lower() == GAME_DIR_NAME.lower():
            return txt
    return ""


def game_build(game_file):
    """Steam's build id of the installed game ("" when it cannot be read)."""
    import re
    m = re.search(r'"buildid"\s+"(\d+)"', _game_manifest(game_file))
    return m.group(1) if m else ""


def game_install_complete(game_file):
    """False while Steam is still installing / updating the game (StateFlags 4 = fully installed)."""
    import re
    m = re.search(r'"StateFlags"\s+"(\d+)"', _game_manifest(game_file))
    return m is None or int(m.group(1)) == 4


def auto_unlock_sha():
    """Once per start of the borderless app, when "auto_unlock_sha_mark" is true in reticle_config.json, redo what a
    game update undid. The sign is the same for both files: the game's file is original again but the only backup
    of it belongs to an older build (so it was unlocked / injected here before, and nobody restored it).
      - BrgGame-Steam.exe  active again  -> unlock the SHA check again
      - UI_HUD_SF.upk      clean again   -> inject the last applied mark again (marker_color / inject_size of the
                                            config, which are written by every Inject Mark; default black, 2 px)
    -> a message for the status line, '' when nothing was done."""
    import Hash_remover as HR
    cfg = Config()
    if not cfg.get("auto_unlock_sha_mark"):
        return ""
    paths = find_game_dirs(cfg.get("steam_exe"))
    if not paths or game_running() or not game_install_complete(paths[0]):
        return ""
    upk, _bin, exe = paths
    build = game_build(upk)
    done = []
    try:
        clean_temp_files(upk, exe)
        if HR.list_backups(exe) and HR.valid_backup(exe, build) is None and HR.sha_status(exe, build)["state"] == "active":
            HR.turn_off_all(exe, build=build)
            done.append("SHA unlocked again")
        if HR.list_backups(upk) and HR.valid_backup(upk, build) is None:
            try:
                check_original(upk)
            except MakerError:
                pass                      # the update did not touch the file (or it is not a clean original)
            else:
                color = parse_rgb(cfg.get("marker_color"), (0, 0, 0))
                size = num(cfg.get("inject_size"), INJECT_MIN, INJECT_MIN, INJECT_MAX, True)
                inject_mark(upk, color, size, build)
                done.append("mark reapplied (%s, %d px)" % (rgb_text(color), size))
    except (HR.Problem, MakerError, OSError) as e:
        return "Auto update after the game update failed: %s" % e
    return ("The game was updated: " + ", ".join(done) + ".") if done else ""


def ensure_backup(game_upk, build=""):
    """Keep the unmodified UI_HUD_SF.upk as UI_HUD_SF.upk.<buildid>.backup next to it in the game folder.
    A clean game file is always the newest truth: when it differs from the saved copy (the game was updated) the
    copy is replaced. A modified game file needs a saved copy that fits this build. Returns the backup path."""
    import Hash_remover as HR
    usable = HR.valid_backup(game_upk, build)
    try:
        check_original(game_upk)
        clean = True
    except MakerError as e:
        clean, why = False, e
    if clean:
        try:
            return str(HR.refresh_backup(game_upk, build))
        except (HR.Problem, OSError) as e:
            raise MakerError("Could not save the backup of %s: %s" % (UPK_NAME, e))
    if usable is None:
        extra = (" The saved copy found belongs to an older version of the game." if HR.list_backups(game_upk) else "")
        raise MakerError("The game's %s is not the original, so it was not saved as backup: %s%s "
                         "In Steam use 'Verify integrity of game files' to get the original back." % (UPK_NAME, why, extra))
    try:
        check_original(str(usable))
    except MakerError as e:
        raise MakerError("%s is not the original: %s Replace it with the unmodified %s "
                         "(or delete it to save it again from the game)." % (usable.name, e, UPK_NAME))
    return str(usable)


def inject_mark(game_upk, color, size, build=""):
    """Write the game's UI_HUD_SF.upk with the reticle cleared and a one-colour mark in its place."""
    clean_temp_files(game_upk)
    backup = ensure_backup(game_upk, build)
    pkg, px = check_original(backup)
    clear_box(pkg.img, px, BOX)
    paint_marker(pkg.img, px, color, size)
    out = pkg.build()
    chk = Package(out)
    cpx = chk.pixel_offset()
    if not has_marker(chk.img, cpx, color, size) or \
            bytes(chk.img[cpx:cpx + PIXEL_BYTES]) != bytes(pkg.img[px:px + PIXEL_BYTES]):
        raise MakerError("Self-check failed, nothing was written.")
    atomic_copy_bytes(game_upk, out)


def restore_upk(game_upk, build=""):
    """Put the original UI_HUD_SF.upk back. Returns True when it had to change the game file.
    Only a saved copy that fits the game's current build is used."""
    import Hash_remover as HR
    backup = HR.valid_backup(game_upk, build)
    if backup is None:
        return False
    backup = str(backup)
    check_original(backup)
    with open(backup, "rb") as f:
        data = f.read()
    try:
        with open(game_upk, "rb") as f:
            if f.read() == data:
                return False
    except OSError:
        pass
    atomic_copy_bytes(game_upk, data)
    return True


DEFAULT_SELECTED = {"outer": ["_Outer/_Default/Plus.png"], "center": ["_Center/_Default/Dot.png"]}
CURRENT_FILE = "Reticle.webp"
WHITE = (255, 255, 255)
# Options kept in every folder's Section_configs.json. Colour / opacity / scale exist for both kinds;
# the rotate / dupe / spread extras only for Outer folders and Displace only for Center folders.
DEFAULT_COMMON = {"color": WHITE, "opacity": 100, "size": 0, "stretch_x": 0, "stretch_y": 0}
DEFAULT_OUTER = dict({"dupe": 1, "rotate_dupe": 0, "rotate_dupe_inv": False, "rotate_all": 0, "rotate_all_inv": False,
                      "spread": 0.0}, **DEFAULT_COMMON)
DEFAULT_CENTER = dict(DEFAULT_COMMON, rotate=0, displace_x=0.0, displace_y=0.0)
DEFAULTS = {"outer": DEFAULT_OUTER, "center": DEFAULT_CENTER}
MAX_DUPE = 64
MAX_CANVAS = 1024


def is_image(name):
    return name.lower().endswith(IMG_EXT)


def norm_section(kind, d):
    """Options of one folder with every value valid (invalid ones fall back to their default)."""
    d = d if isinstance(d, dict) else {}
    o = {}
    if kind == "outer":
        o["dupe"] = num(d.get("dupe"), 1, 1, MAX_DUPE, True)
        for k in ("rotate_dupe", "rotate_all"):
            o[k] = num(d.get(k), 0, 0, 359, True)
        o["spread"] = num(d.get("spread"), 0, -100, 100)
        for k in ("rotate_dupe_inv", "rotate_all_inv"):
            o[k] = bool(d.get(k, False))
    else:
        o["rotate"] = num(d.get("rotate"), 0, -359, 359, True)
        o["displace_x"] = num(d.get("displace_x"), 0, -100, 100)
        o["displace_y"] = num(d.get("displace_y"), 0, -100, 100)
    o["color"] = parse_rgb(d.get("color"), WHITE)
    o["opacity"] = num(d.get("opacity"), 100, 0, 100, True)
    o["size"] = num(d.get("size"), 0, -100, 100, True)
    o["stretch_x"] = num(d.get("stretch_x"), 0, -100, 500, True)
    o["stretch_y"] = num(d.get("stretch_y"), 0, -100, 500, True)
    return o


def norm_outer(d):
    return norm_section("outer", d)


def kind_of(fid):
    """'outer' / 'center' for a folder id such as '_Center/_Default'."""
    return "center" if fid.replace("\\", "/").split("/")[0] == os.path.basename(KIND_DIRS["center"]) else "outer"


SECTION_CFG = "Section_configs.json"
_sec_cache = {}


def section_cfg_path(fid):
    return os.path.join(abs_of(fid), SECTION_CFG)


def load_section_cfg(fid):
    """Outer options of ONE folder, read from the Section_configs.json inside it (defaults when missing or
    broken). Subfolders have their own file and are never affected."""
    p = section_cfg_path(fid)
    try:
        st = os.stat(p)
        sig = (st.st_mtime_ns, st.st_size)
    except OSError:
        return norm_section(kind_of(fid), None)
    hit = _sec_cache.get(p)
    if hit and hit[0] == sig:
        return dict(hit[1])
    try:
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = None
    o = norm_section(kind_of(fid), d)
    _sec_cache[p] = (sig, o)
    return dict(o)


def save_section_cfg(fid, opts):
    """Write a folder's Section_configs.json (atomically), only when its content changes."""
    kind = kind_of(fid)
    o = norm_section(kind, opts)
    p = section_cfg_path(fid)
    if not os.path.isdir(os.path.dirname(p)):
        return
    try:
        with open(p, "r", encoding="utf-8") as f:
            if norm_section(kind, json.load(f)) == o and os.path.getsize(p) > 2:
                return
    except (OSError, ValueError):
        pass
    tmp = p + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(o, f, indent=2)
        os.replace(tmp, p)
    except OSError:
        try:
            os.remove(tmp)
        except OSError:
            pass


def ensure_section_cfgs():
    """Every folder under Reticles/_Outer and Reticles/_Center gets its own Section_configs.json."""
    for kind in ("outer", "center"):
        for dirpath, _dirs, names in os.walk(KIND_DIRS[kind]):
            if dirpath == KIND_DIRS[kind] and not any(is_image(n) for n in names):
                continue        # the _Outer / _Center root only counts when images lie directly in it
            if not os.path.isfile(os.path.join(dirpath, SECTION_CFG)):
                save_section_cfg(rel_of(dirpath), None)


def make_default_images():
    """Procedural defaults, used when no bundled Reticles folder exists: {kind: {file name: PIL image}}."""
    from PIL import Image, ImageDraw
    S = 4

    def canvas(n=64):
        return Image.new("RGBA", (n * S, n * S), (0, 0, 0, 0)), n

    def fin(im, n):
        return im.resize((n, n), Image.LANCZOS)

    W = (255, 255, 255, 255)
    outer = {}
    im, n = canvas()
    d = ImageDraw.Draw(im)
    for box in ((30, 10, 34, 26), (30, 38, 34, 54), (10, 30, 26, 34), (38, 30, 54, 34)):
        d.rounded_rectangle([c * S for c in box], radius=2 * S, fill=W)
    outer["Plus.png"] = fin(im, n)
    im, n = canvas()
    d = ImageDraw.Draw(im)
    d.rectangle([30 * S, 4 * S, 34 * S, 60 * S], fill=W)
    d.rectangle([4 * S, 30 * S, 60 * S, 34 * S], fill=W)
    outer["Cross.webp"] = fin(im, n)
    im, n = canvas()
    ImageDraw.Draw(im).ellipse([10 * S, 10 * S, 54 * S, 54 * S], outline=W, width=2 * S)
    outer["Circle.webp"] = fin(im, n)
    im, n = canvas()
    ImageDraw.Draw(im).polygon([(32 * S, 20 * S), (46 * S, 44 * S), (18 * S, 44 * S)], outline=W, width=2 * S)
    outer["Triangle.webp"] = fin(im, n)
    center = {}
    im, n = canvas()
    ImageDraw.Draw(im).ellipse([29 * S, 29 * S, 35 * S, 35 * S], fill=W)
    center["Dot.png"] = fin(im, n)
    return {"outer": outer, "center": center}


KIND_DIRS = {"outer": os.path.join(RETICLES_DIR, "_Outer"), "center": os.path.join(RETICLES_DIR, "_Center")}


def default_folder(kind):
    return os.path.join(KIND_DIRS[kind], "_Default")


# The whole Reticles folder is packed into the exe (the .bat adds it as it is). It is pasted next to the exe when
# there is no Reticles folder yet. After that only two things are watched: the _Default folder of _Outer and of
# _Center (a deleted folder is restored with everything it had) and Plus.png / Dot.png inside them (restored
# when missing). Any other file or folder is never touched, deleted ones are not brought back.
BUNDLE_DIR = os.path.join(RES_DIR, "Reticles")
REQUIRED = {"outer": "Plus.png", "center": "Dot.png"}


def bundle_ok():
    """A packed Reticles folder exists and is not the live one (running from source it is the same folder)."""
    return os.path.isdir(BUNDLE_DIR) and os.path.abspath(BUNDLE_DIR) != os.path.abspath(RETICLES_DIR)


def _copy_tree(src, dst):
    """Copy a folder tree without overwriting anything that already exists."""
    for dirpath, _dirs, names in os.walk(src):
        out = os.path.join(dst, os.path.relpath(dirpath, src))
        os.makedirs(out, exist_ok=True)
        for n in names:
            if not os.path.exists(os.path.join(out, n)):
                shutil.copyfile(os.path.join(dirpath, n), os.path.join(out, n))


def _bundled_default(kind):
    p = os.path.join(BUNDLE_DIR, os.path.basename(KIND_DIRS[kind]), "_Default")
    return p if bundle_ok() and os.path.isdir(p) else ""


def _save_procedural(kind, only=None):
    folder = default_folder(kind)
    os.makedirs(folder, exist_ok=True)
    try:
        for n, im in make_default_images()[kind].items():
            if (only is None or n == only) and not os.path.exists(os.path.join(folder, n)):
                im.save(os.path.join(folder, n), lossless=True)
    except Exception as e:
        print("Could not create the default reticles:", e)


def paste_bundle():
    """No Reticles folder yet (first run): paste the whole packed one."""
    if bundle_ok() and not os.path.isdir(RETICLES_DIR):
        try:
            _copy_tree(BUNDLE_DIR, RETICLES_DIR)
        except OSError as e:
            print("Could not copy the packed Reticles folder:", e)


def restore_default_folder(kind):
    """The _Default folder of a kind was deleted: bring it back with everything it had."""
    src = _bundled_default(kind)
    if src:
        try:
            _copy_tree(src, default_folder(kind))
            return
        except OSError as e:
            print("Could not restore", default_folder(kind), "-", e)
    _save_procedural(kind)


def restore_required(kind):
    """Plus.png (_Outer) / Dot.png (_Center) are the defaults: restored whenever they are missing."""
    name = REQUIRED[kind]
    dst = os.path.join(default_folder(kind), name)
    if os.path.isfile(dst):
        return
    src = _bundled_default(kind)
    if src and os.path.isfile(os.path.join(src, name)):
        os.makedirs(default_folder(kind), exist_ok=True)
        shutil.copyfile(os.path.join(src, name), dst)
    else:
        _save_procedural(kind, name)


def _unique_dest(folder, name):
    base, ext = os.path.splitext(name)
    dst, i = os.path.join(folder, name), 2
    while os.path.exists(dst):
        dst = os.path.join(folder, "%s (%d)%s" % (base, i, ext))
        i += 1
    return dst


def _merge_move(src, dst_dir):
    """Move a file or folder into dst_dir without overwriting anything."""
    name = os.path.basename(src)
    dst = os.path.join(dst_dir, name)
    if os.path.isdir(src) and os.path.isdir(dst):
        for n in os.listdir(src):
            _merge_move(os.path.join(src, n), dst)
        try:
            os.rmdir(src)
        except OSError:
            pass
    else:
        os.makedirs(dst_dir, exist_ok=True)
        shutil.move(src, _unique_dest(dst_dir, name))


def clean_current():
    """_Current must hold a single reticle: all but one (random) are deleted."""
    try:
        files = [n for n in os.listdir(CURRENT_DIR) if is_image(n)]
    except OSError:
        return
    if len(files) > 1:
        keep = random.choice(files)
        for n in files:
            if n != keep:
                try:
                    os.remove(os.path.join(CURRENT_DIR, n))
                except OSError:
                    pass


def ensure_dirs():
    """Make the Reticles tree; anything lying in Reticles outside _Outer/_Center/_Current moves into _Outer."""
    paste_bundle()
    os.makedirs(RETICLES_DIR, exist_ok=True)
    for d in list(KIND_DIRS.values()) + [CURRENT_DIR]:
        os.makedirs(d, exist_ok=True)
    keep = {"_outer", "_center", "_current"}
    for n in os.listdir(RETICLES_DIR):
        if n.lower() in keep:
            continue
        try:
            _merge_move(os.path.join(RETICLES_DIR, n), KIND_DIRS["outer"])
        except OSError as e:
            print("Could not move", n, "into _Outer:", e)
    for kind in KIND_DIRS:
        if not os.path.isdir(default_folder(kind)):
            restore_default_folder(kind)
        restore_required(kind)
    clean_current()
    ensure_section_cfgs()


def rel_of(path):
    return os.path.relpath(path, RETICLES_DIR).replace("\\", "/")


def abs_of(rel):
    return os.path.join(RETICLES_DIR, *rel.split("/"))


def kind_sections(kind):
    """-> [(folder id (path under Reticles), label, [file paths])] ; _Default first, then by name."""
    base = KIND_DIRS[kind]
    out = []
    for dirpath, dirs, names in os.walk(base):
        dirs.sort(key=str.lower)
        files = [os.path.join(dirpath, n) for n in sorted(names, key=str.lower) if is_image(n)]
        if files:
            sub = os.path.relpath(dirpath, base).replace("\\", "/")
            out.append((rel_of(dirpath), "" if sub == "." else sub, files))
    out.sort(key=lambda s: (s[1] != "_Default", s[1].lower()))
    return out


def prune_selected(sel):
    """Selection {kind: [relative paths]} without broken links: missing files, files outside the kind's folder,
    and more than one pick per folder are dropped."""
    out = {}
    sel = sel if isinstance(sel, dict) else {}
    for kind in KIND_DIRS:
        seen, keep = set(), []
        for rel in (sel.get(kind) or []):
            if not isinstance(rel, str):
                continue
            rel = rel.replace("\\", "/")
            p = abs_of(rel)
            try:
                inside = os.path.commonpath([os.path.abspath(p), os.path.abspath(KIND_DIRS[kind])]) == \
                    os.path.abspath(KIND_DIRS[kind])
            except ValueError:
                inside = False
            folder = os.path.dirname(rel)
            if inside and is_image(rel) and os.path.isfile(p) and folder not in seen:
                seen.add(folder)
                keep.append(rel)
        out[kind] = keep
    return out


def current_name():
    try:
        for n in sorted(os.listdir(CURRENT_DIR)):
            if is_image(n):
                return n
    except OSError:
        pass
    return None


_img_cache = {}


def load_rgba(path):
    from PIL import Image
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        stamp = None
    hit = _img_cache.get(path)
    if hit and hit[0] == stamp:
        return hit[1]
    with Image.open(path) as im:
        a = np.asarray(im.convert("RGBA"), np.uint8).copy()
    if len(_img_cache) > 200:
        _img_cache.clear()
    _img_cache[path] = (stamp, a)
    return a


def _premul(rgba):
    a = rgba.astype(np.float32) / 255.0
    a[..., :3] *= a[..., 3:4]
    return a


def _straight(pm):
    a = np.clip(pm[..., 3:4], 0, 1)
    rgb = np.where(a > 1e-6, pm[..., :3] / np.maximum(a, 1e-6), 0.0)
    return np.clip(np.rint(np.concatenate([rgb, a], -1) * 255), 0, 255).astype(np.uint8)


def _resample_pm(pm, size=None, angle=None, filt=None):
    """Resize (size=(w, h)) or rotate (angle, expanding the canvas) a premultiplied float RGBA array.
    Every channel is resampled as a float image, so there is no 8-bit rounding of the edge pixels (that
    rounding is what tinted / bled the soft edges), and the overshoot of the filter is clamped."""
    from PIL import Image
    chans = []
    for k in range(4):
        im = Image.fromarray(np.ascontiguousarray(pm[..., k], np.float32), "F")
        if size is not None:
            im = im.resize(size, filt)
        else:
            im = im.rotate(angle, resample=filt, expand=True)
        chans.append(np.asarray(im, np.float32))
    out = np.stack(chans, -1)
    a = np.clip(out[..., 3], 0.0, 1.0)
    out[..., 3] = a
    out[..., :3] = np.clip(out[..., :3], 0.0, a[..., None])
    return out


def _paste_over(canvas, im, left, top):
    """canvas, im: float premultiplied HxWx4. Pastes im with its top-left at (left, top), alpha 'over'."""
    H, W = canvas.shape[:2]
    h, w = im.shape[:2]
    x0, y0 = max(0, left), max(0, top)
    x1, y1 = min(W, left + w), min(H, top + h)
    if x1 <= x0 or y1 <= y0:
        return
    src = im[y0 - top:y1 - top, x0 - left:x1 - left]
    dst = canvas[y0:y1, x0:x1]
    canvas[y0:y1, x0:x1] = src + dst * (1.0 - src[..., 3:4])


def stack_images(paths):
    """All images centred on one even-sized canvas -> premultiplied float array, or None."""
    ims = []
    for p in paths:
        try:
            ims.append(_premul(load_rgba(p)))
        except Exception:
            pass
    if not ims:
        return None
    W = max(i.shape[1] for i in ims)
    H = max(i.shape[0] for i in ims)
    W += W % 2
    H += H % 2
    c = np.zeros((H, W, 4), np.float32)
    for i in ims:
        _paste_over(c, i, (W - i.shape[1]) // 2, (H - i.shape[0]) // 2)
    return c


def _rotate_pm(pm, deg):
    """Rotate a premultiplied float image clockwise by `deg`, growing the canvas.
    Multiples of 90 are exact (no resampling at all). Other angles are supersampled: the image is
    enlarged smoothly (which also softens the stair-steps of hard-edged sprites), rotated, and averaged
    back down, which gives clean anti-aliased edges instead of stair-stepped or smeared ones."""
    from PIL import Image
    deg = deg % 360
    if deg == 0:
        return pm
    if deg % 90 == 0:
        return np.ascontiguousarray(np.rot90(pm, k=-(deg // 90)))
    big = max(pm.shape[:2])
    ss = 4 if big <= 256 else 2 if big <= 512 else 1
    if ss == 1:
        r = _resample_pm(pm, angle=-deg, filt=Image.BICUBIC)
        return np.pad(r, ((0, r.shape[0] % 2), (0, r.shape[1] % 2), (0, 0)))
    h0, w0 = pm.shape[:2]
    hi = _resample_pm(pm, size=(w0 * ss, h0 * ss), filt=Image.BICUBIC)
    hi = _resample_pm(hi, angle=-deg, filt=Image.BILINEAR)
    h, w = hi.shape[:2]
    # the result must have EVEN sides (a multiple of 2 * ss before averaging down): an odd-sized layer sits
    # half a pixel off the centre of the (even) canvas it is placed on, which showed up as a rotated sight not
    # lining up with a centre dot. Padding is split evenly, so the error is at most 1 / (2 * ss) px.
    m = 2 * ss
    ph, pw = (-h) % m, (-w) % m
    if ph or pw:
        hi = np.pad(hi, ((ph // 2, ph - ph // 2), (pw // 2, pw - pw // 2), (0, 0)))
    h, w = hi.shape[:2]
    return hi.reshape(h // ss, ss, w // ss, ss, 4).mean((1, 3), dtype=np.float32)


def outer_transform(base, opts):
    """Duplicate / rotate / spread the combined outer image around its centre."""
    o = norm_outer(opts)
    n = o["dupe"]
    h0, w0 = base.shape[:2]
    sd = -1 if o["rotate_dupe_inv"] else 1
    sa = -1 if o["rotate_all_inv"] else 1
    # Spread pushes each copy outward along the direction its own content points to (e.g. a line
    # drawn below the centre points down). Symmetric images have no direction -> 0 deg = right.
    al = base[..., 3].astype(np.float64)
    tot = al.sum()
    base_ang = 0.0
    if tot > 0:
        cy = (al.sum(1) * (np.arange(h0) - (h0 - 1) / 2.0)).sum() / tot
        cx = (al.sum(0) * (np.arange(w0) - (w0 - 1) / 2.0)).sum() / tot
        if math.hypot(cx, cy) > 0.5:
            base_ang = math.degrees(math.atan2(cy, cx))
    placed = []
    for i in range(n):
        rot = i * o["rotate_dupe"] * sd + o["rotate_all"] * sa
        arr = _rotate_pm(base, rot)
        # every copy, the original included, moves the same distance from the centre
        ms = 1
        ang = math.radians(base_ang + rot)
        dx = o["spread"] * ms * math.cos(ang)
        dy = o["spread"] * ms * math.sin(ang)
        ih, iw = arr.shape[:2]
        placed.append((arr, int(round(dx - iw / 2.0)), int(round(dy - ih / 2.0))))
    hw = max(max(abs(l), abs(l + a.shape[1])) for a, l, t in placed)
    hh = max(max(abs(t), abs(t + a.shape[0])) for a, l, t in placed)
    W = int(min(MAX_CANVAS, 2 * hw))
    H = int(min(MAX_CANVAS, 2 * hh))
    W, H = max(2, W + W % 2), max(2, H + H % 2)
    c = np.zeros((H, W, 4), np.float32)
    for arr, l, t in placed:
        _paste_over(c, arr, l + W // 2, t + H // 2)
    return c


def _section_layer(kind, paths, opts, plain):
    """One folder's picked image with its own options applied -> (premultiplied array, dx, dy) or None.
    Order: Outer extras (dupe / rotate / spread), Center rotate, colour + opacity, Size, then Center displace.
    `plain` skips everything except the Outer extras (used by the unmodified Outer / Center box previews)."""
    im = stack_images(paths)
    if im is None:
        return None
    o = norm_section(kind, opts)
    if kind == "outer":
        im = outer_transform(im, o)
    if plain:
        return im, 0, 0
    if kind == "center" and o["rotate"]:
        im = _rotate_pm(im, o["rotate"])        # about the image's own centre, before it is displaced
    rgba = _straight(im)
    rgba = recolor(rgba, o["color"], o["opacity"])
    pm = _premul(rgba)
    if o["size"]:
        # Size: grow / shrink the finished image by N px on its longer side (aspect kept), after everything
        # that rotates or spreads it, so those never get distorted by it
        from PIL import Image
        h, w = pm.shape[:2]
        big = max(h, w)
        f = max(2.0, big + o["size"]) / float(big)
        nw, nh = max(2, int(round(w * f))), max(2, int(round(h * f)))
        nw, nh = nw + nw % 2, nh + nh % 2           # even sides keep the layer exactly centred on the canvas
        pm = _resample_pm(pm, size=(nw, nh), filt=Image.LANCZOS if f < 1 else Image.BICUBIC)
    if o["stretch_x"] or o["stretch_y"]:
        # Stretch: the very last step on the folder's image (after Size, rotation, spread...), along the canvas
        # horizontal / vertical, in percent (-100 flattens it down to a hairline, +100 doubles it)
        from PIL import Image
        h, w = pm.shape[:2]
        nw = int(round(w * max(0.0, 1 + o["stretch_x"] / 100.0)))
        nh = int(round(h * max(0.0, 1 + o["stretch_y"] / 100.0)))
        nw, nh = min(max(2, nw), 2 * MAX_CANVAS), min(max(2, nh), 2 * MAX_CANVAS)
        nw, nh = nw + nw % 2, nh + nh % 2
        pm = _resample_pm(pm, size=(nw, nh), filt=Image.LANCZOS if nw * nh < w * h else Image.BICUBIC)
    dx = dy = 0
    if kind == "center":
        dx, dy = int(round(o["displace_x"])), int(round(o["displace_y"]))
    return pm, dx, dy


def compose(outer_paths, center_paths, overrides=None, plain=False):
    """Outer folders, then Center folders on top -> uint8 RGBA array (None when nothing is picked).
    Every folder is built on its own from ITS Section_configs.json (`overrides` {folder id: options} replaces a
    folder's file, used for live previews) and the results are layered around one common centre."""
    placed = []
    for kind, paths in (("outer", outer_paths), ("center", center_paths)):
        groups = {}
        for p in paths:
            groups.setdefault(rel_of(os.path.dirname(p)), []).append(p)
        for fid, ps in groups.items():
            opts = (overrides or {}).get(fid)
            lay = _section_layer(kind, ps, load_section_cfg(fid) if opts is None else opts, plain)
            if lay is not None:
                arr, dx, dy = lay
                ih, iw = arr.shape[:2]
                placed.append((arr, int(round(dx - iw / 2.0)), int(round(dy - ih / 2.0))))
    if not placed:
        return None
    hw = max(max(abs(l), abs(l + a.shape[1])) for a, l, t in placed)
    hh = max(max(abs(t), abs(t + a.shape[0])) for a, l, t in placed)
    W = int(min(MAX_CANVAS, 2 * hw))
    H = int(min(MAX_CANVAS, 2 * hh))
    W, H = max(2, W + W % 2), max(2, H + H % 2)
    cv = np.zeros((H, W, 4), np.float32)
    for arr, l, t in placed:
        _paste_over(cv, arr, l + W // 2, t + H // 2)
    return _straight(cv)


def recolor(rgba, color, opacity):
    """Pure white (and grey) parts become the colour; coloured parts get a proportional hue shift so
    their shading survives. Opacity (0-100) scales the alpha."""
    a = rgba.astype(np.float32) / 255.0
    r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    mx, mn = a[..., :3].max(-1), a[..., :3].min(-1)
    v = mx
    s = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-6), 0.0)
    tr, tg, tb = (c / 255.0 for c in color)
    th, ts, _tv = colorsys.rgb_to_hsv(tr, tg, tb)
    tmax = max(tr, tg, tb)
    out = np.zeros_like(a[..., :3])
    grey = s < 0.15
    # grey/white: v scales the colour, so pure white becomes exactly the colour
    gscale = v[..., None]
    out[:] = np.stack([tr, tg, tb])[None, None, :] * gscale
    # coloured: rotate hue by (target hue - dominant hue)
    col = ~grey & (al > 0)
    if col.any():
        d = mx - mn
        dd = np.where(d == 0, 1, d)
        h = np.where(mx == r, ((g - b) / dd) % 6, np.where(mx == g, (b - r) / dd + 2, (r - g) / dd + 4)) / 6.0
        wts = (s * al)[col]
        ang = h[col] * 2 * math.pi
        ref = math.atan2(float((np.sin(ang) * wts).sum()), float((np.cos(ang) * wts).sum())) / (2 * math.pi)
        if ts > 0.05:
            nh, ns, shade = (h + (th - ref)) % 1.0, s, 1.0
        else:
            nh, ns, shade = h, s * 0.0, (tmax if tmax > 0 else 1.0)
        i = np.floor(nh * 6).astype(int) % 6
        f = nh * 6 - np.floor(nh * 6)
        p, q, t = v * (1 - ns), v * (1 - f * ns), v * (1 - (1 - f) * ns)
        rr = np.choose(i, [v, q, p, p, t, v])
        gg = np.choose(i, [t, v, v, q, p, p])
        bb = np.choose(i, [p, p, t, v, v, q])
        out[col] = (np.stack([rr, gg, bb], -1) * shade)[col]
    res = np.empty_like(rgba)
    res[..., :3] = np.clip(np.rint(out * 255), 0, 255).astype(np.uint8)
    res[..., 3] = np.clip(np.rint(al * (clamp(opacity, 0, 100) / 100.0) * 255), 0, 255).astype(np.uint8)
    return res


def scale_min(rgba):
    """The smallest Scale Adjust (%) that still leaves the reticle at least 1 px on its short side."""
    m = max(1, min(rgba.shape[0], rgba.shape[1]))
    return min(0.0, math.ceil((-100.0 + 100.0 / m) * 10) / 10.0)


def outline_rgba(rgba, width=1.5, blur=3.0, opacity=70.0):
    """POST Outline: a soft black outline drawn *behind* the finished reticle (the reticle itself is untouched).
    width = thickness in px (fractions allowed), blur = strength (Gaussian sigma = blur / 2 px),
    opacity = 0-100. The canvas grows by the outline's reach so nothing is cut off."""
    width, blur, op = max(0.0, float(width)), max(0.0, float(blur)), clamp(float(opacity), 0, 100) / 100.0
    if (width <= 0 and blur <= 0) or op <= 0:
        return rgba
    sigma = blur / 2.0
    pad = int(np.ceil(width + 2.5 * sigma)) + 1
    pm = np.pad(_premul(rgba), ((pad, pad), (pad, pad), (0, 0)))
    a = pm[..., 3]
    # dilate the alpha by `width`: every offset inside the radius contributes with its coverage (soft edge)
    grown = a.copy()
    r = int(np.ceil(width + 0.5))
    h, w = a.shape
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            wgt = min(1.0, max(0.0, width + 0.5 - (dx * dx + dy * dy) ** 0.5))
            if wgt <= 0 or (dx == 0 and dy == 0):
                continue
            sh = np.zeros_like(a)
            sh[max(0, dy):h + min(0, dy), max(0, dx):w + min(0, dx)] = \
                a[max(0, -dy):h - max(0, dy), max(0, -dx):w - max(0, dx)] * wgt
            np.maximum(grown, sh, out=grown)
    if sigma > 0:
        grown = _blur_f(grown, sigma)
    ring = np.clip(grown, 0, 1) * op * (1.0 - a)        # only outside the reticle's own pixels
    out = pm.copy()
    out[..., 3] = a + ring                              # black underneath: premultiplied colour stays as it is
    return _straight(out)


def _blur_f(arr, sigma):
    """Gaussian blur of a float image (separable kernel, edge-zero)."""
    k = int(np.ceil(sigma * 3))
    x = np.arange(-k, k + 1, dtype=np.float32)
    g = np.exp(-(x * x) / (2 * sigma * sigma))
    g /= g.sum()
    p = np.pad(arr, k)
    t = sum(g[i] * p[:, i:i + arr.shape[1]] for i in range(2 * k + 1))
    return sum(g[i] * t[i:i + arr.shape[0], :] for i in range(2 * k + 1))


def scale_rgba(rgba, pct):
    """Resize around the image centre: +pct% bigger, -pct% smaller (0 leaves it alone)."""
    from PIL import Image
    h, w = rgba.shape[:2]
    f = 1.0 + max(float(pct), scale_min(rgba)) / 100.0
    nw, nh = max(1, int(round(w * f))), max(1, int(round(h * f)))
    if (nw, nh) == (w, h):
        return rgba
    return _straight(_resample_pm(_premul(rgba), size=(nw, nh), filt=Image.LANCZOS if f < 1 else Image.BICUBIC))




def write_current(rgba, scale=0):
    """Scale the finished reticle (every folder already has its own colour / opacity / extras / displace)
    and make it the only file in _Current."""
    from PIL import Image
    ensure_dirs()
    img = scale_rgba(rgba, scale)
    dst = os.path.join(CURRENT_DIR, CURRENT_FILE)
    tmp = os.path.join(CURRENT_DIR, "~tmp_" + CURRENT_FILE)
    Image.fromarray(img, "RGBA").save(tmp, "WEBP", lossless=True)
    for n in os.listdir(CURRENT_DIR):
        if n != os.path.basename(tmp) and is_image(n):
            try:
                os.remove(os.path.join(CURRENT_DIR, n))
            except OSError:
                pass
    os.replace(tmp, dst)
    return dst


# ---------------------------------------------------------------- presets
PRESET_FORMAT = "reticle-maker-preset"
_BAD = object()


def _p_bool(v):
    return v if isinstance(v, bool) else _BAD


def _p_num(lo, hi, integer=False):
    def f(v):
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            return _BAD
        v = clamp(v, lo, hi)
        return int(round(v)) if integer else float(v)
    return f


def _p_color(v):
    out = parse_rgb(v, None) if isinstance(v, (list, tuple, str)) else None
    return list(out) if out else _BAD


def _p_choice(choices):
    def f(v):
        return next((c for c in choices if isinstance(v, str) and c.lower() == v.lower()), _BAD)
    return f


def _p_key(v):
    if v == "":
        return ""
    vk = vk_of(v) if isinstance(v, str) else 0
    return VK_NAMES[vk] if vk else _BAD


def _p_overlay(v):
    if not isinstance(v, dict):
        return _BAD
    out = {k: _p_num(-2000, 2000)(v.get(k)) for k in ("x", "y")}
    out = {k: x for k, x in out.items() if x is not _BAD}
    return out or _BAD


def _p_selected(v):
    return v if isinstance(v, dict) else _BAD


# what a preset carries from reticle_config.json: marker settings, shortcuts, the global reticle options
PRESET_RULES = {
    "show_marker": _p_bool, "marker_color": _p_color, "marker_size": _p_num(1, 6, True),
    "inject_size": _p_num(INJECT_MIN, INJECT_MAX, True), "deviation_level": _p_num(0, 255, True),
    "persist_seconds": _p_num(0, 60), "wait_to_engage": _p_num(0, 5), "Mark_retry_delay": _p_num(0.03, 5),
    "calibration_hold_seconds": _p_num(0.2, 60), "overlay": _p_overlay,
    "mouse_key": _p_choice(MOUSE_CHOICES), "keyboard_key": _p_key, "keyboard_key_2": _p_key,
    "joystick_key": _p_choice(JOY_CHOICES), "ui_hotkey": _p_key,
    "hide_grid": _p_bool, "reticle_scale": _p_num(-99.9, 500), "override_color": _p_color,
    "override_enabled": _p_bool, "subtract_opacity": _p_num(0, 100, True), "post_outline": _p_bool,
    "outline_width": _p_num(0, 20), "outline_blur": _p_num(0, 30), "outline_opacity": _p_num(0, 100),
    "selected": _p_selected,
}


def build_preset(cfg):
    """Everything the UI is configured with, as one JSON-able dict. Machine specific values (the steam.exe path
    and the calibrated mark position) are not included."""
    sections = {}
    for kind in ("outer", "center"):
        for fid, _label, _files in kind_sections(kind):
            sections[fid] = norm_section(kind, load_section_cfg(fid))
    settings = {k: json.loads(json.dumps(cfg.get(k))) for k in PRESET_RULES if cfg.get(k) is not None}
    return {"format": PRESET_FORMAT, "version": 1, "settings": settings, "sections": sections}


def reset_all(cfg):
    """Start over: every folder's Section_configs.json and every preset setting back to its default.
    The steam.exe path and the calibrated mark position are kept. -> (folders reset, settings reset)."""
    n = 0
    for kind in ("outer", "center"):
        for fid, _l, _f in kind_sections(kind):
            save_section_cfg(fid, None)
            n += 1
    defaults = {k: json.loads(json.dumps(DEFAULT_CFG[k])) for k in PRESET_RULES if k in DEFAULT_CFG}
    cfg.set(**defaults)
    return n, len(defaults)


def apply_preset(data, cfg):
    """Apply a preset dict. Whatever is unknown, not found here or invalid is ignored.
    -> (folders applied, settings applied)."""
    if not isinstance(data, dict) or data.get("format") != PRESET_FORMAT:
        raise ValueError("not a Reticle Maker preset")
    known = {fid: kind for kind in ("outer", "center") for fid, _l, _f in kind_sections(kind)}
    secs = data.get("sections") if isinstance(data.get("sections"), dict) else {}
    n_sec = 0
    for fid, o in secs.items():
        fid = fid.replace("\\", "/") if isinstance(fid, str) else None
        if fid in known and isinstance(o, dict):
            save_section_cfg(fid, o)
            n_sec += 1
    setts = data.get("settings") if isinstance(data.get("settings"), dict) else {}
    good = {}
    for k, rule in PRESET_RULES.items():
        if k in setts:
            v = rule(setts[k])
            if v is not _BAD:
                good[k] = v
    if "overlay" in good:
        cur = cfg.get("overlay") if isinstance(cfg.get("overlay"), dict) else {}
        good["overlay"] = dict(cur, **good["overlay"])
    if "selected" in good:
        good["selected"] = prune_selected(good["selected"])     # picks whose files are not here are dropped
    if good:
        cfg.set(**good)
    return n_sec, len(good)


# ---------------------------------------------------------------- reticles that remember how they were made
META_FORMAT = "reticle-maker-reticle"
META_KEYS = ("reticle_scale", "override_enabled", "override_color", "subtract_opacity", "post_outline",
             "outline_width", "outline_blur", "outline_opacity")
META_TAG = "reticle_maker_config"            # PNG text chunk name; WebP keeps it inside an XMP packet
_XMP = ('<x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
        '<rdf:Description rdf:about="" xmlns:rm="urn:reticlemaker:1"><rm:config>%s</rm:config></rdf:Description>'
        '</rdf:RDF></x:xmpmeta>')


def build_reticle_meta(cfg, sel):
    """Only what shaped THIS reticle: the picked images, the options of the folders they come from and the global
    options that touch the final image. Nothing else of the UI."""
    picks = {k: [r for r in sel.get(k, [])] for k in ("outer", "center")}
    sections = {}
    for kind in ("outer", "center"):
        for rel in picks[kind]:
            fid = os.path.dirname(rel)
            sections[fid] = norm_section(kind, load_section_cfg(fid))
    glob = {k: json.loads(json.dumps(cfg.get(k))) for k in META_KEYS if cfg.get(k) is not None}
    return {"format": META_FORMAT, "version": 1, "selected": picks, "sections": sections, "global": glob}


def _meta_blob(meta):
    import base64
    return base64.b64encode(json.dumps(meta, separators=(",", ":")).encode("utf-8")).decode("ascii")


def read_reticle_meta(path):
    """The metadata dict stored in a .config.png / .config.webp, or None when the image has none."""
    import base64
    import re
    from PIL import Image
    try:
        with Image.open(path) as im:
            info = dict(im.info)
        blob = info.get(META_TAG)
        if blob is None and info.get("xmp"):
            m = re.search(rb"<rm:config>([A-Za-z0-9+/=]+)</rm:config>", info["xmp"])
            blob = m.group(1).decode("ascii") if m else None
        if not blob:
            return None
        data = json.loads(base64.b64decode(blob).decode("utf-8"))
    except Exception:
        return None
    return data if isinstance(data, dict) and data.get("format") == META_FORMAT else None


def apply_reticle_meta(meta, cfg):
    """Bring back the options of a saved reticle. Images or folders that are not here are ignored, and only the
    folders of the (still existing) picks are touched. -> the valid picks {kind: [paths]}.
    Raises ValueError when none of its images exist any more (nothing is changed then)."""
    sel = prune_selected(meta.get("selected") if isinstance(meta.get("selected"), dict) else {})
    if not (sel["outer"] or sel["center"]):
        raise ValueError("none of its images were found")
    secs = meta.get("sections") if isinstance(meta.get("sections"), dict) else {}
    for kind in ("outer", "center"):
        for rel in sel[kind]:
            fid = os.path.dirname(rel)
            if isinstance(secs.get(fid), dict):
                save_section_cfg(fid, secs[fid])
    good = {}
    g = meta.get("global") if isinstance(meta.get("global"), dict) else {}
    for k in META_KEYS:
        if k in g and k in PRESET_RULES:
            v = PRESET_RULES[k](g[k])
            if v is not _BAD:
                good[k] = v
    good["selected"] = sel
    cfg.set(**good)
    return sel


def save_preview(rgba, scale=0, meta=None):
    """Same image Apply makes, but kept as a new reticle straight inside _Outer (not in _Default or _Current),
    named <unix time><3 random letters>.config.webp, with `meta` (how it was built) stored inside the file."""
    from PIL import Image
    ensure_dirs()
    img = scale_rgba(rgba, scale)
    while True:
        name = "%d%s.config.webp" % (int(time.time()), "".join(random.choice("abcdefghijklmnopqrstuvwxyz") for _ in range(3)))
        dst = os.path.join(KIND_DIRS["outer"], name)
        if not os.path.exists(dst):
            break
    tmp = dst + ".tmp"
    kw = {"xmp": (_XMP % _meta_blob(meta)).encode("utf-8")} if meta else {}
    Image.fromarray(img, "RGBA").save(tmp, "WEBP", lossless=True, **kw)
    os.replace(tmp, dst)
    return dst


def load_current():
    """-> (premultiplied BGRA uint8 array, mtime) of the _Current reticle, or (None, None)."""
    name = current_name()
    if not name:
        return None, None
    p = os.path.join(CURRENT_DIR, name)
    try:
        a = load_rgba(p).astype(np.float32)
        al = a[..., 3:4] / 255.0
        bgr = a[..., 2::-1] * al
        return np.rint(np.concatenate([bgr, a[..., 3:4]], -1)).astype(np.uint8), (p, os.path.getmtime(p))
    except Exception as e:
        print("Could not read", p, "-", e)
        return None, None