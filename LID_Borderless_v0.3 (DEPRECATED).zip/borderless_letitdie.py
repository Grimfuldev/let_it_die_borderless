#!/usr/bin/env python3
import configparser
import ctypes
import math
import os
import json
import socket
import subprocess
import sys
import threading
import time
from ctypes import wintypes

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.dont_write_bytecode = True

APP_TITLE = "Let It Die Borderless"
VERSION = "v0.3"


def fatal(msg):
    try:
        ctypes.windll.user32.MessageBoxW(None, msg, APP_TITLE, 0x10)
    except Exception:
        print(msg)
    sys.exit(1)


try:
    import pygame
    import pywintypes
    import win32api
    import win32con
    import win32gui
    import win32process
    from PIL import Image
except ImportError as e:
    fatal(f"Missing dependency: {e.name}\n\nInstall with:\n"
          "pip install pywin32 pygame-ce pillow")

MIN_WINDOW_AREA = 100 * 100
POLL_MS = 1000
GUARD_MS = 250
REAPPLY_DELAY_MS = 1500
REAPPLY_TRIES = 6
MISS_LIMIT = 4
WAIT_POLL_MS = 3000
GWL_STYLE, GWL_EXSTYLE = -16, -20
ERROR_ACCESS_DENIED = 5
APP_ID = "Grimfuldev.LID.Borderless"

NATIVE = "native"
ASPECTS = {
    "Fill Screen (ignore aspect)": None,
    "16:9": 16 / 9,
    "16:10": 16 / 10,
    "4:3": 4 / 3,
    "21:9": 21 / 9,
    "32:9": 32 / 9,
    "Native size (centered)": NATIVE,
}

EX_EDGE_BITS = (
    win32con.WS_EX_DLGMODALFRAME | win32con.WS_EX_CLIENTEDGE
    | win32con.WS_EX_STATICEDGE | win32con.WS_EX_WINDOWEDGE
)

FROZEN = getattr(sys, "frozen", False)
SCRIPT_DIR = os.path.dirname(sys.executable if FROZEN else os.path.abspath(__file__))
RES_DIR = getattr(sys, "_MEIPASS", SCRIPT_DIR)
UI_ASSETS = os.path.join(RES_DIR, "UI_Assets")

BG_FILE = "UI background.webp"
GLASSES_FILE = "uncle glasses ready.webp"
CURSOR_FILE = "let it die cursor.webp"
ICO_FILE = "Lidico.ico"


def find_ui(name):
    for root in (UI_ASSETS, SCRIPT_DIR):
        p = os.path.join(root, name)
        if os.path.isfile(p):
            return p
    return ""


SETTINGS_FILE = os.path.join(SCRIPT_DIR, "borderless_settings.ini")
LOCK_FILE = os.path.join(SCRIPT_DIR, "borderless.lock")
STATE_FILE = os.path.join(SCRIPT_DIR, "borderless_state.json")
DEFAULT_ASPECT = next(iter(ASPECTS))
DEFAULT_HOTKEY = ""      # empty = no Hide UI shortcut until the user sets one
DEFAULT_AUTO_DELAY_SECONDS = 10


def load_settings():
    aspect, auto, hotkey, start_min, disable_sc = DEFAULT_ASPECT, False, DEFAULT_HOTKEY, False, False
    auto_delay_seconds = DEFAULT_AUTO_DELAY_SECONDS
    cp = configparser.ConfigParser()
    try:
        cp.read(SETTINGS_FILE, encoding="utf-8")
        if cp.has_section("borderless"):
            a = cp.get("borderless", "aspect", fallback=DEFAULT_ASPECT).strip()
            aspect = a if a in ASPECTS else DEFAULT_ASPECT
            auto = cp.getboolean("borderless", "auto_borderless", fallback=False)
            h = cp.get("borderless", "hotkey", fallback=None)
            hotkey = DEFAULT_HOTKEY if h is None else h.strip()      # an empty value means "no shortcut"
            start_min = cp.getboolean("borderless", "start_minimized", fallback=False)
            disable_sc = cp.getboolean("borderless", "disable_shortcut", fallback=False)
            auto_delay_seconds = cp.getint(
                "borderless", "auto_delay_seconds",
                fallback=DEFAULT_AUTO_DELAY_SECONDS)
            auto_delay_seconds = max(0, min(auto_delay_seconds, 3600))
    except (configparser.Error, ValueError, OSError):
        auto_delay_seconds = DEFAULT_AUTO_DELAY_SECONDS
    return aspect, auto, hotkey, start_min, disable_sc, auto_delay_seconds


def save_settings(aspect, auto, hotkey):
    cp = configparser.ConfigParser()
    try:
        cp.read(SETTINGS_FILE, encoding="utf-8")
    except (configparser.Error, OSError):
        pass
    if not cp.has_section("borderless"):
        cp.add_section("borderless")
    cp.set("borderless", "aspect", aspect)
    cp.set("borderless", "auto_borderless", "true" if auto else "false")
    cp.set("borderless", "hotkey", hotkey)
    if not cp.has_option("borderless", "start_minimized"):
        cp.set("borderless", "start_minimized", "false")
    if not cp.has_option("borderless", "disable_shortcut"):
        cp.set("borderless", "disable_shortcut", "false")
    if not cp.has_option("borderless", "auto_delay_seconds"):
        cp.set("borderless", "auto_delay_seconds", str(DEFAULT_AUTO_DELAY_SECONDS))
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            cp.write(f)
    except OSError:
        pass


_HOTKEY_ID = 0xB10
_HOTKEY_VK = None


def _vk_from_char(ch):
    if not ch:
        return 0xBB
    ch = ch[0]
    if ch == "=":
        return 0xBB
    if ch == "-":
        return 0xBD
    try:
        return ctypes.windll.user32.VkKeyScanW(ord(ch)) & 0xFF
    except Exception:
        return 0xBB


def _install_hook(vk):
    global _HOTKEY_VK
    try:
        ctypes.windll.user32.UnregisterHotKey(None, _HOTKEY_ID)
    except Exception:
        pass
    _HOTKEY_VK = vk
    try:
        ok = ctypes.windll.user32.RegisterHotKey(None, _HOTKEY_ID, 0, vk)
        if not ok:
            ctypes.windll.user32.RegisterHotKey(None, _HOTKEY_ID, 0x4000, vk)
    except Exception:
        pass


def _remove_main_hook():
    """The Hide UI shortcut was removed: stop listening for it."""
    global _HOTKEY_VK
    try:
        ctypes.windll.user32.UnregisterHotKey(None, _HOTKEY_ID)
    except Exception:
        pass
    _HOTKEY_VK = None


def _uninstall_hook():
    try:
        ctypes.windll.user32.UnregisterHotKey(None, _HOTKEY_ID)
        ctypes.windll.user32.UnregisterHotKey(None, _RET_HOTKEY_ID)
    except Exception:
        pass


_RET_HOTKEY_ID = 0xB11
_RET_HOTKEY_VK = None


def _install_ret_hook(vk):
    global _RET_HOTKEY_VK
    try:
        ctypes.windll.user32.UnregisterHotKey(None, _RET_HOTKEY_ID)
    except Exception:
        pass
    _RET_HOTKEY_VK = vk or None
    if vk:
        try:
            ok = ctypes.windll.user32.RegisterHotKey(None, _RET_HOTKEY_ID, 0, vk)
            if not ok:
                ctypes.windll.user32.RegisterHotKey(None, _RET_HOTKEY_ID, 0x4000, vk)
        except Exception:
            pass


def consume_hotkeys():
    """The ids of the hotkeys pressed since the last call."""
    ids = set()
    try:
        user32 = ctypes.windll.user32
        msg = wintypes.MSG()
        while user32.PeekMessageW(ctypes.byref(msg), None, 0x0312, 0x0312, 1):
            ids.add(int(msg.wParam))
    except Exception:
        pass
    return ids


def write_lock():
    try:
        with open(LOCK_FILE, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
    except OSError:
        pass


def clear_lock():
    try:
        if os.path.isfile(LOCK_FILE):
            os.remove(LOCK_FILE)
    except OSError:
        pass


def pid_alive(pid):
    if pid <= 0:
        return False
    try:
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
        if h:
            ctypes.windll.kernel32.CloseHandle(h)
            return True
    except Exception:
        pass
    return False


def clear_stale_lock():
    if not os.path.isfile(LOCK_FILE):
        return
    try:
        raw = open(LOCK_FILE, "r", encoding="utf-8").read().strip()
        old = int(raw or "0")
        if not pid_alive(old):
            os.remove(LOCK_FILE)
    except Exception:
        try:
            os.remove(LOCK_FILE)
        except Exception:
            pass


def _read_lock_pid():
    try:
        with open(LOCK_FILE, "r", encoding="utf-8") as f:
            return int((f.read() or "0").strip())
    except (OSError, ValueError):
        return 0


def _image_name(pid):
    """File name of the program a process runs ('' when unknown)."""
    try:
        k = ctypes.windll.kernel32
        k.OpenProcess.restype = ctypes.c_void_p
        h = k.OpenProcess(0x1000, False, pid)
        if not h:
            return ""
        try:
            buf = ctypes.create_unicode_buffer(1024)
            n = wintypes.DWORD(1024)
            k.QueryFullProcessImageNameW.argtypes = [ctypes.c_void_p, wintypes.DWORD, wintypes.LPWSTR,
                                                     ctypes.POINTER(wintypes.DWORD)]
            if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                return os.path.basename(buf.value).lower()
        finally:
            k.CloseHandle(ctypes.c_void_p(h))
    except Exception:
        pass
    return ""


def _kill_tree(pid):
    """End a process and everything it started (its Reticle window included). True when it is gone."""
    try:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                       timeout=10)
    except Exception:
        pass
    end = time.time() + 5.0
    while time.time() < end:
        if not pid_alive(pid):
            return True
        time.sleep(0.05)
    return not pid_alive(pid)


def take_over_previous():
    """Only one copy of the program runs at a time: starting it again closes the copy that is already running
    (with its Reticle window) and this one takes over. Returns False when this copy should not go on."""
    me = os.getpid()
    mine = os.path.basename(sys.executable).lower()
    for _ in range(6):
        old = _read_lock_pid()
        if old and old != me and pid_alive(old) and _image_name(old) == mine:
            if not _kill_tree(old):
                # most likely the running copy has Administrator rights and this one does not
                if not is_admin() and relaunch_as_admin():
                    return False
                fatal("Another copy of this program is already running and could not be closed.\n\n"
                      "Close it first (it may be running as Administrator).")
        # a copy that was started at the same moment may not have written its lock yet: look once more
        time.sleep(0.15)
        again = _read_lock_pid()
        if not again or again == me or not pid_alive(again) or _image_name(again) != mine:
            return True
    return True


def enable_dpi_awareness():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def ui_scale():
    try:
        return min(3.0, max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96))
    except Exception:
        return 1.0


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin():
    args = sys.argv[1:] if FROZEN else sys.argv
    params = " ".join(f'"{a}"' for a in args) or None
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)
    return int(ret) > 32


def to_signed32(v):
    v &= 0xFFFFFFFF
    return v - 0x100000000 if v & 0x80000000 else v


def find_game_pids():
    pids = set()
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq BrgGame-Steam.exe", "/FO", "CSV", "/NH"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stderr=subprocess.DEVNULL,
            text=True,
            errors="ignore",
        )
    except Exception:
        return pids
    for line in out.splitlines():
        line = line.strip()
        if not line or "brggame" not in line.lower():
            continue
        parts = [p.strip().strip('"') for p in line.split(",")]
        if len(parts) >= 2 and parts[1].isdigit():
            pids.add(int(parts[1]))
    return pids


def find_game_window():
    game_pids = find_game_pids()
    if not game_pids:
        return None
    best = [0, None]

    def visit(hwnd, _):
        if not win32gui.IsWindowVisible(hwnd):
            return True
        try:
            pid = win32process.GetWindowThreadProcessId(hwnd)[1]
            if pid not in game_pids:
                return True
            l, t, r, b = win32gui.GetWindowRect(hwnd)
        except pywintypes.error:
            return True
        area = (r - l) * (b - t)
        if area > MIN_WINDOW_AREA and area > best[0]:
            best[0], best[1] = area, hwnd
        return True

    win32gui.EnumWindows(visit, None)
    return best[1]


def monitor_rect(hwnd):
    try:
        mon = win32api.MonitorFromWindow(hwnd, win32con.MONITOR_DEFAULTTONEAREST)
        return win32api.GetMonitorInfo(mon)["Monitor"]
    except pywintypes.error:
        return 0, 0, win32api.GetSystemMetrics(0), win32api.GetSystemMetrics(1)


def client_size(hwnd):
    l, t, r, b = win32gui.GetClientRect(hwnd)
    return r - l, b - t


def load_image(path):
    im = Image.open(path).convert("RGBA")
    return pygame.image.frombuffer(im.tobytes(), im.size, "RGBA").convert_alpha()


def load_background(path, w, h):
    im = Image.open(path).convert("RGB")
    k = max(w / im.width, h / im.height)
    nw, nh = round(im.width * k), round(im.height * k)
    im = im.resize((nw, nh), Image.Resampling.LANCZOS)
    left, top = (nw - w) // 2, (nh - h) // 2
    im = im.crop((left, top, left + w, top + h))
    return pygame.image.frombuffer(im.tobytes(), im.size, "RGB").convert()


def scaled(surf, size):
    if size == surf.get_width():
        return surf
    fn = pygame.transform.scale if size % surf.get_width() == 0 else pygame.transform.smoothscale
    return fn(surf, (size, size))


def wrap_text(font, text, width):
    lines = []
    for para in text.split("\n"):
        cur = ""
        for word in para.split(" "):
            trial = f"{cur} {word}".strip()
            if font.size(trial)[0] <= width:
                cur = trial
                continue
            if cur:
                lines.append(cur)
            while font.size(word)[0] > width and len(word) > 1:
                n = len(word)
                while n > 1 and font.size(word[:n])[0] > width:
                    n -= 1
                lines.append(word[:n])
                word = word[n:]
            cur = word
        lines.append(cur)
    return lines


C_TEXT = (224, 224, 228)
C_DIM = (146, 146, 154)
C_FAINT = (92, 92, 100)
C_LINE = (62, 62, 70)
C_BTN = (40, 40, 46)
C_BTN_HOT = (56, 56, 64)
C_BTN_DOWN = (28, 28, 32)
C_BTN_OFF = (24, 24, 28)
C_BORDER = (98, 98, 106)
C_BORDER_HOT = (176, 176, 184)
C_BORDER_OFF = (50, 50, 56)

WIN_W, WIN_H = 440, 322


class App:
    def __init__(self):
        pygame.display.init()
        pygame.font.init()
        self.S = ui_scale()
        s = self.s
        (aspect, self.auto, self.hotkey, self.start_minimized,
         self.disable_shortcut, self.auto_delay_seconds) = load_settings()
        self.auto_delay_ms = self.auto_delay_seconds * 1000
        if not self.hotkey or self.disable_shortcut:
            self.start_minimized = False       # nothing could bring a hidden window back
        flags = 0
        if self.start_minimized and hasattr(pygame, "HIDDEN"):
            flags |= pygame.HIDDEN
        self.screen = pygame.display.set_mode((s(WIN_W), s(WIN_H)), flags)
        pygame.display.set_caption(f"{APP_TITLE} {VERSION}")
        self._win_hwnd = pygame.display.get_wm_info().get("window")
        if self.start_minimized and self._win_hwnd:
            try:
                win32gui.ShowWindow(self._win_hwnd, win32con.SW_HIDE)
            except Exception:
                pass

        self.running = True
        self.hwnd = None
        self.is_borderless = False
        self._saved = None
        self._applied = None
        self.keep_borderless = False
        self.reapply_deadline = None
        self._reapply_tries = 0
        self._misses = 0
        self.status = "Looking for the game..."
        self.notice, self.notice_until = "", 0.0
        self.options = list(ASPECTS)
        self.aspect_idx = self.options.index(aspect)
        self.auto_deadline = None
        self._prev_found = None
        self.game_seen = False
        self.ui_visible = not self.start_minimized
        self.capturing_hotkey = False
        self.reticle_proc = None
        self.reticle_port = 0
        self._ret_vk = 0
        self._next_hk_sync = 0
        if not os.path.isfile(SETTINGS_FILE):
            self.save()
        self.dd_open = False
        self.pressed = None
        self.modal = None
        self._next_poll = 0

        names = "segoeui,arial"
        self.f_body = pygame.font.SysFont(names, s(13))
        self.f_btn = pygame.font.SysFont(names, s(13), bold=True)
        self.f_small = pygame.font.SysFont(names, s(11))

        self.r_status = pygame.Rect(s(16), s(16), s(408), s(58))
        self.r_dd = pygame.Rect(s(16), s(110), s(408), s(30))
        self.r_make = pygame.Rect(s(16), s(158), s(196), s(38))
        self.r_stop = pygame.Rect(s(228), s(158), s(196), s(38))
        self.r_auto = pygame.Rect(s(16), s(212), s(160), s(24))
        self.r_hotkey = pygame.Rect(s(190), s(212), s(234), s(24))
        self.r_reticle = pygame.Rect(s(16), s(254), s(408), s(38))
        self.item_h = s(24)
        self.r_list = pygame.Rect(self.r_dd.x, self.r_dd.bottom + s(2),
                                  self.r_dd.w, self.item_h * len(self.options) + s(2))

        self.bg = None
        self.glasses = None
        p = find_ui(BG_FILE)
        if p:
            try:
                self.bg = load_background(p, *self.screen.get_size())
            except Exception:
                pass
        p = find_ui(GLASSES_FILE)
        if p:
            try:
                self.glasses = load_image(p)
            except Exception:
                pass
        self.panel = pygame.Surface(self.r_status.size, pygame.SRCALPHA)
        self.panel.fill((0, 0, 0, 120))
        self.dim = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        self.dim.fill((0, 0, 0, 170))

        self._chrome()
        self._win_hwnd = pygame.display.get_wm_info().get("window")
        if not self.disable_shortcut and self.hotkey:
            _install_hook(_vk_from_char(self.hotkey))
        if self.start_minimized:
            self._hide_ui()
        if reticle_wanted():
            self.spawn_reticle("hidden")
        threading.Thread(target=self._auto_unlock, daemon=True).start()

    def s(self, v):
        return int(round(v * self.S))

    def _chrome(self):
        if self.glasses:
            try:
                pygame.display.set_icon(self.glasses)
            except Exception:
                pass
        try:
            hwnd = pygame.display.get_wm_info().get("window")
            if hwnd:
                user32 = ctypes.windll.user32
                ico = find_ui(ICO_FILE)
                if ico:
                    hicon = user32.LoadImageW(None, ico, 1, 0, 0, 0x0010 | 0x0040)
                    if hicon:
                        user32.SendMessageW(hwnd, 0x0080, 1, hicon)
                black, dark = ctypes.c_int(0), ctypes.c_int(1)
                dwm = ctypes.windll.dwmapi
                dwm.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(dark), 4)
                dwm.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(black), 4)
                dwm.DwmSetWindowAttribute(hwnd, 34, ctypes.byref(black), 4)
        except Exception:
            pass
        p = find_ui(CURSOR_FILE)
        if p:
            try:
                pygame.mouse.set_cursor((0, 0), scaled(load_image(p), self.s(32)))
            except Exception:
                pass

    def _now(self):
        return pygame.time.get_ticks()

    def save(self):
        save_settings(self.options[self.aspect_idx], self.auto, self.hotkey)

    def _hide_ui(self):
        if not self._win_hwnd:
            return
        try:
            win32gui.ShowWindow(self._win_hwnd, win32con.SW_HIDE)
        except Exception:
            pass
        self.ui_visible = False

    def _show_ui(self):
        if not self._win_hwnd:
            return
        try:
            win32gui.ShowWindow(self._win_hwnd, win32con.SW_SHOW)
            win32gui.SetForegroundWindow(self._win_hwnd)
        except Exception:
            pass
        self.ui_visible = True

    def toggle_ui(self):
        if self.ui_visible:
            self._hide_ui()
        else:
            self._show_ui()

    def set_hotkey(self, ch):
        if not ch or len(ch) != 1:
            return
        self.hotkey = ch
        self.save()
        if not self.disable_shortcut:
            _install_hook(_vk_from_char(ch))

    def _begin_hotkey_capture(self):
        """While a new key is being picked no shortcut may be listening: a registered hotkey swallows its key (the
        window would never see it) and would hide the program when the same key is pressed."""
        self.capturing_hotkey = True
        _remove_main_hook()
        _install_ret_hook(0)

    def _end_hotkey_capture(self):
        self.capturing_hotkey = False
        self._next_hk_sync = 0                  # the Reticle shortcut is registered again on the next sync
        if not self.disable_shortcut and self.hotkey:
            _install_hook(_vk_from_char(self.hotkey))

    def _auto_unlock(self):
        """Once per start: the optional "auto_unlock_sha_mark" setting of reticle_config.json (off by default)."""
        try:
            import reticle_maker
            msg = reticle_maker.auto_unlock_sha()
        except Exception as e:
            msg = f"Auto unlock SHA failed: {e}"
        if msg:
            self.notice_until = time.time() + 30       # stays visible a while: the status line changes every 3 s
            self.notice = msg

    def clear_hotkey(self):
        """Right click on the shortcut label removes the Hide UI shortcut."""
        self.hotkey = ""
        self.capturing_hotkey = False
        self.save()
        _remove_main_hook()

    # ---- Reticle Maker (its own window, run as a second process of this program)
    def reticle_alive(self):
        return self.reticle_proc is not None and self.reticle_proc.poll() is None

    def spawn_reticle(self, mode):
        if self.reticle_alive():
            return True
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as t:
                t.bind(("127.0.0.1", 0))
                self.reticle_port = t.getsockname()[1]
            args = ["--reticle-ui", str(os.getpid()), str(self.reticle_port), mode]
            env = dict(os.environ)
            if FROZEN:
                cmd = [sys.executable] + args
                env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
            else:
                exe = sys.executable
                pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
                cmd = [pyw if os.path.isfile(pyw) else exe, os.path.abspath(__file__)] + args
            self.reticle_proc = subprocess.Popen(cmd, cwd=SCRIPT_DIR, env=env, creationflags=0x08000000)
            return True
        except Exception as e:
            self.status = f"Could not start the Reticle window: {e}"
            self.reticle_proc = None
            return False

    def send_reticle(self, cmd):
        if not self.reticle_alive() or not self.reticle_port:
            return
        try:
            ctypes.windll.user32.AllowSetForegroundWindow(-1)
        except Exception:
            pass
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as t:
                t.sendto(cmd.encode(), ("127.0.0.1", self.reticle_port))
        except OSError:
            pass

    def open_reticle(self):
        if self.reticle_alive():
            self.send_reticle("show")
        else:
            try:
                ctypes.windll.user32.AllowSetForegroundWindow(-1)
            except Exception:
                pass
            self.spawn_reticle("show")

    def shutdown_reticle(self):
        if self.reticle_alive():
            self.send_reticle("quit")
            try:
                self.reticle_proc.wait(2.0)
            except Exception:
                pass
            if self.reticle_alive():
                try:
                    self.reticle_proc.terminate()
                except Exception:
                    pass

    def sync_reticle_hotkey(self):
        """The Reticle window's show/hide key lives in reticle_config.json; this program listens for it."""
        now = self._now()
        if now < self._next_hk_sync:
            return
        self._next_hk_sync = now + 1000
        vk = reticle_hotkey_vk()
        if vk and vk == _HOTKEY_VK and not self.disable_shortcut:
            vk_reg = 0
        else:
            vk_reg = vk
        if vk != self._ret_vk or vk_reg != (_RET_HOTKEY_VK or 0):
            self._ret_vk = vk
            _install_ret_hook(vk_reg)

    def on_main_hotkey(self):
        if self._ret_vk and self._ret_vk == _HOTKEY_VK:
            if self.ui_visible:
                self._hide_ui()
                self.send_reticle("hide_keep")
            else:
                self._show_ui()
                self.send_reticle("restore")
        else:
            self.toggle_ui()

    def _already_borderless(self):
        """The game window has no frame and already sits where the chosen aspect would put it (for example a
        previous run of this tool made it borderless). Nothing is changed in that case."""
        try:
            if not self._window_alive() or win32gui.IsIconic(self.hwnd):
                return False
            if win32gui.GetWindowLong(self.hwnd, GWL_STYLE) & (win32con.WS_CAPTION | win32con.WS_THICKFRAME):
                return False
            x, y, w, h = self.target_rect(client_size(self.hwnd))
            return all(abs(a - b) <= 2 for a, b in zip(win32gui.GetWindowRect(self.hwnd), (x, y, x + w, y + h)))
        except pywintypes.error:
            return False

    def _window_pid(self):
        try:
            return win32process.GetWindowThreadProcessId(self.hwnd)[1]
        except pywintypes.error:
            return 0

    def _save_state(self):
        """Remember the original window style so Stop Borderless still works after this program is restarted."""
        if not self._saved:
            return
        style, exstyle, (l, t, r, b) = self._saved
        try:
            with open(STATE_FILE, "w", encoding="utf-8") as f:
                json.dump({"hwnd": int(self.hwnd), "pid": self._window_pid(),
                           "saved": [style, exstyle, l, t, r, b]}, f)
        except OSError:
            pass

    def _clear_state(self):
        try:
            os.remove(STATE_FILE)
        except OSError:
            pass

    def _restore_info(self):
        """(style, exstyle, rect) to restore a window this run did not change: the one saved by an earlier run
        for this very window, otherwise an ordinary framed window of the same client size, centred."""
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
            if d.get("hwnd") == int(self.hwnd) and d.get("pid") == self._window_pid():
                st, ex, l, t, r, b = (int(v) for v in d["saved"])
                return to_signed32(st), to_signed32(ex), (l, t, r, b)
        except (OSError, ValueError, KeyError, TypeError):
            pass
        style = win32con.WS_OVERLAPPEDWINDOW | win32con.WS_VISIBLE
        exstyle = win32gui.GetWindowLong(self.hwnd, GWL_EXSTYLE) | win32con.WS_EX_WINDOWEDGE
        ml, mt, mr, mb = monitor_rect(self.hwnd)
        mw, mh = mr - ml, mb - mt
        cw, ch = client_size(self.hwnd)
        k = min(1.0, 0.85 * mw / max(1, cw), 0.85 * mh / max(1, ch))
        cw, ch = int(cw * k), int(ch * k)
        rc = wintypes.RECT(0, 0, cw, ch)
        ctypes.windll.user32.AdjustWindowRectEx(ctypes.byref(rc), style & 0xFFFFFFFF, False, exstyle & 0xFFFFFFFF)
        l, t, r, b = rc.left, rc.top, rc.right, rc.bottom
        w, h = r - l, b - t
        x, y = ml + (mw - w) // 2, mt + (mh - h) // 2
        return to_signed32(style), to_signed32(exstyle), (x, y, x + w, y + h)

    def _adopt_if_borderless(self):
        """The game window is already borderless (e.g. made so by a previous run): take it over as is, so the
        buttons show the real state and Stop Borderless can put it back. Returns True when adopted."""
        if self.is_borderless or not self._already_borderless():
            return False
        try:
            self._saved = self._restore_info()
            self._applied = tuple(win32gui.GetWindowRect(self.hwnd))
            l, t, r, b = self._applied
            self._applied = (l, t, r - l, b - t)
            self.keep_borderless = True
            self.is_borderless = True
            self.auto_deadline = None
            self.status = (self.status + "\n" if self.status else "") + "Already borderless, left as it is."
            return True
        except pywintypes.error:
            return False

    def can_make(self):
        return bool(self.hwnd) and not self.is_borderless and self.auto_deadline is None

    def _window_alive(self):
        return bool(self.hwnd) and win32gui.IsWindow(self.hwnd)

    def set_auto(self, on):
        if on == self.auto:
            return
        self.auto = on
        self.auto_deadline = None
        if on and self.hwnd and not self.is_borderless and not self._adopt_if_borderless():
            self.auto_deadline = self._now() + self.auto_delay_ms
        self.save()

    def tick(self):
        now = self._now()
        if now >= self._next_poll:
            self.poll()
            if self.is_borderless:
                interval = GUARD_MS
            else:
                interval = POLL_MS if (self.hwnd or self.game_seen) else WAIT_POLL_MS
            self._next_poll = now + interval
        if self.reapply_deadline is not None and now >= self.reapply_deadline:
            self.reapply_deadline = None
            if self.keep_borderless and not self.is_borderless and not self.modal:
                self.hwnd = find_game_window() or self.hwnd
                if self._window_alive():
                    self.make_borderless(quiet=True)
                if not self.is_borderless and self._reapply_tries < REAPPLY_TRIES:
                    self._reapply_tries += 1
                    self.reapply_deadline = now + REAPPLY_DELAY_MS
        if self.auto_deadline is not None and now >= self.auto_deadline:
            self.auto_deadline = None
            if self.auto and not self.is_borderless and not self.modal:
                self.hwnd = find_game_window() or self.hwnd
                if self._window_alive() and not self._adopt_if_borderless():
                    self.make_borderless()

    def poll(self):
        try:
            if not self._window_alive():
                was_active = self.is_borderless or self.keep_borderless
                self.hwnd = None
                self.is_borderless = False
                self._saved = None
                self._applied = None
                self.hwnd = find_game_window()
                if self.hwnd:
                    self._misses = 0
                    self.game_seen = True
                    title = win32gui.GetWindowText(self.hwnd) or "Let It Die"
                    w, h = client_size(self.hwnd)
                    self.status = f"Found: {title}\nClient size: {w}x{h}"
                    if was_active:
                        self._reapply_tries = 0
                        self.reapply_deadline = self._now() + REAPPLY_DELAY_MS
                        self.status += "\nWindow was recreated: applying borderless again..."
                elif self.game_seen:
                    self._misses += 1
                    if self._misses >= MISS_LIMIT:
                        self.running = False
                        return
                elif was_active:
                    self.status = "Game closed. Start it again and click Make Borderless."
                else:
                    self.status = "Waiting for the game... (checking every 3s)"

            elif self.is_borderless:
                self._guard()

            found = bool(self.hwnd)
            if not found:
                self.auto_deadline = None
            elif self._prev_found is not True and self._adopt_if_borderless():
                pass
            elif (self.auto and not self.is_borderless and self.auto_deadline is None
                  and self._prev_found is not True):
                self.auto_deadline = self._now() + self.auto_delay_ms
            self._prev_found = found
        except Exception as e:
            self.status = f"Error while looking for the game: {e}"

    def _guard(self):
        hwnd = self.hwnd
        try:
            if win32gui.IsIconic(hwnd) or not self._applied:
                return
            style = win32gui.GetWindowLong(hwnd, GWL_STYLE)
            rect = win32gui.GetWindowRect(hwnd)
            x, y, w, h = self._applied
            moved = any(abs(a - b) > 2 for a, b in zip(rect, (x, y, x + w, y + h)))
            framed = bool(style & (win32con.WS_CAPTION | win32con.WS_THICKFRAME))
            if moved or framed:
                self.make_borderless(quiet=True, keep_saved=True, size=(w, h))
        except pywintypes.error:
            pass

    def target_rect(self, native_size):
        l, t, r, b = monitor_rect(self.hwnd)
        mw, mh = r - l, b - t
        ratio = ASPECTS[self.options[self.aspect_idx]]

        if ratio is None:
            return l, t, mw, mh
        if ratio == NATIVE:
            w, h = min(native_size[0], mw), min(native_size[1], mh)
        elif mw / mh > ratio:
            h = mh
            w = int(h * ratio)
        else:
            w = mw
            h = int(w / ratio)
        return l + (mw - w) // 2, t + (mh - h) // 2, w, h

    def make_borderless(self, quiet=False, keep_saved=False, size=None):
        if not self._window_alive():
            self.hwnd = find_game_window()
            if not self.hwnd:
                if not quiet:
                    self.show_modal("Could not find the Let It Die window.", [("OK", None)])
                return
        hwnd = self.hwnd
        try:
            if win32gui.IsIconic(hwnd) or win32gui.GetWindowPlacement(hwnd)[1] == win32con.SW_SHOWMAXIMIZED:
                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)

            style = win32gui.GetWindowLong(hwnd, GWL_STYLE)
            exstyle = win32gui.GetWindowLong(hwnd, GWL_EXSTYLE)
            rect = win32gui.GetWindowRect(hwnd)
            x, y, w, h = self.target_rect(size or client_size(hwnd))

            win32gui.SetWindowLong(hwnd, GWL_STYLE, to_signed32(win32con.WS_MAXIMIZE))
            win32gui.SetWindowLong(hwnd, GWL_EXSTYLE, to_signed32(exstyle & ~EX_EDGE_BITS))
            win32gui.SetWindowPos(hwnd, 0, x, y, w, h,
                                  win32con.SWP_SHOWWINDOW | win32con.SWP_FRAMECHANGED)

            if not (keep_saved and self._saved):
                self._saved = (style, exstyle, rect)
                self._save_state()
            self._applied = (x, y, w, h)
            self.keep_borderless = True
            self.is_borderless = True
            self.status = f"Borderless active: {w}x{h} at ({x},{y})"
        except pywintypes.error as e:
            if quiet:
                self.status = f"Could not re-apply borderless: {e}"
                return
            if e.winerror == ERROR_ACCESS_DENIED and not is_admin():
                self.show_modal(
                    "The game window can't be modified from a normal account.\n\n"
                    "Restart this tool as Administrator?",
                    [("Restart as Admin", self._restart_admin), ("Cancel", None)])
                return
            self.show_modal(f"Failed to apply borderless:\n{e}", [("OK", None)])
        except Exception as e:
            if quiet:
                self.status = f"Could not re-apply borderless: {e}"
                return
            self.show_modal(f"Failed to apply borderless:\n{e}", [("OK", None)])

    def stop_borderless(self):
        self.is_borderless = False
        self.keep_borderless = False
        self.reapply_deadline = None
        self._applied = None
        self.set_auto(False)
        try:
            if self._window_alive() and self._saved:
                style, exstyle, (l, t, r, b) = self._saved
                win32gui.SetWindowLong(self.hwnd, GWL_STYLE, style)
                win32gui.SetWindowLong(self.hwnd, GWL_EXSTYLE, exstyle)
                win32gui.SetWindowPos(self.hwnd, 0, l, t, r - l, b - t,
                                      win32con.SWP_SHOWWINDOW | win32con.SWP_FRAMECHANGED)
                self.status = "Restored original window."
                self._clear_state()
        except Exception as e:
            self.show_modal(f"Failed to restore:\n{e}", [("OK", None)])
        self._saved = None

    def _restart_admin(self):
        if relaunch_as_admin():
            self.running = False
        else:
            self.status = "Administrator restart was cancelled."

    def show_modal(self, text, buttons):
        s = self.s
        box_w = s(372)
        lines = wrap_text(self.f_body, text, box_w - s(40))
        lh = self.f_body.get_linesize()
        btn_h, btn_w, gap = s(32), s(148), s(12)
        box_h = s(20) + lh * len(lines) + s(20) + btn_h + s(20)
        box = pygame.Rect(0, 0, box_w, box_h)
        box.center = self.screen.get_rect().center
        total = len(buttons) * btn_w + (len(buttons) - 1) * gap
        x0 = box.centerx - total // 2
        rects = [pygame.Rect(x0 + i * (btn_w + gap), box.bottom - s(20) - btn_h, btn_w, btn_h)
                 for i in range(len(buttons))]
        self.modal = {"lines": lines, "buttons": buttons, "box": box, "rects": rects}
        self.dd_open = False
        self.pressed = None

    def _modal_pick(self, i):
        cb = self.modal["buttons"][i][1]
        self.modal = None
        if cb:
            cb()

    def handle(self, ev):
        t = ev.type
        if t == pygame.QUIT:
            self.running = False
        elif t == pygame.KEYDOWN:
            if self.capturing_hotkey:
                if ev.unicode and len(ev.unicode) == 1 and ev.unicode.isprintable():
                    self.set_hotkey(ev.unicode)
                self._end_hotkey_capture()
                return
            if self.modal:
                if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self._modal_pick(0)
                elif ev.key == pygame.K_ESCAPE:
                    self._modal_pick(len(self.modal["buttons"]) - 1)
            elif ev.key == pygame.K_ESCAPE:
                self.dd_open = False
        elif t == pygame.MOUSEBUTTONDOWN and ev.button == 3:
            if not self.modal and not self.dd_open and self.r_hotkey.collidepoint(ev.pos):
                self.clear_hotkey()
        elif t == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            self._mouse_down(ev.pos)
        elif t == pygame.MOUSEBUTTONUP and ev.button == 1:
            self._mouse_up(ev.pos)

    def _mouse_down(self, pos):
        if self.modal:
            for i, r in enumerate(self.modal["rects"]):
                if r.collidepoint(pos):
                    self.pressed = ("modal", i)
            return
        if self.dd_open:
            if self.r_list.collidepoint(pos):
                i = (pos[1] - self.r_list.y - self.s(1)) // self.item_h
                if 0 <= i < len(self.options) and i != self.aspect_idx:
                    self.aspect_idx = i
                    self.save()
            self.dd_open = False
            return
        if self.r_dd.collidepoint(pos):
            self.dd_open = True
        elif self.r_auto.collidepoint(pos):
            self.set_auto(not self.auto)
        elif self.r_hotkey.collidepoint(pos):
            self._begin_hotkey_capture()
        elif self.r_reticle.collidepoint(pos):
            self.pressed = "reticle"
        elif self.r_make.collidepoint(pos) and self.can_make():
            self.pressed = "make"
        elif self.r_stop.collidepoint(pos) and self.is_borderless:
            self.pressed = "stop"

    def _mouse_up(self, pos):
        p, self.pressed = self.pressed, None
        if p is None:
            return
        if isinstance(p, tuple):
            if self.modal and self.modal["rects"][p[1]].collidepoint(pos):
                self._modal_pick(p[1])
        elif p == "make" and self.r_make.collidepoint(pos) and self.can_make():
            self.make_borderless()
        elif p == "stop" and self.r_stop.collidepoint(pos) and self.is_borderless:
            self.stop_borderless()
        elif p == "reticle" and self.r_reticle.collidepoint(pos):
            self.open_reticle()

    def _text(self, font, txt, color, x, y, center=False):
        img = font.render(txt, True, color)
        self.screen.blit(img, (x - img.get_width() // 2 if center else x, y))

    def _button(self, key, rect, label, enabled, mouse):
        if not enabled:
            fill, border, fg = C_BTN_OFF, C_BORDER_OFF, C_FAINT
        elif self.pressed == key and rect.collidepoint(mouse):
            fill, border, fg = C_BTN_DOWN, C_BORDER_HOT, C_TEXT
        elif rect.collidepoint(mouse):
            fill, border, fg = C_BTN_HOT, C_BORDER_HOT, C_TEXT
        else:
            fill, border, fg = C_BTN, C_BORDER, C_TEXT
        pygame.draw.rect(self.screen, fill, rect, border_radius=self.s(3))
        pygame.draw.rect(self.screen, border, rect, 1, border_radius=self.s(3))
        img = self.f_btn.render(label, True, fg)
        self.screen.blit(img, img.get_rect(center=rect.center))

    def draw(self):
        s, scr = self.s, self.screen
        mouse = pygame.mouse.get_pos() if pygame.mouse.get_focused() else (-1, -1)
        if self.modal:
            mouse_ui = (-1, -1)
        else:
            mouse_ui = mouse

        if self.bg:
            scr.blit(self.bg, (0, 0))
        else:
            scr.fill((18, 18, 22))

        scr.blit(self.panel, self.r_status)
        pygame.draw.rect(scr, C_LINE, self.r_status, 1, border_radius=s(3))
        lines = []
        status = self.status
        if self.notice and time.time() < self.notice_until:
            status = self.notice + "\n" + status
        if self.auto_deadline is not None:
            left = max(1, math.ceil((self.auto_deadline - self._now()) / 1000))
            status = status.split("\n")[0] + f"\nAuto Borderless: applying in {left}s..."
        for para in status.split("\n"):
            lines += wrap_text(self.f_body, para, self.r_status.w - s(20))
        lh = self.f_body.get_linesize()
        y = self.r_status.centery - lh * len(lines) // 2
        for ln in lines:
            self._text(self.f_body, ln, C_TEXT, self.r_status.centerx, y, center=True)
            y += lh

        self._text(self.f_small, "TARGET ASPECT RATIO", C_DIM, self.r_dd.x, self.r_dd.y - s(18))
        hot = self.r_dd.collidepoint(mouse_ui) or self.dd_open
        pygame.draw.rect(scr, C_BTN_HOT if hot else C_BTN, self.r_dd, border_radius=s(3))
        pygame.draw.rect(scr, C_BORDER_HOT if hot else C_BORDER, self.r_dd, 1, border_radius=s(3))
        self._text(self.f_body, self.options[self.aspect_idx], C_TEXT, self.r_dd.x + s(10),
                   self.r_dd.centery - self.f_body.get_height() // 2)
        ax, ay, aw = self.r_dd.right - s(20), self.r_dd.centery, s(5)
        tip = [(ax - aw, ay - s(2)), (ax + aw, ay - s(2)), (ax, ay + s(3))]
        if self.dd_open:
            tip = [(ax - aw, ay + s(2)), (ax + aw, ay + s(2)), (ax, ay - s(3))]
        pygame.draw.polygon(scr, C_DIM, tip)

        self._button("make", self.r_make, "Make Borderless", self.can_make(), mouse_ui)
        self._button("stop", self.r_stop, "Stop Borderless", self.is_borderless, mouse_ui)

        hot = self.r_auto.collidepoint(mouse_ui)
        box = pygame.Rect(self.r_auto.x, self.r_auto.centery - s(9), s(18), s(18))
        pygame.draw.rect(scr, C_BTN_HOT if hot else C_BTN, box, border_radius=s(3))
        pygame.draw.rect(scr, C_BORDER_HOT if hot else C_BORDER, box, 1, border_radius=s(3))
        if self.auto:
            pts = [(box.x + s(4), box.centery), (box.x + s(8), box.bottom - s(5)),
                   (box.right - s(4), box.y + s(5))]
            pygame.draw.lines(scr, C_TEXT, False, pts, max(2, s(2)))
        self._text(self.f_body, "Auto Borderless", C_TEXT if hot or self.auto else C_DIM,
                   box.right + s(10), self.r_auto.centery - self.f_body.get_height() // 2)

        self._button("reticle", self.r_reticle, "Reticle", True, mouse_ui)

        hk_label = "Press a key..." if self.capturing_hotkey else f"Hide UI: {self.hotkey or '...'}"
        hk_hot = self.r_hotkey.collidepoint(mouse_ui) or self.capturing_hotkey
        self._text(self.f_body, hk_label, C_TEXT if hk_hot else C_DIM,
                   self.r_hotkey.x, self.r_hotkey.centery - self.f_body.get_height() // 2)

        if self.dd_open:
            pygame.draw.rect(scr, (30, 30, 35), self.r_list, border_radius=s(3))
            pygame.draw.rect(scr, C_BORDER_HOT, self.r_list, 1, border_radius=s(3))
            for i, label in enumerate(self.options):
                r = pygame.Rect(self.r_list.x + s(1), self.r_list.y + s(1) + i * self.item_h,
                                self.r_list.w - s(2), self.item_h)
                if r.collidepoint(mouse_ui):
                    pygame.draw.rect(scr, C_BTN_HOT, r)
                sel = i == self.aspect_idx
                self._text(self.f_body, label, C_TEXT if sel else C_DIM, r.x + s(10),
                           r.centery - self.f_body.get_height() // 2)
                if sel:
                    pygame.draw.circle(scr, C_TEXT, (r.right - s(14), r.centery), s(3))

        if self.modal:
            scr.blit(self.dim, (0, 0))
            box = self.modal["box"]
            pygame.draw.rect(scr, (28, 28, 33), box, border_radius=s(4))
            pygame.draw.rect(scr, C_BORDER, box, 1, border_radius=s(4))
            y = box.y + s(20)
            for ln in self.modal["lines"]:
                self._text(self.f_body, ln, C_TEXT, box.centerx, y, center=True)
                y += self.f_body.get_linesize()
            for i, ((label, _), r) in enumerate(zip(self.modal["buttons"], self.modal["rects"])):
                down = self.pressed == ("modal", i) and r.collidepoint(mouse)
                fill = C_BTN_DOWN if down else (C_BTN_HOT if r.collidepoint(mouse) else C_BTN)
                pygame.draw.rect(scr, fill, r, border_radius=s(3))
                pygame.draw.rect(scr, C_BORDER_HOT if r.collidepoint(mouse) else C_BORDER, r, 1,
                                 border_radius=s(3))
                img = self.f_btn.render(label, True, C_TEXT)
                scr.blit(img, img.get_rect(center=r.center))

    def run(self):
        while self.running:
            ids = consume_hotkeys()
            if self.capturing_hotkey:
                ids = set()                     # a key being picked is not a command
            if _HOTKEY_ID in ids and not self.disable_shortcut:
                self.on_main_hotkey()
            if _RET_HOTKEY_ID in ids:
                self.send_reticle("toggle")
            if not self.capturing_hotkey:
                self.sync_reticle_hotkey()
            self.tick()
            if self.ui_visible:
                self.draw()
                pygame.display.flip()
            for ev in pygame.event.get():
                self.handle(ev)
            pygame.time.wait(50)


def reticle_wanted():
    """True when the Reticle window should already be running in the background (a mark position is saved)."""
    try:
        with open(os.path.join(SCRIPT_DIR, "reticle_config.json"), "r", encoding="utf-8") as f:
            return bool(json.load(f).get("dot"))
    except (OSError, ValueError, AttributeError):
        return False


def reticle_hotkey_vk():
    try:
        with open(os.path.join(SCRIPT_DIR, "reticle_config.json"), "r", encoding="utf-8") as f:
            name = str(json.load(f).get("ui_hotkey") or "")
    except (OSError, ValueError, AttributeError):
        return 0
    if not name:
        return 0
    import reticle_maker
    return reticle_maker.vk_of(name)


def main():
    if "--reticle-ui" in sys.argv:
        import reticle_maker
        sys.exit(reticle_maker.main(sys.argv[1:]))
    if sys.platform != "win32":
        fatal("This tool only works on Windows.")
    enable_dpi_awareness()
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:
        pass
    if not take_over_previous():
        return
    clear_stale_lock()
    write_lock()
    app = None
    try:
        app = App()
        app.run()
    except Exception:
        import traceback
        fatal("Unexpected error:\n\n" + traceback.format_exc())
    finally:
        if app is not None:
            app.shutdown_reticle()
        _uninstall_hook()
        clear_lock()
        pygame.quit()


if __name__ == "__main__":
    main()