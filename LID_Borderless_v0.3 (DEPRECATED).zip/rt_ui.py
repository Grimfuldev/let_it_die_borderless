"""The Reticle Maker window (pygame) and the --reticle-ui entry point."""
import ctypes
import os
import queue
import select
import socket
import sys
import threading
import time
from rt_core import (
    save_preview,
    build_preset,
    reset_all,
    KIND_DIRS,
    build_reticle_meta,
    read_reticle_meta,
    apply_reticle_meta,
    CFG_PATH,
    apply_preset,
    recolor,
    scale_min, scale_rgba, outline_rgba,
    APP_ID,
    APP_TITLE,
    game_build,
    Config,
    DEFAULT_SELECTED,
    INJECT_MAX,
    INJECT_MIN,
    IS_WIN,
    JOY_CHOICES,
    MOUSE_CHOICES,
    MakerError,
    VERSION,
    VK_NAMES,
    _premul,
    _resample_pm,
    _straight,
    abs_of,
    clamp,
    clean_temp_files,
    compose,
    ensure_dirs,
    find_game_dirs,
    find_ui,
    game_running,
    inject_mark,
    load_rgba,
    load_section_cfg,
    num,
    parse_rgb,
    pid_alive,
    prune_selected,
    restore_upk,
    rgb_text,
    vk_of,
    write_current,
)
from rt_overlay import Engine, Win
from rt_widgets import (
    DY,
    parse_rgb_strict,
    C_BTN,
    C_BTN_DOWN,
    C_BTN_HOT,
    C_BTN_LINE,
    C_INPUT_FILL,
    C_INPUT_LINE,
    C_INPUT_TEXT,
    C_LABEL,
    C_LABEL_DIM,
    C_OFF_LINE,
    C_OFF_TEXT,
    C_RED,
    C_RED_HOT,
    C_SEP,
    C_TEXT,
    CatalogMixin,
    H,
    MARK_COLORS,
    R,
    TextBox,
    W,
    Y0,
    choose_color_dialog,
    esc_down,
    fmt_num,
    open_file_dialog,
    parse_float,
    parse_int,
    scan_pressed_key,
    ui_scale,
    window_is_game,
    snapshot_game,
)
import numpy as np
import pygame


PREVIEW_MIN = 30        # px: previews pad anything smaller than this with a transparent border


class ReticleUI(CatalogMixin):

    def __init__(self, parent_pid=0, port=0, hidden=False):
        self.pg = pg = pygame
        pg.display.init()
        pg.font.init()
        self.parent_pid = parent_pid
        self.S = ui_scale()
        self.cfg = Config()
        ensure_dirs()
        self.msgs = queue.Queue()
        self.message = ""
        self.msg_time = 0.0
        self.engine = Engine(self.cfg, self.msgs)
        self.focus = None
        self.visible = not hidden
        self.resume = False
        self.placed = False
        self.running = True
        self.modal = None
        self.dropdown = None
        self.catalog = None
        self._saved_key = None     # finished-reticle key of the last Save Preview
        self.pv_note = ""
        self.pv_note_red = False
        self.pv_note_until = 0.0
        self.prevpop = None       # {'white', 'game', 'drag'} while the actual-size preview popup is open
        self.snap_why = ""
        self.snap = None          # picture of the game screen (memory only), taken when the window is shown with
        self._snap_surf = None    # the game in front; dropped whenever this window is hidden
        self._hand = None         # the program's own cursor (set once the window exists)
        self._cur_hidden = False
        self._pv_cache = (None, None)
        self.capturing = None
        self.cap_released = False
        self.pressed = None
        self.drag_scale = self.drag_sub = False
        self.busy = False
        self.game_run = False
        self.sha = "unknown"
        self.build = ""           # Steam build id of the installed game
        self.sha_backup = False   # the game program's .backup exists
        self.injected = False
        self.last_poll = 0.0
        self.passthrough = False
        self.pt_after = 0.0
        self.pt_check = 0.0
        self.last_reload = 0.0
        self.last_parent = 0.0
        self.paths = None
        self.imgs = {}
        self.thumbs = {}
        self.joy_cache = {}
        self.preview_key = None
        self.preview = None
        self.sel = {"outer": [], "center": []}
        self._comp_key = None
        self._comp = None
        self._parts = {}

        flags = pg.HIDDEN if (hidden and hasattr(pg, "HIDDEN")) else 0
        self.window = pg.display.set_mode((int(W * self.S), int(H * self.S)), flags)
        pg.display.set_caption("%s %s" % (APP_TITLE, VERSION))
        self.canvas = pg.Surface((W, H)).convert()
        self.hwnd = pg.display.get_wm_info().get("window") if IS_WIN else None
        names = "myriadpro,segoeui,arial"
        self.f_lbl = pg.font.SysFont(names, 18)
        self.f_in = pg.font.SysFont(names, 18)
        self.f_btn = pg.font.SysFont(names, 15, bold=True)
        self.f_small = pg.font.SysFont(names, 13)
        self.f_pin = pg.font.SysFont(names, 15)
        self.f_msg = pg.font.SysFont(names, 16)
        self.bg = None
        p = find_ui("UI background.webp")
        if p:
            try:
                im = pg.image.load(p).convert()
                k = max(W / im.get_width(), H / im.get_height())
                im = pg.transform.smoothscale(im, (int(im.get_width() * k) + 1, int(im.get_height() * k) + 1))
                self.bg = im
            except Exception:
                pass
        self._chrome()
        self.sock = None
        if port:
            try:
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                self.sock.bind(("127.0.0.1", port))
                self.sock.setblocking(False)
            except OSError:
                self.sock = None
        self._layout()
        self._load_state()
        self.engine.start()
        self.refresh_paths()
        if IS_WIN and self.hwnd and hidden:
            ctypes.windll.user32.ShowWindow(self.hwnd, 0)

    # ------------------------------------------------------------------ window
    def _chrome(self):
        pg = self.pg
        g = find_ui("uncle glasses ready.webp")
        if g:
            try:
                pg.display.set_icon(pg.image.load(g))
            except Exception:
                pass
        if not (IS_WIN and self.hwnd):
            return
        try:
            u = ctypes.windll.user32
            ico = find_ui("Lidico.ico")
            if ico:
                hicon = u.LoadImageW(None, ico, 1, 0, 0, 0x0010 | 0x0040)
                if hicon:
                    u.SendMessageW(self.hwnd, 0x0080, 1, hicon)
            black, dark = ctypes.c_int(0), ctypes.c_int(1)
            dwm = ctypes.windll.dwmapi
            dwm.DwmSetWindowAttribute(self.hwnd, 20, ctypes.byref(dark), 4)
            dwm.DwmSetWindowAttribute(self.hwnd, 35, ctypes.byref(black), 4)
            dwm.DwmSetWindowAttribute(self.hwnd, 34, ctypes.byref(black), 4)
        except Exception:
            pass
        c = find_ui("let it die cursor.webp")
        if c:
            try:
                im = pg.image.load(c).convert_alpha()
                sz = int(32 * self.S)
                self._hand = ((0, 0), pg.transform.smoothscale(im, (sz, sz)))
                pg.mouse.set_cursor(*self._hand)
            except Exception:
                pass

    def _place_near_parent(self):
        """First time shown: centred on the borderless window (the user can move it afterwards)."""
        if not (IS_WIN and self.hwnd and self.parent_pid):
            return
        try:
            from ctypes import wintypes as w
            u = ctypes.windll.user32
            found = []
            P = ctypes.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)

            def cb(h, _):
                pid = w.DWORD()
                u.GetWindowThreadProcessId(h, ctypes.byref(pid))
                if pid.value == self.parent_pid and u.IsWindowVisible(h):
                    rc = w.RECT()
                    u.GetWindowRect(h, ctypes.byref(rc))
                    found.append(rc)
                return True

            u.EnumWindows(P(cb), 0)
            me = w.RECT()
            u.GetWindowRect(self.hwnd, ctypes.byref(me))
            mw, mh = me.right - me.left, me.bottom - me.top
            sw, sh = u.GetSystemMetrics(0), u.GetSystemMetrics(1)
            if found:
                p = found[0]
                x = (p.left + p.right - mw) // 2
                y = (p.top + p.bottom - mh) // 2
                x = min(max(0, x), sw - mw)
                y = min(max(0, y), sh - mh)
                u.SetWindowPos(self.hwnd, None, x, y, 0, 0, 0x0001 | 0x0004)
        except Exception:
            pass

    def show(self):
        if not self.visible:
            self._take_snap()
        self.visible = True
        if IS_WIN and self.hwnd:
            u = ctypes.windll.user32
            if not self.placed:
                self._place_near_parent()
                self.placed = True
            self.set_passthrough(False)
            self.pt_after = time.time() + 0.8
            u.ShowWindow(self.hwnd, 9)
            u.SetWindowPos(self.hwnd, ctypes.c_void_p(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
            self._grab_focus()
        self.last_poll = 0.0           # poll the game / UPK state right away
        self.refresh_sha()

    def _grab_focus(self):
        """Bring the window to the front even when the game has the focus."""
        try:
            u = ctypes.windll.user32
            k = ctypes.windll.kernel32
            u.GetForegroundWindow.restype = ctypes.c_void_p
            fg = u.GetForegroundWindow()
            tid_fg = u.GetWindowThreadProcessId(ctypes.c_void_p(fg), None) if fg else 0
            tid_me = k.GetCurrentThreadId()
            attached = bool(tid_fg and tid_fg != tid_me and u.AttachThreadInput(tid_me, tid_fg, True))
            u.SetForegroundWindow(ctypes.c_void_p(self.hwnd))
            if attached:
                u.AttachThreadInput(tid_me, tid_fg, False)
        except Exception:
            pass

    def set_passthrough(self, on):
        """While the game has the focus the window ignores the mouse (it cannot be hovered or clicked)."""
        if on == self.passthrough or not (IS_WIN and self.hwnd):
            return
        try:
            u = ctypes.WinDLL("user32", use_last_error=True)
            u.GetWindowLongW.argtypes = [ctypes.c_void_p, ctypes.c_int]
            u.SetWindowLongW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_long]
            u.SetLayeredWindowAttributes.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ubyte, ctypes.c_ulong]
            u.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                       ctypes.c_int, ctypes.c_uint]
            ex = u.GetWindowLongW(self.hwnd, -20)
            if on:
                u.SetWindowLongW(self.hwnd, -20, ex | 0x80000 | 0x20)
                u.SetLayeredWindowAttributes(self.hwnd, 0, 255, 2)
            else:
                u.SetWindowLongW(self.hwnd, -20, ex & ~(0x80000 | 0x20))
            u.SetWindowPos(self.hwnd, None, 0, 0, 0, 0, 0x37)
            self.passthrough = on
        except Exception:
            pass

    def update_passthrough(self, now):
        if not (IS_WIN and self.hwnd) or now - self.pt_check < 0.1:
            return
        self.pt_check = now
        if not self.visible:
            return
        u = ctypes.windll.user32
        u.GetForegroundWindow.restype = ctypes.c_void_p
        fg = u.GetForegroundWindow()
        want = bool(fg) and fg != self.hwnd and window_is_game(fg) and now >= self.pt_after
        self.set_passthrough(want)

    def _take_snap(self):
        """Picture of the game screen into memory (self.snap); self.snap_why says why there is none."""
        self.snap, self.snap_why = snapshot_game()
        self._snap_surf = None

    def hide(self):
        self.close_overlays()
        self.snap = self._snap_surf = None          # the game picture never outlives the window being shown
        self.snap_why = ""
        self.visible = False
        self.set_passthrough(False)
        if IS_WIN and self.hwnd:
            ctypes.windll.user32.ShowWindow(self.hwnd, 0)

    def lose_focus(self):
        """The user clicked away from the window: the input being edited applies what it has."""
        if self.focus:
            self.focus.blur()
        for tb in self.active_tbs():
            tb.mouse_up()
        self.dropdown = None
        self.capturing = None
        self.pressed = None
        if self.prevpop:
            self.prevpop["drag"] = None

    def close_overlays(self):
        if self.focus:
            self.focus.blur()
        self.dropdown = self.catalog = self.modal = None
        self.close_prevpop()
        self.capturing = None

    def command(self, cmd):
        cmd = cmd.strip().lower()
        if cmd == "show":
            self.show()
        elif cmd == "hide":
            self.hide()
        elif cmd == "toggle":
            self.hide() if self.visible else self.show()
        elif cmd == "hide_keep":
            self.resume = self.visible
            if self.visible:
                self.hide()
        elif cmd == "restore":
            if self.resume:
                self.show()
            self.resume = False
        elif cmd == "quit":
            self.running = False

    # ------------------------------------------------------------------ messages / clipboard
    def post(self, text):
        self.message = text
        self.msg_time = time.time()

    def clip_put(self, t):
        try:
            self.pg.scrap.init()
            self.pg.scrap.put_text(t)
        except Exception:
            self._clip = t

    def clip_get(self):
        try:
            self.pg.scrap.init()
            t = self.pg.scrap.get_text()
            if t:
                return t
        except Exception:
            pass
        return getattr(self, "_clip", "")

    # ------------------------------------------------------------------ state
    def _load_state(self):
        c = self.cfg
        self.mark_color = parse_rgb(c.get("marker_color"), (0, 0, 0))
        self.scale = num(c.get("reticle_scale"), 0, -99.9, 500)
        self.ov_color = parse_rgb(c.get("override_color"), (255, 255, 255))
        self.ov_on = bool(c.get("override_enabled", False))
        self.outline_on = bool(c.get("post_outline", True))
        self.sub_op = num(c.get("subtract_opacity"), 0, 0, 100, True)
        self.inject_size = num(c.get("inject_size"), INJECT_MIN, INJECT_MIN, INJECT_MAX, True)
        sel = c.get("selected")
        if not isinstance(sel, dict):
            sel = DEFAULT_SELECTED
        self.sel = prune_selected(sel)
        if self.sel != sel:
            c.set(selected=self.sel)
        self.mark_sel = self.mark_color
        self.tb_scale.set_value(self.scale)
        self.tb_override.set_value(self.ov_color)
        self.tb_sub.set_value(self.sub_op)
        self.scale_neg = self.scale < 0
        self.sync_fields()

    def sync_fields(self):
        c = self.cfg
        v = c.values()
        ov = c.get("overlay") if isinstance(c.get("overlay"), dict) else {}
        for tb, val in ((self.tb_devx, num(ov.get("x"), 0, -2000, 2000)), (self.tb_devy, num(ov.get("y"), 0, -2000, 2000)),
                        (self.tb_range, v.dev), (self.tb_fade, v.persist), (self.tb_sample, v.wait)):
            tb.set_value(val)
        self.show_marker = bool(c.get("show_marker", False))
        self.mask_size = v.size
        mouse = str(c.get("mouse_key", "LMB")).upper()
        self.mouse_key = mouse if mouse in MOUSE_CHOICES else "LMB"
        self.kb1 = VK_NAMES.get(vk_of(c.get("keyboard_key")), "")
        self.kb2 = VK_NAMES.get(vk_of(c.get("keyboard_key_2")), "")
        j = str(c.get("joystick_key", "None"))
        self.joy_key = next((x for x in JOY_CHOICES if x.lower() == j.lower()), "None")
        self.ui_hotkey = VK_NAMES.get(vk_of(c.get("ui_hotkey")), "")
        steam = str(c.get("steam_exe", "") or "")
        if steam != getattr(self, "steam_exe", None):
            self.steam_exe = steam
            self.refresh_paths()

    def mark_color_name(self):
        for n, c in MARK_COLORS:
            if tuple(c) == tuple(self.mark_sel):
                return n
        return rgb_text(self.mark_sel)

    def refresh_paths(self):
        self.paths = find_game_dirs(self.steam_exe) if self.steam_exe else None
        self.build = game_build(self.paths[0]) if self.paths else ""
        if self.paths and not self.busy and not game_running():
            clean_temp_files(self.paths[0], self.paths[2])
        self.refresh_sha()

    def refresh_sha(self):
        if not self.paths:
            self.sha = "unknown"
            return
        exe = self.paths[2]

        def work():
            try:
                import Hash_remover as HR
                self.build = game_build(exe)        # a game update changes it
                st = HR.sha_status(exe, self.build)
                self.sha_backup = bool(st.get("backup"))
                self.sha = st["state"]
            except Exception:
                self.sha = "unknown"
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------ layout
    def _layout(self):
        self.r_steam = R(18.9, 100.1, 225, 33.8)
        self.r_browse = R(244, 100.1, 69.7, 33.8)
        self.r_unlock = R(21.2, 146.3, 93, 33.4)
        self.r_inject = R(127.4, 146.3, 106.2, 33.4)
        self.r_injsize = R(241.4, 150.2, 48.5, 25.7)
        self.r_markdot = R(248.2, 193.7, 34.7, 34.7)
        self.r_markdd = R(113.8, 198.2, 128, 25.7)
        self.r_outer = pygame.Rect(29, 191, 84, 84)
        self.r_prev = pygame.Rect(123, 191, 84, 84)
        self.r_center = pygame.Rect(217, 191, 84, 84)
        self.r_sneg = pygame.Rect(192, 301, 16, 16)
        self.r_sslider = pygame.Rect(110, 330, 190, 16)
        self.r_ovchk = pygame.Rect(10, 362, 16, 16)
        self.r_ovdot = pygame.Rect(278, 358, 26, 26)
        self.r_ssub = pygame.Rect(110, 426, 190, 16)
        self.r_outchk = pygame.Rect(10, 466, 16, 16)
        self.r_apply = pygame.Rect(54, 506, 93, 33)
        self.r_preset = pygame.Rect(164, 458, 124, 28)        # Save Preset (right click: import)
        self.r_import = pygame.Rect(164, 506, 124, 33)
        self.r_adjust = pygame.Rect(396, 470, 128, 33)
        self.r_show = R(492, 96.6, 25.7, 25.7)
        self.r_mask = R(491.4, 198.2, 48.5, 25.7)
        self.r_mouse = R(493.4, 349.6, 63.8, 25.7)
        self.r_kb1 = R(493.1, 384.5, 65.8, 25.7)
        self.r_kb1x = R(560.5, 389.4, 17.2, 17.2)
        self.r_kb2 = R(493.1, 418.2, 65.8, 25.7)
        self.r_kb2x = R(560.5, 422.5, 17.2, 17.2)
        self.r_joy = R(493.4, 451.7, 78.7, 38.1)
        self.r_short = pygame.Rect(461, int(round(523.3 - Y0 + DY)) - 6, 125, 24)
        self.r_close = R(462.4, 550.4 + DY, 93, 26.4)
        self.r_msgbox = R(19.7, 523.5 + DY, 426.9, 53.4)

        def box(x, y, w, h):
            return R(x, y, w, h)

        T = TextBox
        self.tb_scale = T(self, pygame.Rect(110, 296, 66, 26), 0.0, self._parse_scale, fmt_num, self._scale_commit)
        self.tb_override = T(self, pygame.Rect(146, 358, 124, 26), (255, 255, 255), parse_rgb_strict, rgb_text,
                             self._override_commit)
        self.tb_sub = T(self, pygame.Rect(146, 392, 66, 26), 0, parse_int(0, 100), str, self._sub_commit)
        self.tb_devx = T(self, box(492, 130.9, 65.8, 25.7), 0.0, parse_float(-2000, 2000), fmt_num,
                         lambda v: self.cfg.set_overlay(x=v))
        self.tb_devy = T(self, box(492, 164.6, 65.8, 25.7), 0.0, parse_float(-2000, 2000), fmt_num,
                         lambda v: self.cfg.set_overlay(y=v))
        self.tb_range = T(self, box(492, 230.5, 65.8, 25.7), 5, parse_int(0, 255), str,
                          lambda v: self.cfg.set(deviation_level=v))
        self.tb_fade = T(self, box(492, 263.3, 65.8, 25.7), 0.2, parse_float(0, 60), fmt_num,
                         lambda v: self.cfg.set(persist_seconds=v))
        self.tb_sample = T(self, box(492, 296.6, 65.8, 25.7), 0.1, parse_float(0, 5), fmt_num,
                           lambda v: self.cfg.set(wait_to_engage=v))
        self.textboxes = [self.tb_scale, self.tb_override, self.tb_sub, self.tb_devx, self.tb_devy, self.tb_range, self.tb_fade, self.tb_sample]

    def scale_min(self):
        comp = self.composite()
        return scale_min(comp) if comp is not None else -90.0

    def _parse_scale(self, text):
        """Too small to be valid -> the smallest valid scale for this reticle; unreadable or too big -> default."""
        v = parse_float(-1e9, 500)(text)
        if v is None:
            return None
        return max(v, self.scale_min())

    def _scale_commit(self, v):
        self.scale = v
        if v:
            self.scale_neg = v < 0

    def _override_commit(self, v):
        self.ov_color = v
        self.cfg.set(override_color=list(v))

    def _sub_commit(self, v):
        self.sub_op = v
        self.cfg.set(subtract_opacity=int(v))

    def _sub_slider(self, x):
        v = int(round(clamp((x - self.r_ssub.x) / float(self.r_ssub.w), 0, 1) * 100))
        self.sub_op = v
        self.tb_sub.value, self.tb_sub.text = v, str(v)
        self.cfg.set(subtract_opacity=v)

    def _outline_toggle(self):
        self.outline_on = not self.outline_on
        self.cfg.set(post_outline=self.outline_on)

    def _outline_params(self):
        """width / blur / opacity from the JSON (not editable in the UI); read on every use so edits apply live."""
        def num(k, d, lo, hi):
            try:
                return clamp(float(self.cfg.get(k, d)), lo, hi)
            except (TypeError, ValueError):
                return d
        return (num("outline_width", 1.5, 0, 20), num("outline_blur", 3, 0, 30), num("outline_opacity", 70, 0, 100))

    def _override_toggle(self):
        self.ov_on = not self.ov_on
        self.cfg.set(override_enabled=self.ov_on)

    def final_image(self):
        """The combined reticle; with Override Color enabled it gets one more hue change on top (like the old
        global colour). None when nothing is picked."""
        comp = self.composite()
        if comp is None or not (self.ov_on or self.sub_op):
            return comp
        key = (self._comp_key, self.ov_on, tuple(self.ov_color), int(self.sub_op))
        if getattr(self, "_ov_key", None) != key:
            img = recolor(comp, self.ov_color, 100) if self.ov_on else comp
            if self.sub_op:
                # Subtract Opacity: takes that many percentage points off every pixel's opacity, on top of what
                # the folders already took off (100 leaves nothing visible)
                img = img.copy()
                a = img[..., 3].astype(np.int16) - int(round(self.sub_op * 2.55))
                img[..., 3] = np.clip(a, 0, 255).astype(np.uint8)
            self._ov_key, self._ov_img = key, img
        return self._ov_img

    def finished(self):
        """What Apply / Save Preview write and the popup shows: the final image at the global scale, then (when
        POST Outline is on) the outline, so its thickness is real pixels and is not enlarged by Scale Adjust."""
        comp = self.final_image()
        if comp is None:
            return None
        self.cfg.reload()
        sc = max(self.scale, self.scale_min())
        op = self._outline_params() if self.outline_on else None
        key = (self._comp_key, self.ov_on, tuple(self.ov_color), int(self.sub_op), sc, op)
        if getattr(self, "_fin_key", None) != key:
            img = scale_rgba(comp, sc)
            if op:
                img = outline_rgba(img, *op)
            self._fin_key, self._fin_img = key, img
        return self._fin_img

    def _set_scale(self, v):
        self.scale = max(v, self.scale_min())
        tb = self.tb_scale
        tb.value, tb.text = self.scale, fmt_num(self.scale)

    def _scale_slider(self, x):
        m = int(round(clamp((x - self.r_sslider.x) / float(self.r_sslider.w), 0, 1) * 100))
        self._set_scale(-m if self.scale_neg else m)

    def _scale_flip(self):
        self.scale_neg = not self.scale_neg
        self._set_scale(-abs(self.scale) if self.scale_neg else abs(self.scale))

    # ------------------------------------------------------------------ enable rules
    def files_ok(self):
        return bool(self.paths) and not self.busy and not self.game_run

    def unlock_enabled(self):
        # Restore SHA needs the saved original of the game program; without it the button stays grey
        return self.files_ok() and (self.sha == "active" or self.sha == "off" and self.sha_backup)

    def inject_enabled(self):
        return self.files_ok() and self.sha == "off"

    def ready(self):
        """steam.exe set and the game found, SHA unlocked, and the game's UPK is a modified one."""
        return bool(self.paths) and self.sha == "off" and self.injected

    def apply_enabled(self):
        return self.ready() and self.composite() is not None

    def adjust_enabled(self):
        return self.ready()

    def idle_hint(self):
        if not self.paths:
            return "Browse for Steam.exe"
        if self.sha != "off":
            return "Unlock SHA to enable Reticle usage"
        if not self.injected:
            return "Inject Mark to enable reticle usage"
        return "..."

    def check_injected(self):
        """The game's UPK counts as modified when its size differs from the saved original."""
        if not self.paths:
            return False
        try:
            import Hash_remover as HR
            bk = HR.valid_backup(self.paths[0], self.build)
            return bk is not None and os.path.getsize(self.paths[0]) != os.path.getsize(bk)
        except OSError:
            return False

    # ------------------------------------------------------------------ actions
    def do_browse(self):
        p = open_file_dialog(self.hwnd, "Select steam.exe", "steam.exe\0steam.exe\0All files\0*.*\0\0",
                             os.path.dirname(self.steam_exe) if self.steam_exe else "")
        if not p:
            return
        if os.path.basename(p).lower() != "steam.exe":
            self.post("That is not steam.exe. Pick the steam.exe of your Steam folder.")
            return
        self.cfg.set(steam_exe=p)
        self.steam_exe = p
        self.refresh_paths()
        if self.paths:
            self.post("Game found: " + os.path.dirname(os.path.dirname(os.path.dirname(self.paths[0]))))
        else:
            self.post("LET IT DIE was not found in that Steam's libraries.")

    def run_task(self, label, fn):
        if self.busy:
            return
        self.busy = True
        self.post(label)

        def work():
            try:
                self.post(fn())
            except Exception as e:
                msg = str(e) or e.__class__.__name__
                self.post("Failed: " + msg)
            finally:
                self.busy = False
                self.refresh_sha()
        threading.Thread(target=work, daemon=True).start()

    def do_unlock(self):
        if self.sha == "active":
            self.make_modal("Unlocking SHA turns off the game's file integrity check, so the game accepts the "
                            "modified files. A safe copy of the game program is saved next to it in the game folder (named with the game's build id and the extension .backup) so Restore SHA can undo it. "
                            "Proceed?", [("Proceed", self._unlock_go), ("Cancel", None)])
        elif self.sha == "off":
            self.make_modal("This restores the original files and removes the backup copies that were generated "
                            "by this program.", [("Proceed", self._restore_start), ("Cancel", None)])

    def _restore_start(self):
        self.run_task("Restoring the game to its original files...", self._restore_go)

    def _unlock_go(self):
        exe = self.paths[2]
        clean_temp_files(self.paths[0], exe)

        def fn():
            import Hash_remover as HR
            try:
                n = HR.turn_off_all(Path_(exe), build=self.build)
            except HR.Problem as e:
                raise Exception(str(e))
            return "SHA unlocked (%d entries switched off)." % n
        self.run_task("Unlocking SHA...", fn)

    def _restore_go(self):
        """Put the original files back; a backup is deleted only after its file reads back identical to it."""
        upk, _bin, exe = self.paths
        import Hash_remover as HR
        notes, removed = [], 0
        try:
            bk = HR.valid_backup(upk, self.build)
            if restore_upk(upk, self.build):
                notes.append("UI_HUD_SF.upk restored")
            if bk is not None:
                if HR.same_file(upk, bk):
                    removed += HR.discard_backups(upk)
                else:
                    notes.append("UI_HUD_SF.upk does not match its backup, backup kept")
        except MakerError as e:
            notes.append("could not restore UI_HUD_SF.upk (%s)" % e)
        try:
            bk = HR.valid_backup(exe, self.build)
            HR.restore(Path_(exe), self.build)
            notes.append("game program restored")
            if bk is not None and HR.same_file(exe, bk):
                removed += HR.discard_backups(exe)
            else:
                notes.append("game program does not match its backup, backup kept")
        except HR.Problem as e:
            notes.append(str(e))
        if removed:
            notes.append("%d backup cop%s removed" % (removed, "y" if removed == 1 else "ies"))
        return "Restore done: " + "; ".join(notes) + "."

    def do_inject(self):
        color, size = self.mark_sel, self.inject_size
        upk = self.paths[0]

        def fn():
            inject_mark(upk, color, size, self.build)
            self.cfg.set(marker_color=list(color), inject_size=size)
            self.mark_color = color
            self.injected = self.check_injected()
            return "Mark injected (%s, %d px). Now press Start Adjust." % (rgb_text(color), size)
        self.run_task("Injecting mark...", fn)

    def do_apply(self):
        comp = self.final_image()
        if comp is None:
            self.post("Select at least one reticle (Outer or Center) first.")
            return
        try:
            self.scale = max(self.scale, self.scale_min())
            self.tb_scale.set_value(self.scale)
            write_current(self.finished(), 0)      # already scaled (and outlined)
            self.cfg.set(reticle_scale=self.scale)
            self.post("Applied: %d outer + %d center reticle(s), scale %s%%." % (
                len(self.sel["outer"]), len(self.sel["center"]), fmt_num(self.scale)))
        except Exception as e:
            self.post("Could not apply the reticle: %s" % e)

    def do_save_preview(self):
        """Save the finished reticle as a new reticle in _Outer (the button lives in the preview popup)."""
        comp = self.final_image()
        if comp is None:
            self.post("Select at least one reticle (Outer or Center) first.")
            return
        try:
            self.scale = max(self.scale, self.scale_min())
            self.tb_scale.set_value(self.scale)
            fin = self.finished()
            dst = save_preview(fin, 0, build_reticle_meta(self.cfg, self.sel))
            self._saved_key = self._fin_key
            self.thumbs.clear()
            self._pv_say("Saved: %s" % os.path.basename(dst))
            self.post("Saved to _Outer as %s." % os.path.basename(dst))
        except Exception as e:
            self._pv_say("Could not save: %s" % e, True, 3)
            self.post("Could not save the preview: %s" % e)

    def _pv_say(self, text, red=False, secs=0):
        """Short status line in the preview popup; secs > 0 makes it disappear by itself."""
        self.pv_note, self.pv_note_red = text, red
        self.pv_note_until = time.time() + secs if secs else 0.0

    def do_import_preview(self, path=None):
        """Rebuild a reticle from the metadata of a .config image: its picks and folder options come back and the
        result is mounted (applied). Images that are not here any more are ignored."""
        path = path or open_file_dialog(self.hwnd, "Import reticle",
                                        "Reticles with config (*.config.webp, *.config.png)\0*.config.webp;*.config.png\0\0",
                                        KIND_DIRS["outer"])
        if not path:
            return
        meta = read_reticle_meta(path)
        if meta is None:
            self._pv_say("reticle without metadata", True, 3)
            return
        try:
            apply_reticle_meta(meta, self.cfg)
        except ValueError as e:
            self._pv_say("Nothing imported: %s" % e, True, 3)
            return
        self._load_state()
        self.thumbs.clear()
        self.do_apply()
        self._pv_say("Imported and applied: %s" % os.path.basename(path))

    def preview_unsaved(self):
        """True while the preview differs from the last one saved (the popup's Save Preview is grey otherwise)."""
        return self.finished() is not None and self._fin_key != self._saved_key

    # ------------------------------------------------------------------ presets
    def do_save_preset(self, path=None):
        import json
        path = path or open_file_dialog(self.hwnd, "Save preset", "Preset (*.json)\0*.json\0All files\0*.*\0\0",
                                        os.path.dirname(os.path.abspath(CFG_PATH)), save=True,
                                        default_name="reticle_preset.json", default_ext="json")
        if not path:
            if not IS_WIN:
                self.post("Preset not saved.")
            return
        try:
            self.cfg.reload()
            data = build_preset(self.cfg)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, path)
            self.post("Preset saved: %s (%d folders)." % (os.path.basename(path), len(data["sections"])))
        except OSError as e:
            self.post("Could not save the preset: %s" % e)

    def do_reset_all(self):
        self.make_modal("This resets every folder config and all settings (marker, shortcuts, reticle options) to "
                        "their defaults. Your Steam path and the calibrated mark are kept. Proceed?",
                        [("Proceed", self._reset_all_go), ("Cancel", None)])

    def _reset_all_go(self):
        try:
            n_sec, n_set = reset_all(self.cfg)
        except OSError as e:
            self.post("Could not reset: %s" % e)
            return
        self.close_overlays()
        self._load_state()
        self.thumbs.clear()
        self.post("Reset: %d folder configs and %d settings are back to their defaults." % (n_sec, n_set))

    def do_import_preset(self, path=None):
        import json
        path = path or open_file_dialog(self.hwnd, "Import preset", "Preset (*.json)\0*.json\0All files\0*.*\0\0",
                                        os.path.dirname(os.path.abspath(CFG_PATH)))
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            n_sec, n_set = apply_preset(data, self.cfg)
        except (OSError, ValueError) as e:
            self.post("That is not a usable preset file (%s)." % (str(e) or e.__class__.__name__))
            return
        self.close_overlays()
        self._load_state()
        self.thumbs.clear()
        self.post("Preset imported: %d folder configs and %d settings applied; anything not found here was ignored."
                  % (n_sec, n_set))

    def do_adjust(self):
        if not self.engine.is_alive():
            self.post("The overlay is not running.")
        elif self.engine.adjusting:
            self.engine.cancel_adjust()
        else:
            self.engine.start_adjust()

    def pick_color(self, tb):
        cur = tb.parse(tb.text) or tb.value
        c = choose_color_dialog(self.hwnd, cur)
        if c:
            tb.text = rgb_text(c)
            tb.value = c
            tb.commit(c)

    # ------------------------------------------------------------------ images
    def orig_image(self, path):
        im = self.imgs.get(path)
        if im is None:
            try:
                im = load_rgba(path)
            except Exception:
                im = np.zeros((8, 8, 4), np.uint8)
            self.imgs[path] = im
        return im

    def abs_list(self, kind):
        return [abs_of(r) for r in self.sel[kind]]

    def _sel_key(self):
        folders = sorted({os.path.dirname(r) for k in ("outer", "center") for r in self.sel[k]})
        return (tuple(self.sel["outer"]), tuple(self.sel["center"]),
                repr([(f, sorted(load_section_cfg(f).items())) for f in folders]))

    def composite(self):
        """Every picked folder with its own options (extras, scale, colour, opacity, displace) layered. None when empty."""
        key = self._sel_key()
        if key != self._comp_key:
            self._comp_key = key
            self._parts = {}
            try:
                self._comp = compose(self.abs_list("outer"), self.abs_list("center"))
            except Exception:
                self._comp = None
        return self._comp

    def part_surface(self, kind):
        """Unmodified preview of just the Outer or just the Center selection."""
        self.composite()
        if kind not in self._parts:
            try:
                im = compose(self.abs_list("outer"), [], plain=True) if kind == "outer" else \
                    compose([], self.abs_list("center"), plain=True)
                self._parts[kind] = self._rgba_surface(im, 56) if im is not None else None
            except Exception:
                self._parts[kind] = None
        return self._parts[kind]

    def make_preview(self):
        comp = self.final_image()
        key = (self._comp_key, float(self.scale), self.ov_on, tuple(self.ov_color), int(self.sub_op),
               self._outline_params() if self.outline_on else None)
        if key == self.preview_key:
            return self.preview
        self.preview_key = key
        self.preview = None
        if comp is not None:
            try:
                # the global Scale Adjust is shown as a bigger / smaller picture inside the (clipped) frame
                f = 1 + self.scale / 100.0
                if self.outline_on:
                    # shown before scaling, so give the outline the size it will have once scaled
                    w, b, o = self._outline_params()
                    comp = outline_rgba(comp, w / max(f, 0.05), b / max(f, 0.05), o)
                self.preview = self._rgba_surface(comp, int(round(clamp(60.0 * f, 2, 200))))
            except Exception:
                self.preview = None
        return self.preview

    def _rgba_surface(self, rgba, box, on_black=False):
        from PIL import Image
        h0, w0 = rgba.shape[:2]
        if h0 < PREVIEW_MIN or w0 < PREVIEW_MIN:
            # small sprites would be blown up into blobs when fitted to the box: give them a transparent border
            # (1 px per side at a time) until both sides reach PREVIEW_MIN; the asset itself is never enlarged
            nh, nw = max(PREVIEW_MIN, h0), max(PREVIEW_MIN, w0)
            top, left = (nh - h0) // 2, (nw - w0) // 2
            rgba = np.pad(rgba, ((top, nh - h0 - top), (left, nw - w0 - left), (0, 0)))
            h0, w0 = nh, nw
        k = min(box / w0, box / h0)
        size = (max(1, int(w0 * k)), max(1, int(h0 * k)))
        if size != (w0, h0):
            # resample premultiplied floats: resizing straight RGBA mixes the colour of fully transparent
            # (black) pixels into the edges, which showed up as dark, jagged, bled outlines
            rgba = _straight(_resample_pm(_premul(rgba), size=size, filt=Image.LANCZOS if k < 1 else Image.BICUBIC))
        im = Image.fromarray(rgba, "RGBA")
        if on_black:
            bg = Image.new("RGBA", im.size, (0, 0, 0, 255))
            bg.alpha_composite(im)
            im = bg
        return self.pg.image.frombuffer(im.tobytes(), im.size, "RGBA").convert_alpha()

    def thumb(self, path, box):
        t = self.thumbs.get((path, box))
        if t is None:
            try:
                t = self._rgba_surface(self.orig_image(path), box)
            except Exception:
                t = self.pg.Surface((1, 1), self.pg.SRCALPHA)
            self.thumbs[(path, box)] = t
        return t

    def joy_icon(self, name, h):
        key = (name, h)
        s = self.joy_cache.get(key)
        if s is not None:
            return s
        pg = self.pg
        p = next((q for q in (find_ui(os.path.join("Boxes", name + e)) for e in (".png", ".webp")) if q), "")
        s = None
        if p:
            try:
                im = pg.image.load(p).convert_alpha()
                k = h / im.get_height()
                s = pg.transform.smoothscale(im, (max(1, int(im.get_width() * k)), h))
            except Exception:
                s = None
        if s is None:
            s = self._joy_fallback(name, h)
        self.joy_cache[key] = s
        return s

    def _joy_fallback(self, name, h):
        pg = self.pg
        pairs = {"A_Cross": ("A", "x"), "B_Circle": ("B", "o"), "X_Square": ("X", "s"), "Y_Triangle": ("Y", "t")}
        f = pg.font.SysFont("segoeui,arial", max(8, int(h * 0.62)), bold=True)
        if name in pairs:
            r = h // 2
            s = pg.Surface((h * 2 + 2, h), pg.SRCALPHA)
            for i, glyph in enumerate(pairs[name]):
                cx, cy = r + i * (h + 2), r
                pg.draw.circle(s, (255, 255, 255), (cx, cy), r)
                if i == 0:
                    t = f.render(glyph, True, (0, 0, 0))
                    s.blit(t, t.get_rect(center=(cx, cy)))
                else:
                    q = int(r * 0.45)
                    if glyph == "x":
                        pg.draw.line(s, (0, 0, 0), (cx - q, cy - q), (cx + q, cy + q), 2)
                        pg.draw.line(s, (0, 0, 0), (cx - q, cy + q), (cx + q, cy - q), 2)
                    elif glyph == "o":
                        pg.draw.circle(s, (0, 0, 0), (cx, cy), q, 2)
                    elif glyph == "s":
                        pg.draw.rect(s, (0, 0, 0), (cx - q, cy - q, 2 * q, 2 * q), 2)
                    else:
                        pg.draw.polygon(s, (0, 0, 0), [(cx, cy - q), (cx + q, cy + q), (cx - q, cy + q)], 2)
            return s
        label = name.upper()
        f2 = pg.font.SysFont("segoeui,arial", max(8, int(h * (0.4 if label == "START" else 0.52))), bold=True)
        t = f2.render(label, True, (0, 0, 0))
        s = pg.Surface((max(t.get_width() + 10, h + 6), h), pg.SRCALPHA)
        pg.draw.rect(s, (255, 255, 255), s.get_rect(), border_radius=3)
        s.blit(t, t.get_rect(center=s.get_rect().center))
        return s

    # ------------------------------------------------------------------ events
    def to_logical(self, pos):
        return (int(pos[0] / self.S), int(pos[1] / self.S))

    def handle(self, ev):
        pg = self.pg
        t = ev.type
        if t == pg.QUIT:
            if self.parent_pid:
                self.hide()
            else:
                self.running = False
            return
        if t in (pg.MOUSEBUTTONDOWN, pg.MOUSEBUTTONUP, pg.MOUSEMOTION):
            ev_pos = self.to_logical(ev.pos)
        if t == getattr(pg, "WINDOWFOCUSLOST", -1):
            self.lose_focus()
            return
        if t == pg.MOUSEWHEEL and self.catalog:
            self.catalog["scroll"] = clamp(self.catalog["scroll"] - ev.y * 40, 0, self.catalog["max"])
            return
        if t == pg.KEYDOWN:
            if self.capturing and not IS_WIN:
                name = pg.key.name(ev.key)
                self._finish_capture(vk_of(name))
                return
            if self.modal:
                if ev.key in (pg.K_RETURN, pg.K_KP_ENTER):
                    self._modal_pick(0)
                elif ev.key == pg.K_ESCAPE:
                    self._modal_pick(len(self.modal["buttons"]) - 1)
                return
            if self.catalog:
                if self.focus:
                    self.focus.key(ev)
                elif ev.key == pg.K_ESCAPE:
                    self._cancel_catalog()
                elif ev.key in (pg.K_RETURN, pg.K_KP_ENTER):
                    self._accept_catalog()
                return
            if self.prevpop:
                if ev.key == pg.K_ESCAPE:
                    if self.prevpop["game"]:
                        self.prevpop["game"] = False        # Esc leaves the game view first, then closes
                    else:
                        self.close_prevpop()
                elif ev.key == pg.K_SPACE:      # only handled while the preview popup is open
                    self._pv_cycle_bg()
                return
            if self.dropdown:
                if ev.key == pg.K_ESCAPE:
                    self.dropdown = None
                return
            if self.focus:
                self.focus.key(ev)
            return
        if t == pg.TEXTINPUT:
            if self.focus and not self.modal:
                self.focus.textinput(ev.text)
            return
        if t == pg.MOUSEMOTION:
            for tb in self.active_tbs():
                tb.mouse_move(ev_pos)
            if self.drag_scale:
                self._scale_slider(ev_pos[0])
            if self.drag_sub:
                self._sub_slider(ev_pos[0])
            if self.catalog and self.catalog["drag"]:
                self._pop_slider(self.catalog["drag"], ev_pos[0])
        elif t == pg.MOUSEBUTTONUP and ev.button == 1:
            for tb in self.active_tbs():
                tb.mouse_up()
            self.drag_scale = self.drag_sub = False
            if self.catalog:
                self.catalog["drag"] = None
            if self.prevpop:
                self.prevpop["drag"] = None         # letting go sends the game picture back to the centre
            p, self.pressed = self.pressed, None
            if p:
                self._click_button(p, ev_pos)
        elif t == pg.MOUSEBUTTONDOWN:
            self._mouse_down(ev.button, ev_pos)

    def _modal_pick(self, i):
        cb = self.modal["buttons"][i][1]
        self.modal = None
        if cb:
            cb()

    def _finish_capture(self, vk):
        what, self.capturing = self.capturing, None
        if not vk:
            return
        name = VK_NAMES[vk]
        if what == "kb1":
            self.cfg.set(keyboard_key=name)
        elif what == "kb2":
            self.cfg.set(keyboard_key_2=name)
        elif what == "hotkey":
            self.cfg.set(ui_hotkey=name)
        self.sync_fields()

    def _mouse_down(self, button, pos):
        if self.modal:
            if button == 1:
                for i, r in enumerate(self.modal["rects"]):
                    if r.collidepoint(pos):
                        self.pressed = ("modal", i)
            return
        if self.catalog:
            if button == 1:
                self._catalog_click(pos)
            return
        if self.prevpop:
            if button == 1:
                self._prevpop_click(pos)
            return
        if self.dropdown:
            if button == 1:
                self._dropdown_click(pos)
            return
        if self.capturing:
            self.capturing = None
            return
        if button == 3 and self.r_preset.collidepoint(pos):
            self.do_import_preset()          # right click on Save Preset imports instead
            return
        if button == 3 and self.r_import.collidepoint(pos):
            self.do_reset_all()              # right click on Import Preset starts over
            return
        if button == 3 and self.r_short.collidepoint(pos):
            self.cfg.set(ui_hotkey="")
            self.sync_fields()
            return
        if button != 1:
            return
        hit_tb = None
        for tb in self.textboxes:
            if tb.rect.collidepoint(pos):
                hit_tb = tb
        if self.focus and self.focus is not hit_tb:
            self.focus.blur()
        if hit_tb:
            hit_tb.mouse_down(pos)
            return
        if self.r_sslider.inflate(0, 8).collidepoint(pos):
            self.drag_scale = True
            self._scale_slider(pos[0])
            return
        if self.r_ssub.inflate(0, 8).collidepoint(pos):
            self.drag_sub = True
            self._sub_slider(pos[0])
            return
        if self.r_ovchk.collidepoint(pos):
            self._override_toggle()
            return
        if self.r_outchk.inflate(110, 6).collidepoint(pos):
            self._outline_toggle()
            return
        if self.r_ovdot.collidepoint(pos):
            self.pick_color(self.tb_override)
            return
        if self.r_sneg.inflate(44, 6).collidepoint(pos):
            self._scale_flip()
            return
        r = self
        if r.r_markdd.collidepoint(pos) or r.r_markdot.collidepoint(pos):
            if self.inject_enabled():
                self.open_dropdown("markcolor", self.r_markdd, [n for n, _c in MARK_COLORS])
        elif r.r_outer.collidepoint(pos):
            self.open_catalog("outer")
        elif r.r_center.collidepoint(pos):
            self.open_catalog("center")
        elif r.r_prev.collidepoint(pos):
            self.open_prevpop()
        elif r.r_show.collidepoint(pos):
            self.cfg.set(show_marker=not self.show_marker)
            self.sync_fields()
        elif r.r_injsize.collidepoint(pos):
            if self.inject_enabled():
                self.open_dropdown("inject", self.r_injsize, [str(i) for i in range(INJECT_MIN, INJECT_MAX + 1)])
        elif r.r_mask.collidepoint(pos):
            self.open_dropdown("mask", self.r_mask, [str(i) for i in range(1, 7)])
        elif r.r_mouse.collidepoint(pos):
            self.open_dropdown("mouse", self.r_mouse, MOUSE_CHOICES)
        elif r.r_joy.collidepoint(pos):
            self.open_dropdown("joy", self.r_joy, JOY_CHOICES, row_h=30)
        elif r.r_kb1x.collidepoint(pos):
            self.cfg.set(keyboard_key="")
            self.sync_fields()
        elif r.r_kb2x.collidepoint(pos):
            self.cfg.set(keyboard_key_2="")
            self.sync_fields()
        elif r.r_kb1.collidepoint(pos):
            self._start_capture("kb1")
        elif r.r_kb2.collidepoint(pos):
            self._start_capture("kb2")
        elif r.r_short.collidepoint(pos):
            self._start_capture("hotkey")
        else:
            for key, rect, ok in (("browse", self.r_browse, True),
                                  ("unlock", self.r_unlock, self.unlock_enabled()),
                                  ("inject", self.r_inject, self.inject_enabled()),
                                  ("apply", self.r_apply, self.apply_enabled()),
                                  ("preset", self.r_preset, True),
                                  ("import", self.r_import, True),
                                  ("adjust", self.r_adjust, self.adjust_enabled()),
                                  ("close", self.r_close, True)):
                if rect.collidepoint(pos) and ok:
                    self.pressed = key
                    return
            if self.r_unlock.collidepoint(pos) and not self.unlock_enabled():
                self._why_disabled()
            elif (self.r_apply.collidepoint(pos) or self.r_adjust.collidepoint(pos)) and not self.ready():
                self.post(self.idle_hint())

    def _why_disabled(self):
        if not self.paths:
            self.post("Select steam.exe first so the game files can be found.")
        elif self.game_run:
            self.post("Close the game first: its files cannot be changed while it is running.")
        elif self.busy:
            self.post("Working on the game files, one moment...")
        elif self.sha == "off" and not self.sha_backup:
            self.run_task("Looking for the original files...", self._no_backup_go)

    def _no_backup_go(self):
        msg = "The SHA were already modified, no backup found."
        try:
            if restore_upk(self.paths[0], self.build):
                msg += " UI_HUD_SF.upk has been restored."
        except MakerError as e:
            msg += " Could not restore UI_HUD_SF.upk (%s)." % e
        return msg

    def _click_button(self, p, pos):
        if isinstance(p, tuple):
            if self.modal and self.modal["rects"][p[1]].collidepoint(pos):
                self._modal_pick(p[1])
            return
        rect = {"browse": self.r_browse, "unlock": self.r_unlock, "inject": self.r_inject, "apply": self.r_apply,
                "preset": self.r_preset, "import": self.r_import, "adjust": self.r_adjust, "close": self.r_close}[p]
        if not rect.collidepoint(pos):
            return
        {"browse": self.do_browse, "unlock": self.do_unlock, "inject": self.do_inject, "apply": self.do_apply,
         "preset": self.do_save_preset, "import": self.do_import_preset, "adjust": self.do_adjust, "close": self.hide}[p]()

    def _start_capture(self, what):
        self.capturing = what
        self.cap_released = not (IS_WIN and scan_pressed_key())
        self.post("Press the key to use (Esc cancels).")

    def open_dropdown(self, name, rect, items, row_h=24):
        h = len(items) * row_h + 2
        top = rect.bottom + 1
        if top + h > H - 4:
            top = max(4, rect.top - h - 1)
        w = max(rect.w, 70 if name != "joy" else rect.w)
        self.dropdown = {"name": name, "items": items, "rect": pygame.Rect(rect.x, top, w, h), "row_h": row_h}

    def _dropdown_click(self, pos):
        d, self.dropdown = self.dropdown, None
        if not d["rect"].collidepoint(pos):
            return
        i = (pos[1] - d["rect"].y - 1) // d["row_h"]
        if not (0 <= i < len(d["items"])):
            return
        item = d["items"][i]
        n = d["name"]
        if n == "markcolor":
            self.mark_sel = dict(MARK_COLORS)[item]
        elif n == "inject":
            self.inject_size = int(item)
        elif n == "mask":
            self.cfg.set(marker_size=int(item))
        elif n == "mouse":
            self.cfg.set(mouse_key=item)
        elif n == "joy":
            self.cfg.set(joystick_key=item)
        self.sync_fields()

    # ------------------------------------------------------------------ per-frame
    def update(self):
        now = time.time()
        if self.sock:
            try:
                while True:
                    data, _ = self.sock.recvfrom(256)
                    self.command(data.decode("utf-8", "ignore"))
            except (BlockingIOError, OSError):
                pass
        try:
            while True:
                self.post(self.msgs.get_nowait())
        except queue.Empty:
            pass
        if now - self.last_parent > 1.0:
            self.last_parent = now
            if self.parent_pid and not pid_alive(self.parent_pid):
                self.running = False
        if now - self.last_reload > 0.5:
            self.last_reload = now
            if self.cfg.reload():
                self.sync_fields()
        # game / UPK / SHA state only matters while the window is on screen (show() forces a fresh poll)
        if self.visible and now - self.last_poll > 1.5:
            self.last_poll = now
            was = self.game_run
            self.game_run = game_running()
            self.injected = self.check_injected()
            if was and not self.game_run:
                self.refresh_sha()
        self.update_passthrough(now)
        if self.capturing and IS_WIN:
            if esc_down():
                self.capturing = None
                self.post("Cancelled.")
            else:
                vk = scan_pressed_key()
                if not vk:
                    self.cap_released = True
                elif self.cap_released:
                    self._finish_capture(vk)

    def draw_text(self, font, txt, color, x, y, anchor="l"):
        img = font.render(txt, True, color)
        r = img.get_rect()
        if anchor == "l":
            r.midleft = (x, y)
        elif anchor == "r":
            r.midright = (x, y)
        else:
            r.center = (x, y)
        self.canvas.blit(img, r)

    def button(self, rect, label, enabled, mouse, key=None, red=False):
        scr = self.canvas
        if not enabled:
            fill, line, fg = (C_RED if red else C_BTN), C_OFF_LINE, C_OFF_TEXT
        elif key and self.pressed == key and rect.collidepoint(mouse):
            fill, line, fg = C_BTN_DOWN, C_BTN_LINE, C_TEXT
        elif rect.collidepoint(mouse):
            fill, line, fg = (C_RED_HOT if red else C_BTN_HOT), (230, 230, 230) if red else C_BTN_LINE, C_TEXT
        else:
            fill, line, fg = (C_RED if red else C_BTN), ((242, 242, 242) if red else (50, 50, 56)), C_TEXT
        pygame.draw.rect(scr, fill, rect)
        pygame.draw.rect(scr, line, rect, 1)
        self.draw_text(self.f_btn, label, fg, rect.centerx, rect.centery, "c")

    def dropdown_box(self, rect, label, mouse, enabled=True, icon=None):
        scr = self.canvas
        pygame.draw.rect(scr, C_INPUT_FILL, rect)
        pygame.draw.rect(scr, (110, 110, 120) if rect.collidepoint(mouse) and enabled else C_INPUT_LINE, rect, 1)
        col = C_INPUT_TEXT if enabled else C_OFF_TEXT
        if icon is not None:
            scr.blit(icon, icon.get_rect(center=(rect.centerx - 6, rect.centery)))
        else:
            self.draw_text(self.f_in, label, col, rect.x + 9, rect.centery)
        ax, ay = rect.right - 10, rect.centery
        pygame.draw.polygon(scr, col, [(ax - 4, ay - 2), (ax + 4, ay - 2), (ax, ay + 3)])

    def dot(self, rect, color, mouse):
        c = rect.center
        pygame.draw.circle(self.canvas, color, c, rect.w // 2 - 2)
        pygame.draw.circle(self.canvas, (235, 235, 235) if rect.collidepoint(mouse) else (60, 60, 64), c,
                           rect.w // 2 - 1, 2)

    def draw(self):
        scr = self.canvas
        pg = self.pg
        mouse = self.to_logical(pg.mouse.get_pos()) if pg.mouse.get_focused() else (-1, -1)
        blocked = bool(self.modal or self.catalog or self.dropdown or self.prevpop)
        m = (-1, -1) if blocked else mouse
        if self.bg:
            scr.blit(self.bg, (0, 0))
        else:
            scr.fill((20, 20, 22))
        L = self.draw_text
        # separators
        sep = lambda x0, y, x1: pygame.draw.line(scr, C_SEP, (x0, int(round(y - Y0))), (x1, int(round(y - Y0))), 2)
        sep(14, 236.8, 316)
        sep(329, 335.9, 586)
        sep(14, 515.6 + DY, 586)
        pygame.draw.line(scr, C_SEP, (322, 8), (322, int(round(515.6 - Y0 + DY))), 2)

        # steam
        L(self.f_lbl, "steam.exe", C_LABEL, 131, int(95 - Y0) - 5, "c")
        pygame.draw.rect(scr, C_INPUT_FILL, self.r_steam)
        pygame.draw.rect(scr, C_INPUT_LINE, self.r_steam, 1)
        st = self.steam_exe or "..."
        while self.f_in.size(st)[0] > self.r_steam.w - 16 and len(st) > 4:
            st = "..." + st[4:]
        L(self.f_in, st, C_INPUT_TEXT if self.steam_exe else C_LABEL_DIM, self.r_steam.x + 8, self.r_steam.centery)
        self.button(self.r_browse, "Browse", True, m, "browse")
        unlock_label = "Restore SHA" if self.sha == "off" else "Unlock SHA"
        self.button(self.r_unlock, unlock_label, self.unlock_enabled(), m, "unlock")
        self.button(self.r_inject, "Reinject Mark" if self.injected else "Inject Mark", self.inject_enabled(), m, "inject")
        self.dropdown_box(self.r_injsize, str(self.inject_size), m, self.inject_enabled())
        L(self.f_lbl, "px", C_LABEL, self.r_injsize.right + 5, self.r_injsize.centery)
        L(self.f_lbl, "Mark Color", C_LABEL_DIM, 18, self.r_markdd.centery)
        self.dropdown_box(self.r_markdd, self.mark_color_name(), m, self.inject_enabled())
        self.dot(self.r_markdot, self.mark_sel, m)

        # sight selectors: Outer | Preview | Center
        pv = self.make_preview()
        for rect, label, kind in ((self.r_outer, "Outer", "outer"), (self.r_prev, "Preview", None),
                                  (self.r_center, "Center", "center")):
            L(self.f_small, label, C_LABEL, rect.centerx, rect.y - 9, "c")
            hot = kind is not None and rect.collidepoint(m)
            pygame.draw.rect(scr, (0, 0, 0), rect, border_radius=8)
            clip = scr.get_clip()
            if kind is None:
                scr.set_clip(rect.inflate(-6, -6))
                if pv:
                    scr.blit(pv, pv.get_rect(center=rect.center))
            else:
                scr.set_clip(pygame.Rect(rect.x + 3, rect.y + 3, rect.w - 6, rect.h - 24))
                ps = self.part_surface(kind)
                if ps:
                    scr.blit(ps, ps.get_rect(center=(rect.centerx, rect.y + (rect.h - 18) // 2)))
            scr.set_clip(clip)
            if kind is not None:
                tab = pygame.Rect(rect.x + 2, rect.bottom - 20, rect.w - 4, 18)
                pygame.draw.rect(scr, (96, 96, 100) if hot else (74, 74, 78), tab, border_bottom_left_radius=6,
                                 border_bottom_right_radius=6)
                pygame.draw.polygon(scr, (240, 240, 240), [(tab.centerx - 5, tab.centery - 3),
                                                           (tab.centerx + 5, tab.centery - 3),
                                                           (tab.centerx, tab.centery + 4)])
            pygame.draw.rect(scr, (130, 130, 136) if hot else (62, 62, 66), rect, 2, border_radius=8)

        L(self.f_lbl, "Scale Adjust", C_LABEL_DIM, 7, self.tb_scale.rect.centery)
        self.tb_scale.draw(scr, self.f_in)
        sg = self.r_sslider
        pygame.draw.line(scr, (205, 205, 205), (sg.x, sg.centery), (sg.right, sg.centery), 2)
        pygame.draw.circle(scr, (240, 240, 240), (sg.x + int(sg.w * clamp(abs(self.scale), 0, 100) / 100.0), sg.centery), 6)
        nb = self.r_sneg
        pygame.draw.rect(scr, (245, 245, 245) if self.scale_neg else C_INPUT_FILL, nb)
        pygame.draw.rect(scr, (240, 240, 240), nb, 1)
        if self.scale_neg:
            pygame.draw.lines(scr, (20, 20, 20), False, [(nb.x + 3, nb.centery), (nb.x + 7, nb.bottom - 4),
                                                        (nb.right - 3, nb.y + 4)], 2)
        L(self.f_lbl, "neg.", C_LABEL_DIM, nb.right + 6, nb.centery)
        oc = self.r_ovchk
        pygame.draw.rect(scr, (245, 245, 245) if self.ov_on else C_INPUT_FILL, oc)
        pygame.draw.rect(scr, (240, 240, 240), oc, 1)
        if self.ov_on:
            pygame.draw.lines(scr, (20, 20, 20), False, [(oc.x + 3, oc.centery), (oc.x + 7, oc.bottom - 4),
                                                        (oc.right - 3, oc.y + 4)], 2)
        L(self.f_lbl, "Override Color", C_LABEL_DIM if self.ov_on else C_OFF_TEXT, oc.right + 6, oc.centery)
        self.tb_override.draw(scr, self.f_in)
        self.dot(self.r_ovdot, parse_rgb_strict(self.tb_override.text) or self.tb_override.value, m)
        L(self.f_lbl, "Subtract Opacity", C_LABEL_DIM, 10, self.tb_sub.rect.centery)
        self.tb_sub.draw(scr, self.f_in)
        ss = self.r_ssub
        pygame.draw.line(scr, (205, 205, 205), (ss.x, ss.centery), (ss.right, ss.centery), 2)
        pygame.draw.circle(scr, (240, 240, 240), (ss.x + int(ss.w * clamp(self.sub_op, 0, 100) / 100.0), ss.centery), 6)
        ob = self.r_outchk
        pygame.draw.rect(scr, (245, 245, 245) if self.outline_on else C_INPUT_FILL, ob)
        pygame.draw.rect(scr, (240, 240, 240), ob, 1)
        if self.outline_on:
            pygame.draw.lines(scr, (20, 20, 20), False, [(ob.x + 3, ob.centery), (ob.x + 7, ob.bottom - 4),
                                                        (ob.right - 3, ob.y + 4)], 2)
        L(self.f_lbl, "Post Outline", C_LABEL_DIM if self.outline_on else C_OFF_TEXT, ob.right + 6, ob.centery)
        self.button(self.r_apply, "Apply", self.apply_enabled(), m, "apply")
        self.button(self.r_preset, "Save Preset", True, m, "preset")
        self.button(self.r_import, "Import Preset", True, m, "import")
        self.button(self.r_adjust, "Cancel Adjust" if self.engine.adjusting else "Start Adjust", self.adjust_enabled(), m, "adjust")

        # right panel
        lx = 482
        L(self.f_lbl, "Show Marker", C_LABEL_DIM, lx + 2, self.r_show.centery, "r")
        pygame.draw.rect(scr, (245, 245, 245) if self.show_marker else C_INPUT_FILL, self.r_show)
        pygame.draw.rect(scr, (240, 240, 240), self.r_show, 2)
        if self.show_marker:
            c = self.r_show.center
            pygame.draw.lines(scr, (20, 20, 20), False, [(c[0] - 6, c[1]), (c[0] - 2, c[1] + 5), (c[0] + 6, c[1] - 6)], 3)
        for text, tb in (("Reticle Deviation x", self.tb_devx), ("Reticle Deviation y", self.tb_devy),
                         ("Mark Color Range", self.tb_range), ("Mark Fade Delay", self.tb_fade),
                         ("Mark Sample Delay", self.tb_sample)):
            L(self.f_lbl, text, C_LABEL_DIM, lx, tb.rect.centery, "r")
            tb.draw(scr, self.f_in)
        L(self.f_lbl, "Mark  Mask Size", C_LABEL_DIM, lx, self.r_mask.centery, "r")
        self.dropdown_box(self.r_mask, str(self.mask_size), m)
        L(self.f_lbl, "px", C_LABEL, self.r_mask.right + 5, self.r_mask.centery)
        L(self.f_lbl, "Mouse key", C_LABEL_DIM, lx, self.r_mouse.centery, "r")
        self.dropdown_box(self.r_mouse, self.mouse_key, m)
        for text, rect, xr, val, cap in (("Keyboard key", self.r_kb1, self.r_kb1x, self.kb1, "kb1"),
                                          ("Keyboard key 2", self.r_kb2, self.r_kb2x, self.kb2, "kb2")):
            L(self.f_lbl, text, C_LABEL_DIM, lx, rect.centery, "r")
            pygame.draw.rect(scr, C_INPUT_FILL, rect)
            pygame.draw.rect(scr, (140, 140, 150) if self.capturing == cap else C_INPUT_LINE, rect, 1)
            shown = "..." if self.capturing == cap else (val or "...")
            L(self.f_in, shown, C_INPUT_TEXT if val and self.capturing != cap else C_LABEL_DIM, rect.centerx,
              rect.centery, "c")
            on = bool(val)
            pygame.draw.rect(scr, (176, 38, 38) if on else (58, 58, 62), xr)
            pygame.draw.rect(scr, (230, 230, 230) if on else (90, 90, 94), xr, 1)
            L(self.f_btn, "X", (255, 255, 255) if on else (130, 130, 134), xr.centerx, xr.centery, "c")
        L(self.f_lbl, "Joystick key", C_LABEL_DIM, lx, self.r_joy.centery, "r")
        icon = self.joy_icon(self.joy_key, 24) if self.joy_key != "None" else None
        self.dropdown_box(self.r_joy, "None", m, icon=icon)

        # bottom
        pygame.draw.rect(scr, (8, 8, 9), self.r_msgbox)
        pygame.draw.rect(scr, (60, 60, 64), self.r_msgbox, 1)
        fresh = bool(self.message) and time.time() - self.msg_time < 10.0
        text = self.message if fresh else self.idle_hint()
        lines = self._wrap(text, self.r_msgbox.w - 24)[:3]
        lh = self.f_msg.get_linesize()
        y = self.r_msgbox.centery - lh * len(lines) // 2 + lh // 2
        for ln in lines:
            L(self.f_msg, ln, C_TEXT if fresh else C_LABEL_DIM, self.r_msgbox.centerx, y, "c")
            y += lh
        sc = "Press a key..." if self.capturing == "hotkey" else "Shortcut: %s" % (self.ui_hotkey or "...")
        L(self.f_lbl, sc, C_TEXT if self.r_short.collidepoint(m) or self.capturing == "hotkey" else C_LABEL_DIM,
          self.r_short.centerx, self.r_short.centery, "c")
        self.button(self.r_close, "Close", True, m, "close", red=True)

        # overlays
        if self.dropdown:
            self._draw_dropdown(mouse)
        if self.catalog:
            self._draw_catalog(mouse)
        if self.prevpop:
            self._draw_prevpop(mouse)
        if self.modal:
            self._draw_modal(mouse)

    def _wrap(self, text, width):
        words, lines, cur = text.split(), [], ""
        for w in words:
            t = (cur + " " + w).strip()
            if self.f_msg.size(t)[0] <= width or not cur:
                cur = t
            else:
                lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
        return lines or [""]

    def _draw_dropdown(self, mouse):
        d = self.dropdown
        scr = self.canvas
        pygame.draw.rect(scr, (10, 10, 12), d["rect"])
        pygame.draw.rect(scr, (140, 140, 150), d["rect"], 1)
        for i, item in enumerate(d["items"]):
            r = pygame.Rect(d["rect"].x + 1, d["rect"].y + 1 + i * d["row_h"], d["rect"].w - 2, d["row_h"])
            if r.collidepoint(mouse):
                pygame.draw.rect(scr, C_BTN_HOT, r)
            if d["name"] == "markcolor":
                pygame.draw.circle(scr, dict(MARK_COLORS)[item], (r.x + 14, r.centery), 7)
                pygame.draw.circle(scr, (90, 90, 96), (r.x + 14, r.centery), 7, 1)
                self.draw_text(self.f_in, item, C_INPUT_TEXT, r.x + 28, r.centery)
            elif d["name"] == "joy" and item != "None":
                ic = self.joy_icon(item, 22)
                scr.blit(ic, ic.get_rect(center=r.center))
            else:
                self.draw_text(self.f_in, item, C_INPUT_TEXT, r.x + 9, r.centery)

    def make_modal(self, text, buttons):
        bw = 400
        lines = self._wrap(text, bw - 40)
        lh = self.f_msg.get_linesize()
        bh = 24 + lh * len(lines) + 24 + 34 + 20
        box = pygame.Rect(0, 0, bw, bh)
        box.center = (W // 2, H // 2)
        n = len(buttons)
        bwid, gap = 130, 14
        x0 = box.centerx - (n * bwid + (n - 1) * gap) // 2
        self.dropdown = self.catalog = None
        self.close_prevpop()
        self.modal = {"buttons": buttons, "box": box, "lines": lines,
                      "rects": [pygame.Rect(x0 + i * (bwid + gap), box.bottom - 20 - 34, bwid, 34) for i in range(n)]}

    def _draw_modal(self, mouse):
        scr = self.canvas
        m = self.modal
        dim = pygame.Surface((W, H), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 170))
        scr.blit(dim, (0, 0))
        pygame.draw.rect(scr, (24, 24, 28), m["box"])
        pygame.draw.rect(scr, (110, 110, 118), m["box"], 1)
        y = m["box"].y + 24 + self.f_msg.get_linesize() // 2
        for ln in m["lines"]:
            self.draw_text(self.f_msg, ln, C_TEXT, m["box"].centerx, y, "c")
            y += self.f_msg.get_linesize()
        for i, ((label, _cb), r) in enumerate(zip(m["buttons"], m["rects"])):
            self.button(r, label, True, mouse, ("modal", i))


    # ------------------------------------------------------------------ actual-size preview popup
    def open_prevpop(self):
        if self.final_image() is None:
            self.post("Select at least one reticle (Outer or Center) first.")
            return
        self.dropdown = None
        self.prevpop = {"white": False, "game": False, "drag": None}
        self.cat_rect = pygame.Rect(8, 6, W - 16, H - 12)
        self.pv_sand = pygame.Rect(self.cat_rect.x + 14, self.cat_rect.y + 38, self.cat_rect.w - 28,
                                   self.cat_rect.h - 38 - 56)
        self.pv_white = pygame.Rect(self.cat_rect.x + 14, self.cat_rect.bottom - 38, 14, 14)
        self.pv_close = pygame.Rect(self.cat_rect.right - 14 - 110, self.cat_rect.bottom - 46, 110, 32)
        self.pv_save = pygame.Rect(self.cat_rect.x + 14 + 14 + 8 + 74 + 14, self.cat_rect.bottom - 46, 120, 32)
        self.pv_import = pygame.Rect(self.pv_save.right + 8, self.cat_rect.bottom - 46, 130, 32)
        self._pv_say("")

    def close_prevpop(self):
        if self.prevpop:
            self.prevpop = None
        self._set_cursor_hidden(False)

    def _pv_cycle_bg(self):
        """Space: black -> white -> game picture (only when one was taken) -> black."""
        p = self.prevpop
        if p["game"]:
            p["game"], p["white"] = False, False
        elif not p["white"]:
            p["white"] = True
        else:
            if self.snap is None:
                self._take_snap()           # none yet (window opened without the game in front): try once more
            if self.snap is not None:
                p["game"] = True
            else:
                p["white"] = False
                self._pv_say("No game picture: %s" % (self.snap_why or "unavailable"), True, 4)

    @staticmethod
    def _game_offset(delta, box, img):
        """The game picture follows a drag. It never leaves the sandbox uncovered: once one of its edges meets
        the matching sandbox edge it stops moving that way."""
        return [max(-lim, min(lim, d)) for d, lim in ((delta[0], max(0.0, (img[0] - box.w) / 2.0)),
                                                       (delta[1], max(0.0, (img[1] - box.h) / 2.0)))]

    def _pv_snap_surface(self):
        if self.snap is None:
            return None
        if self._snap_surf is None:
            h, w = self.snap.shape[:2]
            self._snap_surf = self.pg.image.frombuffer(self.snap.tobytes(), (w, h), "RGB").convert()
        return self._snap_surf

    def _prevpop_click(self, pos):
        if self.prevpop["game"] and self.pv_sand.collidepoint(pos):
            self.prevpop["drag"] = self.pg.mouse.get_pos()          # the picture moves from where it is now
        elif self.pv_close.collidepoint(pos):
            self.close_prevpop()
        elif self.pv_import.collidepoint(pos):
            self.do_import_preview()
        elif self.pv_save.collidepoint(pos):
            if self.preview_unsaved():
                self.do_save_preview()
        elif self.pv_white.inflate(90, 8).collidepoint(pos):
            if not self.prevpop["game"]:        # the checkbox only switches black / white
                self.prevpop["white"] = not self.prevpop["white"]

    def _pv_surface(self):
        """The finished reticle exactly as Apply would write it (pixel for pixel)."""
        fin = self.finished()
        if fin is None:
            return None
        key = id(fin)
        if self._pv_cache[0] != key:
            from PIL import Image
            img = Image.fromarray(np.ascontiguousarray(fin), "RGBA")
            self._pv_cache = (key, self.pg.image.frombuffer(img.tobytes(), img.size, "RGBA").convert_alpha())
        return self._pv_cache[1]

    def _draw_prevpop(self, mouse):
        scr = self.canvas
        dim = pygame.Surface((W, H), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 170))
        scr.blit(dim, (0, 0))
        pygame.draw.rect(scr, (14, 14, 16), self.cat_rect)
        pygame.draw.rect(scr, (110, 110, 118), self.cat_rect, 1)
        surf = self._pv_surface()
        info = "%d x %d px" % surf.get_size() if surf else ""
        self.draw_text(self.f_lbl, "Preview (actual size)", C_TEXT, self.cat_rect.x + 14, self.cat_rect.y + 16)
        self.draw_text(self.f_small, info, C_LABEL_DIM, self.cat_rect.right - 14, self.cat_rect.y + 16, "r")
        white, game = self.prevpop["white"], self.prevpop["game"]
        pygame.draw.rect(scr, (255, 255, 255) if white and not game else (0, 0, 0), self.pv_sand)
        pygame.draw.rect(scr, (110, 110, 118), self.pv_sand, 1)
        cb = self.pv_white
        pygame.draw.rect(scr, (245, 245, 245) if white else C_INPUT_FILL, cb)
        pygame.draw.rect(scr, (210, 210, 210), cb, 1)
        if white:
            pygame.draw.lines(scr, (20, 20, 20), False, [(cb.x + 3, cb.centery), (cb.x + 6, cb.bottom - 4),
                                                        (cb.right - 3, cb.y + 3)], 2)
        self.draw_text(self.f_lbl, "White bg", C_LABEL_DIM if game else C_LABEL, cb.right + 8, cb.centery)
        self.button(self.pv_save, "Save Reticle", self.preview_unsaved(), mouse, "psave")
        self.button(self.pv_import, "Import Reticle", True, mouse, "pimport")
        if self.pv_note_until and time.time() > self.pv_note_until:
            self._pv_say("")
        hint = self.pv_note or ("Game view: drag to look around - Esc / Space to leave" if game else
                                "Space: black / white / game")
        self.draw_text(self.f_small, hint, (235, 70, 70) if self.pv_note and self.pv_note_red else C_LABEL_DIM,
                       self.cat_rect.x + 220, self.cat_rect.y + 16)
        self.button(self.pv_close, "Close", True, mouse, "pclose")
        # inside the sandbox the mouse is hidden and the reticle itself follows it (drawn in render() at real pixels)

    def _sandbox_phys(self):
        """Sandbox rectangle in window pixels and the mouse position in window pixels (None outside)."""
        ww, wh = self.window.get_size()
        fx, fy = ww / float(W), wh / float(H)
        r = self.pv_sand
        box = pygame.Rect(int(r.x * fx) + 1, int(r.y * fy) + 1, int(r.w * fx) - 2, int(r.h * fy) - 2)
        if not self.pg.mouse.get_focused():
            return box, None
        mp = self.pg.mouse.get_pos()
        return box, (mp if box.collidepoint(mp) else None)

    def _set_cursor_hidden(self, hide):
        if hide != self._cur_hidden:
            self._cur_hidden = hide
            try:
                self.pg.mouse.set_visible(not hide)
            except Exception:
                pass

    def _idle_wait(self, secs):
        try:
            if self.sock:
                select.select([self.sock], [], [], secs)
                return
        except (OSError, ValueError):
            pass
        time.sleep(secs)

    def render(self):
        self.draw()
        if self.S == 1.0:
            self.window.blit(self.canvas, (0, 0))
        else:
            self.pg.transform.smoothscale(self.canvas, self.window.get_size(), self.window)
        if self.prevpop and not self.modal:
            box, mp = self._sandbox_phys()
            gs = self._pv_snap_surface() if self.prevpop["game"] else None
            self._set_cursor_hidden(mp is not None and gs is None)      # game view keeps the normal mouse
            surf = self._pv_surface()
            if gs is not None:
                # game view: the reticle stays in the middle of the sandbox; holding the mouse button drags the
                # game picture around under it, and it returns to the centre when released
                drag = self.prevpop["drag"]
                cur = self.pg.mouse.get_pos()
                dx, dy = self._game_offset((cur[0] - drag[0], cur[1] - drag[1]) if drag else (0, 0), box, gs.get_size())
                clip = self.window.get_clip()
                self.window.set_clip(box)
                self.window.fill((0, 0, 0), box)
                self.window.blit(gs, gs.get_rect(center=(int(box.centerx + dx), int(box.centery + dy))))
                if surf is not None:
                    self.window.blit(surf, surf.get_rect(center=box.center))
                self.window.set_clip(clip)
            elif mp is not None and surf is not None:
                clip = self.window.get_clip()
                self.window.set_clip(box)
                self.window.blit(surf, surf.get_rect(center=mp))
                self.window.set_clip(clip)
        else:
            self._set_cursor_hidden(False)
        self.pg.display.flip()

    def run(self):
        pg = self.pg
        hot_until = last_draw = 0.0
        was_visible = False
        try:
            while self.running:
                self.update()
                evs = pg.event.get()
                for ev in evs:
                    self.handle(ev)
                now = time.time()
                if evs or self.focus or self.catalog and self.catalog.get("drag"):
                    hot_until = now + 0.6      # input just happened: keep drawing at full speed
                if self.visible:
                    # redraw at ~60 fps while something is happening, otherwise only a few times a second
                    # (status text, message flush); an idle window costs almost no CPU
                    if now < hot_until or now - last_draw > 0.25 or not was_visible:
                        self.render()
                        last_draw = now
                    pg.time.wait(16 if now < hot_until else 40)
                else:
                    # hidden: no drawing, no polling; sleep on the command socket so a hotkey wakes it at once
                    self._idle_wait(0.25)
                was_visible = self.visible
        finally:
            self.engine.stop()
            try:
                self.engine.join(1.0)
            except RuntimeError:
                pass
            pg.quit()


def Path_(p):
    from pathlib import Path
    return Path(p)


def run_ui(parent_pid=0, port=0, hidden=False):
    if IS_WIN:
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
        except Exception:
            pass
        Win.dpi_aware()
    ReticleUI(parent_pid, port, hidden).run()
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    pid = port = 0
    hidden = False
    args = [a for a in argv if a != "--reticle-ui"]
    for a in args:
        if a == "hidden":
            hidden = True
        elif a.isdigit():
            if not pid:
                pid = int(a)
            else:
                port = int(a)
    return run_ui(pid, port, hidden)


if __name__ == "__main__":
    sys.exit(main())