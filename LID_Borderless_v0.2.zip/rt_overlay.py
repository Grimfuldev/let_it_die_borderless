"""In-game overlay: mark detection / blur fill, the Windows click-through layered window, XInput, banner and the Engine thread."""
import ctypes
import math
import os
import threading
import time
from rt_core import (
    CURRENT_DIR,
    Config,
    GAME_EXE,
    IS_WIN,
    JOY_BITS,
    current_name,
    load_current,
)
import numpy as np


FPS = 0
PAD = 3
SUPERSAMPLE = 4
MAX_MARKER_PX = 14


def color_match(px, color, dev):
    d = np.abs(px[..., :3].astype(np.int16) - np.array(color, np.int16))
    return d.max(axis=-1) <= dev


def find_dot(frames, idle, color, dev, max_size=MAX_MARKER_PX):
    if not isinstance(frames, (list, tuple)):
        frames = [frames]
    f = None
    for fr in frames:
        m = color_match(fr, color, dev)
        f = m if f is None else (f & m)
    white = f.copy()
    if idle is not None and idle.shape[:2] == f.shape:
        white &= ~color_match(idle, color, dev + 40)
    ys, xs = np.nonzero(white)
    if len(xs) == 0:
        return None, "no new marker-coloured pixel that stays put - is the reticle showing while you hold the button?"
    if len(xs) > 4000:
        return None, "too many marker-coloured pixels in view - aim at a darker part of the scene"
    pts = set(zip(xs.tolist(), ys.tolist()))
    seen, best = set(), None
    h, w = f.shape
    cx0, cy0 = w / 2.0, h / 2.0
    for p in pts:
        if p in seen:
            continue
        stack, comp = [p], []
        seen.add(p)
        while stack:
            x, y = stack.pop()
            comp.append((x, y))
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    q = (x + dx, y + dy)
                    if q in pts and q not in seen:
                        seen.add(q)
                        stack.append(q)
        cxs, cys = [c[0] for c in comp], [c[1] for c in comp]
        x0, x1, y0, y1 = min(cxs), max(cxs), min(cys), max(cys)
        bw, bh = x1 - x0 + 1, y1 - y0 + 1
        if bw > max_size or bh > max_size or x0 < 2 or y0 < 2 or x1 > w - 3 or y1 > h - 3:
            continue
        ring = int(f[y0 - 2:y1 + 3, x0 - 2:x1 + 3].sum()) - len(comp)
        if ring > 1:
            continue
        mx, my = (x0 + x1 + 1) / 2.0, (y0 + y1 + 1) / 2.0
        d = math.hypot(mx - cx0, my - cy0)
        if best is None or d < best[0]:
            best = (d, (mx, my, bw, bh))
    if best is None:
        return None, "marker-coloured pixels were found but none looks like the small isolated marker"
    return best[1], ""


def build_rect_coverage(bw, bh, margin, fx, fy, half):
    n = 2 * half + 2
    S = SUPERSAMPLE
    c = (np.arange(n * S) + 0.5) / S
    inside = (np.abs(c[None, :] - (half + fx)) <= bw / 2.0 + margin) & \
             (np.abs(c[:, None] - (half + fy)) <= bh / 2.0 + margin)
    return inside.reshape(n, S, n, S).mean(axis=(1, 3))


class BlurFill:

    def __init__(self, cov):
        h, w = cov.shape
        self.h, self.w = h, w
        unk = cov > 0
        ys, xs = np.nonzero(unk)
        n = len(xs)
        uid = np.full((h, w), -1, np.int64)
        uid[ys, xs] = np.arange(n)
        A = np.zeros((n, n))
        kr, kc, kw = [], [], []
        for dx, dy, wgt in ((1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
                           (1, 1, .5), (1, -1, .5), (-1, 1, .5), (-1, -1, .5)):
            nx, ny = xs + dx, ys + dy
            ok = (nx >= 0) & (ny >= 0) & (nx < w) & (ny < h)
            i = np.nonzero(ok)[0]
            A[i, i] += wgt
            inner = unk[ny[i], nx[i]]
            ii = i[inner]
            A[ii, uid[ny[ii], nx[ii]]] -= wgt
            io = i[~inner]
            kr.append(io)
            kc.append(ny[io] * w + nx[io])
            kw.append(np.full(len(io), wgt))
        kr, kc, kw = np.concatenate(kr), np.concatenate(kc), np.concatenate(kw)
        self.kidx, col = np.unique(kc, return_inverse=True)
        B = np.zeros((n, len(self.kidx)))
        np.add.at(B, (kr, col), kw)
        self.W = np.linalg.solve(A, B).astype(np.float32)
        self.n = n
        self.ys, self.xs = ys, xs
        self.unk = (ys * w + xs).astype(np.intp)
        self.alpha8 = np.rint(cov[ys, xs] * 255).astype(np.uint8)
        self.alpha_f = (self.alpha8.astype(np.float32) / 255.0)[:, None]

    def colors(self, cap_flat):
        return (self.W @ cap_flat[self.kidx, :3].astype(np.float32)) * self.alpha_f


class Layout:

    def __init__(self, dot, cfg, png):
        cx, cy = dot[0], dot[1]
        bw = bh = cfg.size
        self.anchor_off = (math.floor(cx), math.floor(cy))
        fx, fy = round(cx - math.floor(cx), 3), round(cy - math.floor(cy), 3)
        half = int(math.ceil(bw / 2.0)) + PAD
        self.half = half
        self.fill = BlurFill(build_rect_coverage(bw, bh, 0, fx, fy, half))
        n = self.n = 2 * half + 2
        mx0, my0 = -half, -half
        x0, y0, x1, y1 = mx0, my0, mx0 + n, my0 + n
        self.png = png
        if png is not None:
            rh, rw = png.shape[:2]
            rx = int(round(fx + cfg.off_x)) - rw // 2
            ry = int(round(fy + cfg.off_y)) - rh // 2
            x0, y0, x1, y1 = min(x0, rx), min(y0, ry), max(x1, rx + rw), max(y1, ry + rh)
        self.W, self.H = x1 - x0, y1 - y0
        self.win_off = (x0, y0)
        self.cap_off = (mx0, my0)
        base = np.zeros((self.H, self.W, 4), np.uint8)
        if png is not None:
            base[ry - y0:ry - y0 + rh, rx - x0:rx - x0 + rw] = png
        self.base = base.reshape(-1, 4)
        ys, xs = self.fill.ys + (my0 - y0), self.fill.xs + (mx0 - x0)
        self.win_idx = (ys * self.W + xs).astype(np.intp)
        ar = self.base[self.win_idx, 3].astype(np.float32) / 255.0
        self.base_rgb = self.base[self.win_idx, :3].astype(np.float32)
        self.inv_ar = (1.0 - ar)[:, None]
        ap = self.fill.alpha8.astype(np.float32) / 255.0
        self.alpha_final = np.rint((ar + ap * (1.0 - ar)) * 255).astype(np.uint8)
        gx, gy = np.meshgrid(np.arange(n), np.arange(n))
        inb = (np.abs(gx + 0.5 - (half + fx)) <= bw / 2.0) & (np.abs(gy + 0.5 - (half + fy)) <= bh / 2.0)
        self.det_idx = np.flatnonzero(inb.ravel())
        self.max_white = len(self.det_idx) + 2
        self.last = None
        self.mode = None
        self.cur = (0.0, 1.0)

    def aiming(self, cap_flat, color, dev):
        wh = color_match(cap_flat, color, dev)
        return bool(wh[self.det_idx].any() and int(wh.sum()) <= self.max_white)

    def render(self, cap_flat, out_flat, reticle, hide=True):
        mode = (bool(reticle and self.png is not None), bool(hide))
        fresh = self.mode != mode
        if fresh:
            self.mode = mode
            self.last = None
            if mode == (True, True):
                out_flat[:] = self.base
                out_flat[self.win_idx, 3] = self.alpha_final
                self.cur = (self.base_rgb, self.inv_ar)
            elif mode == (False, True):
                out_flat[:] = 0
                out_flat[self.win_idx, 3] = self.fill.alpha8
                self.cur = (0.0, 1.0)
            else:
                out_flat[:] = self.base if mode[0] else 0
                return True
        if not mode[1]:
            return False
        base_rgb, inv = self.cur
        new = np.minimum(base_rgb + self.fill.colors(cap_flat) * inv + 0.5, 255).astype(np.uint8)
        if not fresh and self.last is not None and np.array_equal(new, self.last):
            return False
        self.last = new
        out_flat[self.win_idx, :3] = new
        return True

    def blanked(self):
        self.mode, self.last = None, None


if IS_WIN:
    from ctypes import wintypes as wt

    V = ctypes.c_void_p

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [("biSize", wt.DWORD), ("biWidth", wt.LONG), ("biHeight", wt.LONG), ("biPlanes", wt.WORD),
                    ("biBitCount", wt.WORD), ("biCompression", wt.DWORD), ("biSizeImage", wt.DWORD),
                    ("biXPelsPerMeter", wt.LONG), ("biYPelsPerMeter", wt.LONG), ("biClrUsed", wt.DWORD),
                    ("biClrImportant", wt.DWORD)]

    class BITMAPINFO(ctypes.Structure):
        _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wt.DWORD * 3)]

    class BLENDFUNCTION(ctypes.Structure):
        _fields_ = [("BlendOp", ctypes.c_ubyte), ("BlendFlags", ctypes.c_ubyte),
                    ("SourceConstantAlpha", ctypes.c_ubyte), ("AlphaFormat", ctypes.c_ubyte)]

    WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, V, wt.UINT, wt.WPARAM, wt.LPARAM)
    ENUMPROC = ctypes.WINFUNCTYPE(wt.BOOL, V, wt.LPARAM)

    class WNDCLASSW(ctypes.Structure):
        _fields_ = [("style", wt.UINT), ("lpfnWndProc", WNDPROC), ("cbClsExtra", ctypes.c_int),
                    ("cbWndExtra", ctypes.c_int), ("hInstance", V), ("hIcon", V), ("hCursor", V),
                    ("hbrBackground", V), ("lpszMenuName", wt.LPCWSTR), ("lpszClassName", wt.LPCWSTR)]

    def _sig(fn, res, *args):
        fn.restype = res
        fn.argtypes = list(args)

    class Surf:

        def __init__(self, win, w, h):
            bi = BITMAPINFO()
            bi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            bi.bmiHeader.biWidth, bi.bmiHeader.biHeight = w, -h
            bi.bmiHeader.biPlanes, bi.bmiHeader.biBitCount = 1, 32
            bits = V()
            self.g = win.g
            self.bmp = win.g.CreateDIBSection(win.screen_dc, ctypes.byref(bi), 0, ctypes.byref(bits), None, 0)
            if not self.bmp or not bits.value:
                raise ctypes.WinError(ctypes.get_last_error())
            self.dc = win.g.CreateCompatibleDC(win.screen_dc)
            win.g.SelectObject(self.dc, self.bmp)
            buf = (ctypes.c_ubyte * (w * h * 4)).from_address(bits.value)
            self.arr = np.frombuffer(buf, np.uint8).reshape(h * w, 4)
            self.size = (w, h)

        def close(self):
            self.g.DeleteDC(self.dc)
            self.g.DeleteObject(self.bmp)

    class Win:

        def __init__(self):
            u = self.u = ctypes.WinDLL("user32", use_last_error=True)
            g = self.g = ctypes.WinDLL("gdi32", use_last_error=True)
            k = self.k = ctypes.WinDLL("kernel32", use_last_error=True)
            self.d = ctypes.WinDLL("dwmapi")
            self.mm = ctypes.WinDLL("winmm")
            _sig(u.GetDC, V, V); _sig(u.ReleaseDC, ctypes.c_int, V, V)
            _sig(u.EnumWindows, wt.BOOL, ENUMPROC, wt.LPARAM)
            _sig(u.IsWindowVisible, wt.BOOL, V); _sig(u.IsWindow, wt.BOOL, V)
            _sig(u.GetForegroundWindow, V); _sig(u.GetSystemMetrics, ctypes.c_int, ctypes.c_int)
            _sig(u.GetAsyncKeyState, ctypes.c_short, ctypes.c_int)
            _sig(u.GetWindowThreadProcessId, wt.DWORD, V, ctypes.POINTER(wt.DWORD))
            _sig(u.GetClientRect, wt.BOOL, V, ctypes.POINTER(wt.RECT))
            _sig(u.ClientToScreen, wt.BOOL, V, ctypes.POINTER(wt.POINT))
            _sig(u.DefWindowProcW, ctypes.c_ssize_t, V, wt.UINT, wt.WPARAM, wt.LPARAM)
            _sig(u.RegisterClassW, wt.ATOM, ctypes.POINTER(WNDCLASSW))
            _sig(u.CreateWindowExW, V, wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD, ctypes.c_int, ctypes.c_int,
                 ctypes.c_int, ctypes.c_int, V, V, V, V)
            _sig(u.DestroyWindow, wt.BOOL, V)
            _sig(u.ShowWindow, wt.BOOL, V, ctypes.c_int)
            _sig(u.SetWindowPos, wt.BOOL, V, V, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wt.UINT)
            _sig(u.UpdateLayeredWindow, wt.BOOL, V, V, ctypes.POINTER(wt.POINT), ctypes.POINTER(wt.SIZE), V,
                 ctypes.POINTER(wt.POINT), wt.DWORD, ctypes.POINTER(BLENDFUNCTION), wt.DWORD)
            _sig(u.PeekMessageW, wt.BOOL, ctypes.POINTER(wt.MSG), V, wt.UINT, wt.UINT, wt.UINT)
            _sig(u.TranslateMessage, wt.BOOL, ctypes.POINTER(wt.MSG))
            _sig(u.DispatchMessageW, ctypes.c_ssize_t, ctypes.POINTER(wt.MSG))
            _sig(g.CreateCompatibleDC, V, V); _sig(g.DeleteDC, wt.BOOL, V); _sig(g.DeleteObject, wt.BOOL, V)
            _sig(g.SelectObject, V, V, V)
            _sig(g.CreateDIBSection, V, V, ctypes.POINTER(BITMAPINFO), wt.UINT, ctypes.POINTER(V), V, wt.DWORD)
            _sig(g.BitBlt, wt.BOOL, V, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, V, ctypes.c_int,
                 ctypes.c_int, wt.DWORD)
            _sig(k.OpenProcess, V, wt.DWORD, wt.BOOL, wt.DWORD); _sig(k.CloseHandle, wt.BOOL, V)
            _sig(k.QueryFullProcessImageNameW, wt.BOOL, V, wt.DWORD, wt.LPWSTR, ctypes.POINTER(wt.DWORD))
            _sig(k.GetModuleHandleW, V, wt.LPCWSTR)
            _sig(k.CreateMutexW, V, V, wt.BOOL, wt.LPCWSTR)
            self.pid_cache, self.pid_cache_t = {}, 0.0
            self.game_hwnd, self.last_enum = None, 0.0
            self.screen_dc = u.GetDC(None)
            self.cap = self.out = self.big = None
            self._wndproc = WNDPROC(lambda h, m, w, l: u.DefWindowProcW(h, m, w, l))
            self.hwnd = self._create_window("LIDReticleOverlayWindow", "LID Reticle Overlay")
            self.visible = False
            self.last_top = 0.0

        @staticmethod
        def dpi_aware():
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)
            except Exception:
                try:
                    ctypes.windll.user32.SetProcessDPIAware()
                except Exception:
                    pass

        def already_running(self):
            self.k.CreateMutexW(None, False, "Local\\LID_ReticleMaker")
            return ctypes.get_last_error() == 183

        def _create_window(self, cls, title):
            u = self.u
            wc = WNDCLASSW()
            wc.lpfnWndProc = self._wndproc
            wc.hInstance = self.k.GetModuleHandleW(None)
            wc.lpszClassName = cls
            u.RegisterClassW(ctypes.byref(wc))
            ex = 0x80000 | 0x20 | 0x8 | 0x08000000 | 0x80
            hwnd = u.CreateWindowExW(ex, cls, title, 0x80000000,
                                     0, 0, 1, 1, None, None, wc.hInstance, None)
            if not hwnd:
                raise ctypes.WinError(ctypes.get_last_error())
            return hwnd

        def show(self, on):
            if on != self.visible:
                self.u.ShowWindow(self.hwnd, 4 if on else 0)
                self.visible = on

        def keep_on_top(self):
            now = time.perf_counter()
            if self.visible and now - self.last_top > 1.0:
                self.u.SetWindowPos(self.hwnd, -1, 0, 0, 0, 0, 0x13)
                self.last_top = now

        def surface(self, name, w, h):
            cur = getattr(self, name)
            if cur is not None and cur.size == (w, h):
                return cur
            if cur is not None:
                cur.close()
            s = Surf(self, w, h)
            setattr(self, name, s)
            return s

        def grab(self, surf, x, y):
            w, h = surf.size
            self.g.BitBlt(surf.dc, 0, 0, w, h, self.screen_dc, int(x), int(y), 0x00CC0020)

        def present(self, surf, x, y, hwnd=None):
            w, h = surf.size
            pt, sz, src = wt.POINT(int(x), int(y)), wt.SIZE(w, h), wt.POINT(0, 0)
            bf = BLENDFUNCTION(0, 0, 255, 1)
            self.u.UpdateLayeredWindow(hwnd or self.hwnd, None, ctypes.byref(pt), ctypes.byref(sz), surf.dc,
                                       ctypes.byref(src), 0, ctypes.byref(bf), 2)

        def wait_frame(self, fps, t_prev):
            if fps > 0:
                left = 1.0 / fps - (time.perf_counter() - t_prev)
                if left > 0:
                    time.sleep(left)
                return
            t = time.perf_counter()
            hr = self.d.DwmFlush()
            if hr != 0 or time.perf_counter() - t < 0.002:
                time.sleep(0.008)

        def _is_game_pid(self, pid):
            r = self.pid_cache.get(pid)
            if r is None:
                r = False
                h = self.k.OpenProcess(0x1000, False, pid)
                if h:
                    buf = ctypes.create_unicode_buffer(1024)
                    n = wt.DWORD(1024)
                    if self.k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                        r = os.path.basename(buf.value).lower() == GAME_EXE
                    self.k.CloseHandle(h)
                self.pid_cache[pid] = r
            return r

        def _rect(self, hwnd):
            rc, pt = wt.RECT(), wt.POINT(0, 0)
            if self.u.GetClientRect(hwnd, ctypes.byref(rc)) and self.u.ClientToScreen(hwnd, ctypes.byref(pt)) \
                    and rc.right > 0 and rc.bottom > 0:
                return hwnd, pt.x, pt.y, rc.right, rc.bottom
            return None

        def find_game(self):
            now = time.perf_counter()
            if self.game_hwnd and self.u.IsWindow(self.game_hwnd) and self.u.IsWindowVisible(self.game_hwnd):
                r = self._rect(self.game_hwnd)
                if r:
                    return r
            self.game_hwnd = None
            if now - self.last_enum < 2.0:
                return None
            self.last_enum = now
            if now - self.pid_cache_t > 10:
                self.pid_cache.clear()
                self.pid_cache_t = now
            found = []

            def cb(hwnd, lp):
                if self.u.IsWindowVisible(hwnd):
                    pid = wt.DWORD()
                    self.u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                    if self._is_game_pid(pid.value):
                        found.append(hwnd)
                return True

            self.u.EnumWindows(ENUMPROC(cb), 0)
            best = None
            for hwnd in found:
                r = self._rect(hwnd)
                if r and (best is None or r[3] * r[4] > best[3] * best[4]):
                    best = r
            if best:
                self.game_hwnd = best[0]
            return best

        def foreground_is(self, hwnd):
            return bool(hwnd) and self.u.GetForegroundWindow() == hwnd

        def key_down(self, vk):
            return bool(self.u.GetAsyncKeyState(vk) & 0x8000)

        def pump(self):
            msg = wt.MSG()
            while self.u.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
                self.u.TranslateMessage(ctypes.byref(msg))
                self.u.DispatchMessageW(ctypes.byref(msg))

        def close(self):
            self.show(False)
            self.u.DestroyWindow(self.hwnd)
            for s in (self.cap, self.out, self.big):
                if s:
                    s.close()
            self.u.ReleaseDC(None, self.screen_dc)

else:  # the overlay is Windows-only; these names just have to exist so the UI can be imported
    Win = Surf = None


if IS_WIN:
    from ctypes import wintypes as wt

    class XINPUT_GAMEPAD(ctypes.Structure):
        _fields_ = [("wButtons", wt.WORD), ("bLeftTrigger", ctypes.c_ubyte), ("bRightTrigger", ctypes.c_ubyte),
                    ("sThumbLX", ctypes.c_short), ("sThumbLY", ctypes.c_short),
                    ("sThumbRX", ctypes.c_short), ("sThumbRY", ctypes.c_short)]

    class XINPUT_STATE(ctypes.Structure):
        _fields_ = [("dwPacketNumber", wt.DWORD), ("Gamepad", XINPUT_GAMEPAD)]

    class XInput:
        """Controller buttons through XInput; works whether or not any window of ours has focus."""

        def __init__(self):
            self.fn = None
            for name in ("xinput1_4.dll", "xinput1_3.dll", "xinput9_1_0.dll"):
                try:
                    self.fn = ctypes.WinDLL(name).XInputGetState
                    self.fn.argtypes = [wt.DWORD, ctypes.POINTER(XINPUT_STATE)]
                    self.fn.restype = wt.DWORD
                    break
                except (OSError, AttributeError):
                    self.fn = None
            self.slot, self.last_scan, self.st = None, 0.0, XINPUT_STATE()

        def read(self):
            """-> (buttons, left trigger, right trigger) or None when no controller answers."""
            if self.fn is None:
                return None
            now = time.perf_counter()
            if self.slot is not None and self.fn(self.slot, ctypes.byref(self.st)) == 0:
                g = self.st.Gamepad
                return g.wButtons, g.bLeftTrigger, g.bRightTrigger
            self.slot = None
            if now - self.last_scan < 2.0:
                return None
            self.last_scan = now
            for i in range(4):
                if self.fn(i, ctypes.byref(self.st)) == 0:
                    self.slot = i
                    g = self.st.Gamepad
                    return g.wButtons, g.bLeftTrigger, g.bRightTrigger
            return None


if IS_WIN:

    class Banner:
        """White in-game text (click-through layered window) used while adjusting."""
        BW, BH = 1100, 56

        def __init__(self, win):
            from PIL import ImageFont
            self.win = win
            self.hwnd = win._create_window("LIDReticleBannerWindow", "LID Reticle Message")
            self.surf = Surf(win, self.BW, self.BH)
            self.key = None
            self.visible = False
            self.last = 0.0
            self.font = None
            for name in ("segoeui.ttf", "arial.ttf"):
                try:
                    self.font = ImageFont.truetype(name, 30)
                    break
                except OSError:
                    pass
            if self.font is None:
                self.font = ImageFont.load_default()

        def show(self, text, g):
            from PIL import Image, ImageDraw
            x = g[1] + g[3] // 2 - self.BW // 2
            y = g[2] + int(g[4] * 0.14)
            key = (text, x, y)
            now = time.perf_counter()
            if key == self.key and self.visible:
                return
            if self.visible and self.key and self.key[0] != text and now - self.last < 0.02:
                return
            self.key, self.last = key, now
            im = Image.new("RGBA", (self.BW, self.BH), (0, 0, 0, 0))
            ImageDraw.Draw(im).text((self.BW // 2, self.BH // 2), text, font=self.font, fill=(255, 255, 255, 255),
                                    anchor="mm", stroke_width=3, stroke_fill=(0, 0, 0, 255))
            a = np.asarray(im, np.float32)
            al = a[..., 3:4] / 255.0
            out = np.concatenate([a[..., 2::-1] * al, a[..., 3:4]], -1)
            self.surf.arr[:] = np.rint(out).astype(np.uint8).reshape(-1, 4)
            self.win.present(self.surf, x, y, self.hwnd)
            if not self.visible:
                self.win.u.ShowWindow(self.hwnd, 4)
                self.win.u.SetWindowPos(self.hwnd, -1, 0, 0, 0, 0, 0x13)
                self.visible = True

        def hide(self):
            if self.visible:
                self.win.u.ShowWindow(self.hwnd, 0)
                self.visible = False
                self.key = None

        def close(self):
            self.hide()
            self.win.u.DestroyWindow(self.hwnd)
            self.surf.close()


class Engine(threading.Thread):
    """The reticle overlay, running in the background of the Reticle UI process."""

    def __init__(self, cfg, msgs):
        super().__init__(daemon=True, name="reticle-engine")
        self.cfg = cfg
        self.msgs = msgs
        self.quit = threading.Event()
        self.adjust_req = threading.Event()
        self.cancel_req = threading.Event()
        self.adjusting = False
        self.banner = None
        self.success_until = self.fail_until = 0.0
        self.need_release = False
        self.status = ""

    def say(self, s):
        if s != self.status:
            self.status = s
            self.msgs.put(s)

    def start_adjust(self):
        """Look for a new mark position. The saved one stays until a new one is found."""
        self.adjusting = True
        self.cancel_req.clear()
        self.adjust_req.set()

    def cancel_adjust(self):
        self.adjusting = False
        self.adjust_req.clear()
        self.cancel_req.set()

    def stop(self):
        self.quit.set()

    def run(self):
        if not IS_WIN:
            return
        try:
            self._loop()
        except Exception:
            import traceback
            self.msgs.put("Overlay stopped: " + traceback.format_exc().strip().splitlines()[-1])
            traceback.print_exc()

    @staticmethod
    def _mtime(path):
        try:
            return os.path.getmtime(path)
        except OSError:
            return None

    def _held(self, w, v, xi):
        if v.mouse_vk and w.key_down(v.mouse_vk):
            return True
        if v.kb_vk and w.key_down(v.kb_vk):
            return True
        if v.kb2_vk and w.key_down(v.kb2_vk):
            return True
        if v.joy:
            st = xi.read()
            if st:
                if v.joy == "lt":
                    return st[1] > 60
                if v.joy == "rt":
                    return st[2] > 60
                return bool(st[0] & JOY_BITS.get(v.joy, 0))
        return False

    def _grab_gray(self, w, surf, sx, sy):
        w.grab(surf, sx, sy)
        sw, sh = surf.size
        return surf.arr.reshape(sh, sw, 4)[..., :3].copy()

    def _calibrate(self, w, v, g, res, held, now):
        bn = self.banner
        sw, sh = min(1280, int(g[3] * 0.4)), min(720, int(g[4] * 0.4))
        sx, sy = g[1] + g[3] // 2 - sw // 2, g[2] + g[4] // 2 - sh // 2
        big = w.surface("big", sw, sh)
        if self.success_until:
            if now >= self.success_until:
                self.success_until = 0.0
                bn.hide()
                self.status = "Reticle active on %s." % res
            else:
                bn.show("Success", g)
            return
        if not held:
            self.need_release = False
        if now < self.fail_until:
            if self.need_release or not held:
                if not held and now - self.idle_t > 0.3:
                    self.idle = self._grab_gray(w, big, sx, sy)
                    self.idle_t = now
                bn.show("Failed, try again looking elsewhere, or increase mark size or color", g)
                return
            self.fail_until = 0.0
        if self.need_release:
            bn.show("Hold Aim to apply reticle  %.3fs" % v.hold, g)
            return
        if not held:
            self.press_t = None
            if now - self.idle_t > 0.3:
                self.idle = self._grab_gray(w, big, sx, sy)
                self.idle_t = now
            bn.show("Hold Aim to apply reticle  %.3fs" % v.hold, g)
            self.say("Hold aim button for %g seconds while in-game to add reticle" % v.hold)
            return
        if self.press_t is None:
            self.press_t = now
        left = v.hold - (now - self.press_t)
        if left > 0:
            bn.show("Hold Aim to apply reticle  %.3fs" % left, g)
            return
        frames = []
        for i in range(4):
            frames.append(self._grab_gray(w, big, sx, sy))
            if i < 3:
                time.sleep(0.03)
        found, why = find_dot(frames, self.idle, v.color, v.dev)
        self.press_t = None
        if found is None:
            self.fail_until = now + 3.5
            self.need_release = True
            self.say("Failed, try again looking elsewhere, or increase mark size or color")
            return
        mx, my, bw, bh = found
        dot = {"x": sx + mx - g[1], "y": sy + my - g[2], "w": int(bw), "h": int(bh), "resolution": res}
        self.cfg.set(dot=dot)
        self.idle = None
        self.adjusting = False
        self.success_until = now + 1.5
        self.say("Success: mark found at (%g, %g) for %s and saved." % (dot["x"], dot["y"], res))

    def _reset_adjust(self):
        self.press_t = self.idle = None
        self.success_until = self.fail_until = 0.0
        self.need_release = False
        if self.banner:
            self.banner.hide()

    def _ensure_layout(self, w, dot, v):
        key = (dot, v.size, v.off_x, v.off_y, None if self.png is None else (self.png.shape, self.png_stamp))
        if key != self.layout_key:
            self.layout = Layout(dot, v, self.png)
            self.layout_key = key
            w.surface("cap", self.layout.n, self.layout.n)
            w.surface("out", self.layout.W, self.layout.H)
            self.state = "unknown"
        return self.layout

    def _present_blank(self, w, win_xy):
        w.out.arr[:] = 0
        w.present(w.out, *win_xy)
        self.state = "blank"
        if self.layout is not None:
            self.layout.blanked()

    def _loop(self):
        w = Win()
        if w.already_running():
            self.msgs.put("The overlay is already running in another Reticle Maker window.")
            w.close()
            return
        xi = XInput()
        self.banner = Banner(w)
        self.png, self.png_stamp = load_current()
        self.layout = self.layout_key = None
        self.state = "unknown"
        self.press_t = self.idle = None
        self.idle_t = 0.0
        self.reticle = False
        self.was_held = False
        self.hold_t = self.last_look = self.hide_until = 0.0
        v = self.cfg.values()
        last_scan = last_reload = 0.0
        game, fg = None, False
        t_prev = time.perf_counter()
        w.mm.timeBeginPeriod(1)
        try:
            while not self.quit.is_set():
                w.pump()
                now = time.perf_counter()
                if now - last_scan > 0.5:
                    last_scan = now
                    game = w.find_game()
                    fg = bool(game) and w.foreground_is(game[0])
                if now - last_reload > 0.3:
                    last_reload = now
                    v = self.cfg.values()
                    stamp = self.png_stamp
                    cur = current_name()
                    cp = os.path.join(CURRENT_DIR, cur) if cur else None
                    if cur is None and self.png is not None:
                        self.png, self.png_stamp = None, None
                    elif cp and (stamp is None or stamp[0] != cp or self._mtime(cp) != stamp[1]):
                        self.png, self.png_stamp = load_current()
                if self.adjust_req.is_set():
                    self.adjust_req.clear()
                    self._reset_adjust()
                    self.status = ""
                    v = self.cfg.values()
                    self.say("Hold aim button for %g seconds while in-game to add reticle" % v.hold)
                if self.cancel_req.is_set():
                    self.cancel_req.clear()
                    self._reset_adjust()
                    self.status = ""
                    self.say("Adjust cancelled. The saved mark was kept.")
                if not game:
                    self.banner.hide()
                    if w.visible:
                        w.show(False)
                    self.state = "unknown"
                    self.say("Waiting for the game window...")
                    time.sleep(0.1)
                    t_prev = time.perf_counter()
                    continue
                if not fg:
                    self.banner.hide()
                    if w.visible:
                        w.show(False)
                    self.state = "unknown"
                    self.say("Paused: the game is not in front.")
                    time.sleep(0.05)
                    t_prev = time.perf_counter()
                    continue
                res = "%dx%d" % (game[3], game[4])
                dot = Config.dot_for(v.dot, res)
                held = self._held(w, v, xi)
                if self.adjusting or self.success_until:
                    if w.visible:
                        w.show(False)
                    self.state = "unknown"
                    self._calibrate(w, v, game, res, held, now)
                    time.sleep(0.01)
                    t_prev = time.perf_counter()
                    continue
                if dot is None:
                    self.say("No mark position for %s: press Start Adjust." % res)
                    if w.visible:
                        w.show(False)
                    time.sleep(0.01)
                    t_prev = time.perf_counter()
                    continue
                lay = self._ensure_layout(w, dot, v)
                ax, ay = game[1] + lay.anchor_off[0], game[2] + lay.anchor_off[1]
                cap_xy = (ax + lay.cap_off[0], ay + lay.cap_off[1])
                win_xy = (ax + lay.win_off[0], ay + lay.win_off[1])
                if not w.visible:
                    self._present_blank(w, win_xy)
                    w.show(True)
                self.say("Reticle active on %s." % res)
                edge = held and not self.was_held
                self.was_held = held
                if edge:
                    self.hold_t, self.last_look, self.reticle = now, -1e9, False
                hide = v.hide
                if held:
                    self.hide_until = now + (v.persist if hide else 0.0)
                elif now >= self.hide_until:
                    if self.state != "blank":
                        self._present_blank(w, win_xy)
                    time.sleep(0.008)    # aim button not held: ~125 checks a second is plenty
                    t_prev = time.perf_counter()
                    continue
                if held and not self.reticle and now - self.hold_t >= v.wait and now - self.last_look >= v.every:
                    if hide:
                        self._present_blank(w, win_xy)
                        w.wait_frame(0, 0)
                    w.grab(w.cap, *cap_xy)
                    self.reticle = lay.aiming(w.cap.arr, v.color, v.dev)
                    self.last_look = now
                elif hide:
                    w.grab(w.cap, *cap_xy)
                draw = held and self.reticle
                if hide or draw:
                    if lay.render(w.cap.arr, w.out.arr, draw, hide) or self.state != "drawn":
                        w.present(w.out, *win_xy)
                    self.state = "drawn"
                elif self.state != "blank":
                    self._present_blank(w, win_xy)
                w.keep_on_top()
                w.wait_frame(FPS, t_prev)
                t_prev = time.perf_counter()
        finally:
            self.banner.close()
            w.mm.timeEndPeriod(1)
            w.close()
    


if not IS_WIN:
    Banner = XInput = None