@echo off
cd /d "%~dp0"
python -m pip install --upgrade pip pyinstaller pillow pywin32 numpy lzallright
python -c "import pygame" 2>nul
if errorlevel 1 (
  echo pygame is missing. Install the binary wheel:
  echo   python -m pip install pygame-ce
  pause
  exit /b 1
)

set ICON_ICO=UI_Assets\Lidico.ico
if not exist "%ICON_ICO%" (
  echo Missing %ICON_ICO% - the exe would get the default Python icon.
  pause
  exit /b 1
)

REM UI_Assets (background, icons, Boxes\ joystick .png buttons) is packed inside the exe.
REM The Reticles folder, the saved original UPK and the json/ini files are created next to the exe.
set DATA=--add-data "UI_Assets;UI_Assets"
REM The WHOLE Reticles folder (every shape and folder you put in it) is packed as it is. The exe pastes it next
REM to itself when there is no Reticles folder yet, and afterwards only restores a deleted _Outer\_Default or
REM _Center\_Default folder (and Plus.png / Dot.png inside them) - nothing else is ever brought back.
if exist "Reticles" (
  set DATA=%DATA% --add-data "Reticles;Reticles"
) else (
  echo Note: no Reticles folder next to this .bat - the exe will create plain defaults instead.
)

python -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name "LID_Borderless" ^
  --icon "%ICON_ICO%" ^
  %DATA% ^
  --paths "." ^
  --hidden-import reticle_maker ^
  --hidden-import rt_core ^
  --hidden-import rt_overlay ^
  --hidden-import rt_widgets ^
  --hidden-import rt_ui ^
  --hidden-import Hash_remover ^
  --hidden-import PIL ^
  --hidden-import PIL.Image ^
  --hidden-import PIL.ImageDraw ^
  --hidden-import PIL.ImageFont ^
  --hidden-import numpy ^
  --hidden-import lzallright ^
  --hidden-import pygame ^
  borderless_letitdie.py

echo.
echo Built: dist\LID_Borderless.exe
echo Reticle Maker runs from the Reticle button inside this same exe.
pause