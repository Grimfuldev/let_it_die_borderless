#!/usr/bin/env python3
"""Reticle Maker: UPK mark injector + reticle overlay in one program.

Started from the Reticle button of borderless_letitdie.py (it runs as its own process so the
two windows stay independent). Both halves write the same reticle_config.json.

Layout: rt_core (constants, Config, Steam / UPK, reticle images) <- rt_overlay (in-game overlay)
        <- rt_widgets (UI widgets + catalog popups) <- rt_ui (window).  This file is the entry point.
"""
import sys

from rt_core import *  # noqa: F401,F403  (re-exported for borderless_letitdie.py)
from rt_overlay import *  # noqa: F401,F403
from rt_widgets import *  # noqa: F401,F403
from rt_ui import *  # noqa: F401,F403
from rt_ui import main

if __name__ == "__main__":
    sys.exit(main())