"""
Closer reconstruction of lid_hash_test (KSFA).
Follows the original PE resource directory walk (type 10 / id 1010).
"""

from pathlib import Path
import struct
import shutil
import hashlib
import os
import re
import sys

EXE_NAME = 'BrgGame-Steam.exe'
RESOURCE_TYPE = 10
RESOURCE_ID = 1010
HASH_BYTES = 20
SECTION_MARKER = b'+++'
BACKUP_SUFFIX = '.backup'

class Problem(Exception):
    pass

def _u16(raw, off):
    return struct.unpack_from('<H', raw, off)[0]

def _u32(raw, off):
    return struct.unpack_from('<I', raw, off)[0]

def _pe_offset(raw):
    return _u32(raw, 0x3C)

def _sections(raw):
    pe = _pe_offset(raw)
    num = _u16(raw, pe + 6)
    size_opt = _u16(raw, pe + 20)
    table = pe + 24 + size_opt
    secs = []
    for i in range(num):
        o = table + i * 40
        name = raw[o:o+8].split(b'\x00')[0]
        vsize, vaddr, rawsize, rawptr = struct.unpack_from('<IIII', raw, o + 8)
        secs.append((name, vaddr, vsize, rawptr, rawsize))
    return secs

def _file_offset(raw, rva):
    for name, vaddr, vsize, rawptr, rawsize in _sections(raw):
        span = max(vsize, rawsize)
        if vaddr <= rva < vaddr + span:
            return rawptr + (rva - vaddr)
    raise Problem("RVA not in any section")

def _entries(raw, at):
    """Read a resource directory: list of (key, offset_or_rva)."""
    named = _u16(raw, at + 12)
    ids = _u16(raw, at + 14)
    out = []
    for i in range(named + ids):
        key = _u32(raw, at + 16 + i * 8)
        off = _u32(raw, at + 20 + i * 8)
        out.append((key, off))
    return out

def hash_list(raw):
    """Locate the verification list via PE resource directory (type 10 / id 1010)."""
    pe = _pe_offset(raw)
    optional = pe + 24
    if _u16(raw, optional) != 0x20B:          # PE32+
        raise Problem("this tool only understands 64-bit programs")
    # DataDirectory[2] = Resource
    res_rva = _u32(raw, optional + 112 + 16)
    if not res_rva:
        raise Problem("the program carries no resources")
    root = _file_offset(raw, res_rva)

    def descend(at, wanted):
        for key, offset in _entries(raw, at):
            if key == wanted:
                if not (offset & 0x80000000):
                    raise Problem("the resource table is not the expected shape")
                return root + (offset & 0x7FFFFFFF)
        raise Problem("the file list is not in this program")

    by_type = descend(root, RESOURCE_TYPE)
    by_id = descend(by_type, RESOURCE_ID)
    _key, leaf = _entries(raw, by_id)[0]
    if leaf & 0x80000000:
        raise Problem("the resource table is nested deeper than expected")
    leaf = root + leaf
    data_rva = _u32(raw, leaf)
    size = _u32(raw, leaf + 4)
    return _file_offset(raw, data_rva), size

def walk(raw):
    """Return list of (name_lower, offset_of_last_char, sha1_hex)."""
    at, length = hash_list(raw)
    end = at + length
    cursor = at
    out = []
    while cursor < end:
        stop = raw.find(b'\x00', cursor, end)
        if stop < 0:
            break
        name = raw[cursor:stop]
        cursor = stop + 1
        if not name:
            continue
        if name == SECTION_MARKER:
            break
        if cursor + HASH_BYTES > end:
            break
        try:
            text = name.decode('ascii')
        except UnicodeDecodeError:
            raise Problem("a name in the list is not plain text")
        sha = raw[cursor:cursor + HASH_BYTES]
        last = stop - 1
        out.append((text.lower(), last, sha.hex()))
        cursor += HASH_BYTES
    if not out:
        raise Problem("the file list is empty")
    return out

def code_fingerprint(raw):
    for name, _v, _vs, rawptr, rawsize in _sections(raw):
        if name == b'.text':
            return hashlib.sha256(raw[rawptr:rawptr + rawsize]).hexdigest()
    raise Problem("the program has no code section")

def mangled(raw, targets):
    """Change last character of each targeted name to X (or Y if already X)."""
    out = bytearray(raw)
    touched = []
    for _name, last, _sha in targets:
        current = out[last]
        out[last] = ord('X') if current != ord('X') else ord('Y')
        touched.append(last)
    changed = bytes(out)
    if len(changed) != len(raw):
        raise Problem("the change altered the file's size - refusing")
    if code_fingerprint(changed) != code_fingerprint(raw):
        raise Problem("the change altered the game's CODE - refusing")
    # Extra safety checks from the original
    differs = [i for i in range(len(raw)) if raw[i] != changed[i]]
    if sorted(set(touched)) != differs:
        raise Problem("bytes changed that were not meant to - refusing")
    at, length = hash_list(raw)
    if any(not (at <= i < at + length) for i in differs):
        raise Problem("a change landed outside the file list - refusing")
    if len(walk(changed)) != len(walk(raw)):
        raise Problem("the list no longer reads back correctly - refusing")
    return changed, differs

def find_game(script_dir=None):
    script_dir = Path(script_dir) if script_dir else Path(__file__).resolve().parent
    for folder in (script_dir, Path.cwd()):
        exe = folder / EXE_NAME
        if exe.is_file():
            return exe
    raise Problem(f"could not find {EXE_NAME} in the script folder or current working folder")

# Safe copies sit next to the file in the game folder and carry the game's build id in the name:
#   BrgGame-Steam.exe.<buildid>.backup      (a bare  BrgGame-Steam.exe.backup  means "build unknown")
def backup_path(path, build=""):
    path = Path(path)
    return path.with_name(path.name + (".%s" % build if build else "") + BACKUP_SUFFIX)

def list_backups(path):
    """-> [(file, build)] for every backup of this game file ("" = no build id in the name)."""
    path = Path(path)
    pat = re.compile(re.escape(path.name) + r"(?:\.(\d+))?" + re.escape(BACKUP_SUFFIX) + "$")
    found = []
    try:
        for f in path.parent.iterdir():
            m = pat.match(f.name)
            if m and f.is_file():
                found.append((f, m.group(1) or ""))
    except OSError:
        pass
    return found

def valid_backup(path, build=""):
    """The backup that fits the game's current build: the one named with it, else a nameless (build unknown) one.
    With an unknown current build any backup counts. None when the only ones belong to another build."""
    found = list_backups(path)
    for want in ([build, ""] if build else [None]):
        for f, b in found:
            if want is None or b == want:
                return f
    return None

def refresh_backup(path, build=""):
    """Make sure <file>.<build>.backup is an exact copy of `path` (which must be a clean original), then remove the
    backups of other builds. A copy that already matches is left alone. Returns the backup path."""
    import filecmp
    path = Path(path)
    dst = backup_path(path, build)
    if not (dst.is_file() and filecmp.cmp(path, dst, shallow=False)):
        tmp = dst.with_name(dst.name + ".tmp")
        shutil.copyfile(path, tmp)
        if not filecmp.cmp(path, tmp, shallow=False):
            tmp.unlink()
            raise Problem("the backup did not copy correctly - nothing was changed")
        os.replace(tmp, dst)
    for f, _b in list_backups(path):
        if f != dst:
            try:
                f.unlink()
            except OSError:
                pass
    return dst

def discard_backups(path):
    """Delete every backup this program made for `path` (any build). Returns how many were removed."""
    n = 0
    for f, _b in list_backups(path):
        try:
            f.unlink()
            n += 1
        except OSError:
            pass
    return n

def same_file(a, b):
    import filecmp
    try:
        return filecmp.cmp(a, b, shallow=False)
    except OSError:
        return False

def sha_status(exe_path: Path, build=""):
    """Read-only look-up (writes nothing). Is the game's file verification (SHA) still active?

    -> {"state": "active" | "off" | "unknown",
        "button": "Unlock SHA" | "Restore SHA" | None,   # what the UI button should say
        "entries": names in the list, "switched": how many of them are switched off,
        "backup": a backup for this game build exists, "stale": only backups of another build exist, "detail": short text}
    """
    exe_path = Path(exe_path)
    info = {"state": "unknown", "button": None, "entries": 0, "switched": 0,
            "backup": valid_backup(exe_path, build) is not None, "stale": False, "detail": ""}
    info["stale"] = not info["backup"] and bool(list_backups(exe_path))
    try:
        raw = exe_path.read_bytes()
        if raw[:2] != b'MZ' or raw[_pe_offset(raw):_pe_offset(raw) + 4] != b'PE\0\0':
            raise Problem("this is not a Windows program")
        listed = walk(raw)
    except (Problem, OSError, struct.error) as e:
        info["detail"] = str(e)
        return info
    info["entries"] = len(listed)
    info["switched"] = sum(1 for name, _l, _s in listed if name[-1:] in ('x', 'y'))
    if info["switched"] == info["entries"]:
        info.update(state="off", button="Restore SHA", detail="verification is switched off")
    else:
        info.update(state="active", button="Unlock SHA", detail="verification is active")
    return info

def is_off(listed):
    """True when every listed name already ends in the replacement character (already switched off)."""
    return all(name[-1:] in ('x', 'y') for name, _last, _sha in listed)

def same_outside(raw, changed, positions):
    """Both buffers identical everywhere except at `positions` (fast: compares the stretches in between)."""
    prev = 0
    for p in sorted(set(positions)):
        if raw[prev:p] != changed[prev:p]:
            return False
        prev = p + 1
    return raw[prev:] == changed[prev:]

def atomic_write(path, data):
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_bytes(data)
    if tmp.read_bytes() != data:
        tmp.unlink()
        raise Problem("the temporary file did not read back correctly - nothing was changed")
    os.replace(tmp, path)

def turn_off_all(exe_path: Path, dry_run=False, build=""):
    raw = exe_path.read_bytes()
    if raw[:2] != b'MZ' or raw[_pe_offset(raw):_pe_offset(raw) + 4] != b'PE\0\0':
        raise Problem("this is not a Windows program")
    listed = walk(raw)
    if is_off(listed):
        raise Problem("the verification list is already switched off - nothing to do")
    changed, differs = mangled(raw, listed)
    if not same_outside(raw, changed, differs):
        raise Problem("bytes changed that were not meant to - refusing")
    after = walk(changed)
    if [s for _n, _l, s in after] != [s for _n, _l, s in listed]:
        raise Problem("the stored hashes would change - refusing")
    if dry_run:
        return len(differs)
    refresh_backup(exe_path, build)      # the exe is an unmodified original here, so this is the safe copy
    atomic_write(exe_path, changed)
    written = exe_path.read_bytes()
    if written != changed:
        raise Problem("the written file does not match - restore it with: restore")
    return len(differs)

def restore(exe_path: Path, build=""):
    backup = valid_backup(exe_path, build)
    if backup is None:
        raise Problem("no backup found for this game version: " + backup_path(exe_path, build).name)
    atomic_write(exe_path, backup.read_bytes())

def main(argv):
    args = [a for a in argv if not a.startswith('-')]
    flags = {a for a in argv if a.startswith('-')}
    try:
        game = find_game()
        if args[:1] == ['off'] and '--all' in flags:
            n = turn_off_all(game, dry_run='--dry-run' in flags)
            print(("would switch off" if '--dry-run' in flags else "switched off"), n, "entries")
        elif args[:1] == ['status']:
            st = sha_status(game)
            print(st["state"], "-", st["detail"], f"({st['switched']}/{st['entries']} switched off)",
                  "| button:", st["button"], "| backup:", "yes" if st["backup"] else "no")
        elif args[:1] == ['restore']:
            restore(game)
            print("restored the original from the .backup next to it")
        else:
            print("usage: off --all [--dry-run]   |   restore   |   status")
            return 2
    except (Problem, OSError, struct.error) as e:
        print("Stopped, nothing was damaged:", e)
        return 1
    return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))